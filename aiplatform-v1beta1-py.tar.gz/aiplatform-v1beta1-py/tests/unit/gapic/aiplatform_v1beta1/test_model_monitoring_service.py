# -*- coding: utf-8 -*-
# Copyright 2024 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
import os
# try/except added for compatibility with python < 3.8
try:
    from unittest import mock
    from unittest.mock import AsyncMock  # pragma: NO COVER
except ImportError:  # pragma: NO COVER
    import mock

import grpc
from grpc.experimental import aio
from collections.abc import Iterable, AsyncIterable
from google.protobuf import json_format
import json
import math
import pytest
from google.api_core import api_core_version
from proto.marshal.rules.dates import DurationRule, TimestampRule
from proto.marshal.rules import wrappers
try:
    import aiohttp  # type: ignore
    from google.auth.aio.transport.sessions import AsyncAuthorizedSession
    from google.api_core.operations_v1 import AsyncOperationsRestClient
    HAS_ASYNC_REST_EXTRA = True
except ImportError: # pragma: NO COVER
    HAS_ASYNC_REST_EXTRA = False
from requests import Response
from requests import Request, PreparedRequest
from requests.sessions import Session
from google.protobuf import json_format

try:
    from google.auth.aio import credentials as ga_credentials_async
    HAS_GOOGLE_AUTH_AIO = True
except ImportError: # pragma: NO COVER
    HAS_GOOGLE_AUTH_AIO = False

from google.api_core import client_options
from google.api_core import exceptions as core_exceptions
from google.api_core import future
from google.api_core import gapic_v1
from google.api_core import grpc_helpers
from google.api_core import grpc_helpers_async
from google.api_core import operation
from google.api_core import operation_async  # type: ignore
from google.api_core import operations_v1
from google.api_core import path_template
from google.api_core import retry as retries
from google.auth import credentials as ga_credentials
from google.auth.exceptions import MutualTLSChannelError
from google.cloud.aiplatform_v1beta1.services.model_monitoring_service import ModelMonitoringServiceAsyncClient
from google.cloud.aiplatform_v1beta1.services.model_monitoring_service import ModelMonitoringServiceClient
from google.cloud.aiplatform_v1beta1.services.model_monitoring_service import pagers
from google.cloud.aiplatform_v1beta1.services.model_monitoring_service import transports
from google.cloud.aiplatform_v1beta1.types import accelerator_type
from google.cloud.aiplatform_v1beta1.types import explanation
from google.cloud.aiplatform_v1beta1.types import explanation_metadata
from google.cloud.aiplatform_v1beta1.types import io
from google.cloud.aiplatform_v1beta1.types import job_state
from google.cloud.aiplatform_v1beta1.types import machine_resources
from google.cloud.aiplatform_v1beta1.types import model_monitor
from google.cloud.aiplatform_v1beta1.types import model_monitor as gca_model_monitor
from google.cloud.aiplatform_v1beta1.types import model_monitoring_alert
from google.cloud.aiplatform_v1beta1.types import model_monitoring_job
from google.cloud.aiplatform_v1beta1.types import model_monitoring_job as gca_model_monitoring_job
from google.cloud.aiplatform_v1beta1.types import model_monitoring_service
from google.cloud.aiplatform_v1beta1.types import model_monitoring_spec
from google.cloud.aiplatform_v1beta1.types import model_monitoring_stats
from google.cloud.aiplatform_v1beta1.types import operation as gca_operation
from google.cloud.aiplatform_v1beta1.types import reservation_affinity
from google.cloud.location import locations_pb2
from google.iam.v1 import iam_policy_pb2  # type: ignore
from google.iam.v1 import options_pb2  # type: ignore
from google.iam.v1 import policy_pb2  # type: ignore
from google.longrunning import operations_pb2 # type: ignore
from google.oauth2 import service_account
from google.protobuf import any_pb2  # type: ignore
from google.protobuf import empty_pb2  # type: ignore
from google.protobuf import field_mask_pb2  # type: ignore
from google.protobuf import struct_pb2  # type: ignore
from google.protobuf import timestamp_pb2  # type: ignore
from google.rpc import status_pb2  # type: ignore
from google.type import interval_pb2  # type: ignore
import google.auth


async def mock_async_gen(data, chunk_size=1):
    for i in range(0, len(data)):  # pragma: NO COVER
        chunk = data[i : i + chunk_size]
        yield chunk.encode("utf-8")

def client_cert_source_callback():
    return b"cert bytes", b"key bytes"

# TODO: use async auth anon credentials by default once the minimum version of google-auth is upgraded.
# See related issue: https://github.com/googleapis/gapic-generator-python/issues/2107.
def async_anonymous_credentials():
    if HAS_GOOGLE_AUTH_AIO:
        return ga_credentials_async.AnonymousCredentials()
    return ga_credentials.AnonymousCredentials()

# If default endpoint is localhost, then default mtls endpoint will be the same.
# This method modifies the default endpoint so the client can produce a different
# mtls endpoint for endpoint testing purposes.
def modify_default_endpoint(client):
    return "foo.googleapis.com" if ("localhost" in client.DEFAULT_ENDPOINT) else client.DEFAULT_ENDPOINT

# If default endpoint template is localhost, then default mtls endpoint will be the same.
# This method modifies the default endpoint template so the client can produce a different
# mtls endpoint for endpoint testing purposes.
def modify_default_endpoint_template(client):
    return "test.{UNIVERSE_DOMAIN}" if ("localhost" in client._DEFAULT_ENDPOINT_TEMPLATE) else client._DEFAULT_ENDPOINT_TEMPLATE


def test__get_default_mtls_endpoint():
    api_endpoint = "example.googleapis.com"
    api_mtls_endpoint = "example.mtls.googleapis.com"
    sandbox_endpoint = "example.sandbox.googleapis.com"
    sandbox_mtls_endpoint = "example.mtls.sandbox.googleapis.com"
    non_googleapi = "api.example.com"

    assert ModelMonitoringServiceClient._get_default_mtls_endpoint(None) is None
    assert ModelMonitoringServiceClient._get_default_mtls_endpoint(api_endpoint) == api_mtls_endpoint
    assert ModelMonitoringServiceClient._get_default_mtls_endpoint(api_mtls_endpoint) == api_mtls_endpoint
    assert ModelMonitoringServiceClient._get_default_mtls_endpoint(sandbox_endpoint) == sandbox_mtls_endpoint
    assert ModelMonitoringServiceClient._get_default_mtls_endpoint(sandbox_mtls_endpoint) == sandbox_mtls_endpoint
    assert ModelMonitoringServiceClient._get_default_mtls_endpoint(non_googleapi) == non_googleapi

def test__read_environment_variables():
    assert ModelMonitoringServiceClient._read_environment_variables() == (False, "auto", None)

    with mock.patch.dict(os.environ, {"GOOGLE_API_USE_CLIENT_CERTIFICATE": "true"}):
        assert ModelMonitoringServiceClient._read_environment_variables() == (True, "auto", None)

    with mock.patch.dict(os.environ, {"GOOGLE_API_USE_CLIENT_CERTIFICATE": "false"}):
        assert ModelMonitoringServiceClient._read_environment_variables() == (False, "auto", None)

    with mock.patch.dict(os.environ, {"GOOGLE_API_USE_CLIENT_CERTIFICATE": "Unsupported"}):
        with pytest.raises(ValueError) as excinfo:
            ModelMonitoringServiceClient._read_environment_variables()
    assert str(excinfo.value) == "Environment variable `GOOGLE_API_USE_CLIENT_CERTIFICATE` must be either `true` or `false`"

    with mock.patch.dict(os.environ, {"GOOGLE_API_USE_MTLS_ENDPOINT": "never"}):
        assert ModelMonitoringServiceClient._read_environment_variables() == (False, "never", None)

    with mock.patch.dict(os.environ, {"GOOGLE_API_USE_MTLS_ENDPOINT": "always"}):
        assert ModelMonitoringServiceClient._read_environment_variables() == (False, "always", None)

    with mock.patch.dict(os.environ, {"GOOGLE_API_USE_MTLS_ENDPOINT": "auto"}):
        assert ModelMonitoringServiceClient._read_environment_variables() == (False, "auto", None)

    with mock.patch.dict(os.environ, {"GOOGLE_API_USE_MTLS_ENDPOINT": "Unsupported"}):
        with pytest.raises(MutualTLSChannelError) as excinfo:
            ModelMonitoringServiceClient._read_environment_variables()
    assert str(excinfo.value) == "Environment variable `GOOGLE_API_USE_MTLS_ENDPOINT` must be `never`, `auto` or `always`"

    with mock.patch.dict(os.environ, {"GOOGLE_CLOUD_UNIVERSE_DOMAIN": "foo.com"}):
        assert ModelMonitoringServiceClient._read_environment_variables() == (False, "auto", "foo.com")

def test__get_client_cert_source():
    mock_provided_cert_source = mock.Mock()
    mock_default_cert_source = mock.Mock()

    assert ModelMonitoringServiceClient._get_client_cert_source(None, False) is None
    assert ModelMonitoringServiceClient._get_client_cert_source(mock_provided_cert_source, False) is None
    assert ModelMonitoringServiceClient._get_client_cert_source(mock_provided_cert_source, True) == mock_provided_cert_source

    with mock.patch('google.auth.transport.mtls.has_default_client_cert_source', return_value=True):
        with mock.patch('google.auth.transport.mtls.default_client_cert_source', return_value=mock_default_cert_source):
            assert ModelMonitoringServiceClient._get_client_cert_source(None, True) is mock_default_cert_source
            assert ModelMonitoringServiceClient._get_client_cert_source(mock_provided_cert_source, "true") is mock_provided_cert_source

@mock.patch.object(ModelMonitoringServiceClient, "_DEFAULT_ENDPOINT_TEMPLATE", modify_default_endpoint_template(ModelMonitoringServiceClient))
@mock.patch.object(ModelMonitoringServiceAsyncClient, "_DEFAULT_ENDPOINT_TEMPLATE", modify_default_endpoint_template(ModelMonitoringServiceAsyncClient))
def test__get_api_endpoint():
    api_override = "foo.com"
    mock_client_cert_source = mock.Mock()
    default_universe = ModelMonitoringServiceClient._DEFAULT_UNIVERSE
    default_endpoint = ModelMonitoringServiceClient._DEFAULT_ENDPOINT_TEMPLATE.format(UNIVERSE_DOMAIN=default_universe)
    mock_universe = "bar.com"
    mock_endpoint = ModelMonitoringServiceClient._DEFAULT_ENDPOINT_TEMPLATE.format(UNIVERSE_DOMAIN=mock_universe)

    assert ModelMonitoringServiceClient._get_api_endpoint(api_override, mock_client_cert_source, default_universe, "always") == api_override
    assert ModelMonitoringServiceClient._get_api_endpoint(None, mock_client_cert_source, default_universe, "auto") == ModelMonitoringServiceClient.DEFAULT_MTLS_ENDPOINT
    assert ModelMonitoringServiceClient._get_api_endpoint(None, None, default_universe, "auto") == default_endpoint
    assert ModelMonitoringServiceClient._get_api_endpoint(None, None, default_universe, "always") == ModelMonitoringServiceClient.DEFAULT_MTLS_ENDPOINT
    assert ModelMonitoringServiceClient._get_api_endpoint(None, mock_client_cert_source, default_universe, "always") == ModelMonitoringServiceClient.DEFAULT_MTLS_ENDPOINT
    assert ModelMonitoringServiceClient._get_api_endpoint(None, None, mock_universe, "never") == mock_endpoint
    assert ModelMonitoringServiceClient._get_api_endpoint(None, None, default_universe, "never") == default_endpoint

    with pytest.raises(MutualTLSChannelError) as excinfo:
        ModelMonitoringServiceClient._get_api_endpoint(None, mock_client_cert_source, mock_universe, "auto")
    assert str(excinfo.value) == "mTLS is not supported in any universe other than googleapis.com."


def test__get_universe_domain():
    client_universe_domain = "foo.com"
    universe_domain_env = "bar.com"

    assert ModelMonitoringServiceClient._get_universe_domain(client_universe_domain, universe_domain_env) == client_universe_domain
    assert ModelMonitoringServiceClient._get_universe_domain(None, universe_domain_env) == universe_domain_env
    assert ModelMonitoringServiceClient._get_universe_domain(None, None) == ModelMonitoringServiceClient._DEFAULT_UNIVERSE

    with pytest.raises(ValueError) as excinfo:
        ModelMonitoringServiceClient._get_universe_domain("", None)
    assert str(excinfo.value) == "Universe Domain cannot be an empty string."


@pytest.mark.parametrize("client_class,transport_name", [
    (ModelMonitoringServiceClient, "grpc"),
    (ModelMonitoringServiceAsyncClient, "grpc_asyncio"),
    (ModelMonitoringServiceClient, "rest"),
])
def test_model_monitoring_service_client_from_service_account_info(client_class, transport_name):
    creds = ga_credentials.AnonymousCredentials()
    with mock.patch.object(service_account.Credentials, 'from_service_account_info') as factory:
        factory.return_value = creds
        info = {"valid": True}
        client = client_class.from_service_account_info(info, transport=transport_name)
        assert client.transport._credentials == creds
        assert isinstance(client, client_class)

        assert client.transport._host == (
            'aiplatform.googleapis.com:443'
            if transport_name in ['grpc', 'grpc_asyncio']
            else
            'https://aiplatform.googleapis.com'
        )


@pytest.mark.parametrize("transport_class,transport_name", [
    (transports.ModelMonitoringServiceGrpcTransport, "grpc"),
    (transports.ModelMonitoringServiceGrpcAsyncIOTransport, "grpc_asyncio"),
    (transports.ModelMonitoringServiceRestTransport, "rest"),
])
def test_model_monitoring_service_client_service_account_always_use_jwt(transport_class, transport_name):
    with mock.patch.object(service_account.Credentials, 'with_always_use_jwt_access', create=True) as use_jwt:
        creds = service_account.Credentials(None, None, None)
        transport = transport_class(credentials=creds, always_use_jwt_access=True)
        use_jwt.assert_called_once_with(True)

    with mock.patch.object(service_account.Credentials, 'with_always_use_jwt_access', create=True) as use_jwt:
        creds = service_account.Credentials(None, None, None)
        transport = transport_class(credentials=creds, always_use_jwt_access=False)
        use_jwt.assert_not_called()


@pytest.mark.parametrize("client_class,transport_name", [
    (ModelMonitoringServiceClient, "grpc"),
    (ModelMonitoringServiceAsyncClient, "grpc_asyncio"),
    (ModelMonitoringServiceClient, "rest"),
])
def test_model_monitoring_service_client_from_service_account_file(client_class, transport_name):
    creds = ga_credentials.AnonymousCredentials()
    with mock.patch.object(service_account.Credentials, 'from_service_account_file') as factory:
        factory.return_value = creds
        client = client_class.from_service_account_file("dummy/file/path.json", transport=transport_name)
        assert client.transport._credentials == creds
        assert isinstance(client, client_class)

        client = client_class.from_service_account_json("dummy/file/path.json", transport=transport_name)
        assert client.transport._credentials == creds
        assert isinstance(client, client_class)

        assert client.transport._host == (
            'aiplatform.googleapis.com:443'
            if transport_name in ['grpc', 'grpc_asyncio']
            else
            'https://aiplatform.googleapis.com'
        )


def test_model_monitoring_service_client_get_transport_class():
    transport = ModelMonitoringServiceClient.get_transport_class()
    available_transports = [
        transports.ModelMonitoringServiceGrpcTransport,
        transports.ModelMonitoringServiceRestTransport,
    ]
    assert transport in available_transports

    transport = ModelMonitoringServiceClient.get_transport_class("grpc")
    assert transport == transports.ModelMonitoringServiceGrpcTransport


@pytest.mark.parametrize("client_class,transport_class,transport_name", [
    (ModelMonitoringServiceClient, transports.ModelMonitoringServiceGrpcTransport, "grpc"),
    (ModelMonitoringServiceAsyncClient, transports.ModelMonitoringServiceGrpcAsyncIOTransport, "grpc_asyncio"),
    (ModelMonitoringServiceClient, transports.ModelMonitoringServiceRestTransport, "rest"),
])
@mock.patch.object(ModelMonitoringServiceClient, "_DEFAULT_ENDPOINT_TEMPLATE", modify_default_endpoint_template(ModelMonitoringServiceClient))
@mock.patch.object(ModelMonitoringServiceAsyncClient, "_DEFAULT_ENDPOINT_TEMPLATE", modify_default_endpoint_template(ModelMonitoringServiceAsyncClient))
def test_model_monitoring_service_client_client_options(client_class, transport_class, transport_name):
    # Check that if channel is provided we won't create a new one.
    with mock.patch.object(ModelMonitoringServiceClient, 'get_transport_class') as gtc:
        transport = transport_class(
            credentials=ga_credentials.AnonymousCredentials()
        )
        client = client_class(transport=transport)
        gtc.assert_not_called()

    # Check that if channel is provided via str we will create a new one.
    with mock.patch.object(ModelMonitoringServiceClient, 'get_transport_class') as gtc:
        client = client_class(transport=transport_name)
        gtc.assert_called()

    # Check the case api_endpoint is provided.
    options = client_options.ClientOptions(api_endpoint="squid.clam.whelk")
    with mock.patch.object(transport_class, '__init__') as patched:
        patched.return_value = None
        client = client_class(transport=transport_name, client_options=options)
        patched.assert_called_once_with(
            credentials=None,
            credentials_file=None,
            host="squid.clam.whelk",
            scopes=None,
            client_cert_source_for_mtls=None,
            quota_project_id=None,
            client_info=transports.base.DEFAULT_CLIENT_INFO,
            always_use_jwt_access=True,
            api_audience=None,
        )

    # Check the case api_endpoint is not provided and GOOGLE_API_USE_MTLS_ENDPOINT is
    # "never".
    with mock.patch.dict(os.environ, {"GOOGLE_API_USE_MTLS_ENDPOINT": "never"}):
        with mock.patch.object(transport_class, '__init__') as patched:
            patched.return_value = None
            client = client_class(transport=transport_name)
            patched.assert_called_once_with(
                credentials=None,
                credentials_file=None,
                host=client._DEFAULT_ENDPOINT_TEMPLATE.format(UNIVERSE_DOMAIN=client._DEFAULT_UNIVERSE),
                scopes=None,
                client_cert_source_for_mtls=None,
                quota_project_id=None,
                client_info=transports.base.DEFAULT_CLIENT_INFO,
                always_use_jwt_access=True,
                api_audience=None,
            )

    # Check the case api_endpoint is not provided and GOOGLE_API_USE_MTLS_ENDPOINT is
    # "always".
    with mock.patch.dict(os.environ, {"GOOGLE_API_USE_MTLS_ENDPOINT": "always"}):
        with mock.patch.object(transport_class, '__init__') as patched:
            patched.return_value = None
            client = client_class(transport=transport_name)
            patched.assert_called_once_with(
                credentials=None,
                credentials_file=None,
                host=client.DEFAULT_MTLS_ENDPOINT,
                scopes=None,
                client_cert_source_for_mtls=None,
                quota_project_id=None,
                client_info=transports.base.DEFAULT_CLIENT_INFO,
                always_use_jwt_access=True,
                api_audience=None,
            )

    # Check the case api_endpoint is not provided and GOOGLE_API_USE_MTLS_ENDPOINT has
    # unsupported value.
    with mock.patch.dict(os.environ, {"GOOGLE_API_USE_MTLS_ENDPOINT": "Unsupported"}):
        with pytest.raises(MutualTLSChannelError) as excinfo:
            client = client_class(transport=transport_name)
    assert str(excinfo.value) == "Environment variable `GOOGLE_API_USE_MTLS_ENDPOINT` must be `never`, `auto` or `always`"

    # Check the case GOOGLE_API_USE_CLIENT_CERTIFICATE has unsupported value.
    with mock.patch.dict(os.environ, {"GOOGLE_API_USE_CLIENT_CERTIFICATE": "Unsupported"}):
        with pytest.raises(ValueError) as excinfo:
            client = client_class(transport=transport_name)
    assert str(excinfo.value) == "Environment variable `GOOGLE_API_USE_CLIENT_CERTIFICATE` must be either `true` or `false`"

    # Check the case quota_project_id is provided
    options = client_options.ClientOptions(quota_project_id="octopus")
    with mock.patch.object(transport_class, '__init__') as patched:
        patched.return_value = None
        client = client_class(client_options=options, transport=transport_name)
        patched.assert_called_once_with(
            credentials=None,
            credentials_file=None,
            host=client._DEFAULT_ENDPOINT_TEMPLATE.format(UNIVERSE_DOMAIN=client._DEFAULT_UNIVERSE),
            scopes=None,
            client_cert_source_for_mtls=None,
            quota_project_id="octopus",
            client_info=transports.base.DEFAULT_CLIENT_INFO,
            always_use_jwt_access=True,
            api_audience=None,
        )
    # Check the case api_endpoint is provided
    options = client_options.ClientOptions(api_audience="https://language.googleapis.com")
    with mock.patch.object(transport_class, '__init__') as patched:
        patched.return_value = None
        client = client_class(client_options=options, transport=transport_name)
        patched.assert_called_once_with(
            credentials=None,
            credentials_file=None,
            host=client._DEFAULT_ENDPOINT_TEMPLATE.format(UNIVERSE_DOMAIN=client._DEFAULT_UNIVERSE),
            scopes=None,
            client_cert_source_for_mtls=None,
            quota_project_id=None,
            client_info=transports.base.DEFAULT_CLIENT_INFO,
            always_use_jwt_access=True,
            api_audience="https://language.googleapis.com"
        )

@pytest.mark.parametrize("client_class,transport_class,transport_name,use_client_cert_env", [
    (ModelMonitoringServiceClient, transports.ModelMonitoringServiceGrpcTransport, "grpc", "true"),
    (ModelMonitoringServiceAsyncClient, transports.ModelMonitoringServiceGrpcAsyncIOTransport, "grpc_asyncio", "true"),
    (ModelMonitoringServiceClient, transports.ModelMonitoringServiceGrpcTransport, "grpc", "false"),
    (ModelMonitoringServiceAsyncClient, transports.ModelMonitoringServiceGrpcAsyncIOTransport, "grpc_asyncio", "false"),
    (ModelMonitoringServiceClient, transports.ModelMonitoringServiceRestTransport, "rest", "true"),
    (ModelMonitoringServiceClient, transports.ModelMonitoringServiceRestTransport, "rest", "false"),
])
@mock.patch.object(ModelMonitoringServiceClient, "_DEFAULT_ENDPOINT_TEMPLATE", modify_default_endpoint_template(ModelMonitoringServiceClient))
@mock.patch.object(ModelMonitoringServiceAsyncClient, "_DEFAULT_ENDPOINT_TEMPLATE", modify_default_endpoint_template(ModelMonitoringServiceAsyncClient))
@mock.patch.dict(os.environ, {"GOOGLE_API_USE_MTLS_ENDPOINT": "auto"})
def test_model_monitoring_service_client_mtls_env_auto(client_class, transport_class, transport_name, use_client_cert_env):
    # This tests the endpoint autoswitch behavior. Endpoint is autoswitched to the default
    # mtls endpoint, if GOOGLE_API_USE_CLIENT_CERTIFICATE is "true" and client cert exists.

    # Check the case client_cert_source is provided. Whether client cert is used depends on
    # GOOGLE_API_USE_CLIENT_CERTIFICATE value.
    with mock.patch.dict(os.environ, {"GOOGLE_API_USE_CLIENT_CERTIFICATE": use_client_cert_env}):
        options = client_options.ClientOptions(client_cert_source=client_cert_source_callback)
        with mock.patch.object(transport_class, '__init__') as patched:
            patched.return_value = None
            client = client_class(client_options=options, transport=transport_name)

            if use_client_cert_env == "false":
                expected_client_cert_source = None
                expected_host = client._DEFAULT_ENDPOINT_TEMPLATE.format(UNIVERSE_DOMAIN=client._DEFAULT_UNIVERSE)
            else:
                expected_client_cert_source = client_cert_source_callback
                expected_host = client.DEFAULT_MTLS_ENDPOINT

            patched.assert_called_once_with(
                credentials=None,
                credentials_file=None,
                host=expected_host,
                scopes=None,
                client_cert_source_for_mtls=expected_client_cert_source,
                quota_project_id=None,
                client_info=transports.base.DEFAULT_CLIENT_INFO,
                always_use_jwt_access=True,
                api_audience=None,
            )

    # Check the case ADC client cert is provided. Whether client cert is used depends on
    # GOOGLE_API_USE_CLIENT_CERTIFICATE value.
    with mock.patch.dict(os.environ, {"GOOGLE_API_USE_CLIENT_CERTIFICATE": use_client_cert_env}):
        with mock.patch.object(transport_class, '__init__') as patched:
            with mock.patch('google.auth.transport.mtls.has_default_client_cert_source', return_value=True):
                with mock.patch('google.auth.transport.mtls.default_client_cert_source', return_value=client_cert_source_callback):
                    if use_client_cert_env == "false":
                        expected_host = client._DEFAULT_ENDPOINT_TEMPLATE.format(UNIVERSE_DOMAIN=client._DEFAULT_UNIVERSE)
                        expected_client_cert_source = None
                    else:
                        expected_host = client.DEFAULT_MTLS_ENDPOINT
                        expected_client_cert_source = client_cert_source_callback

                    patched.return_value = None
                    client = client_class(transport=transport_name)
                    patched.assert_called_once_with(
                        credentials=None,
                        credentials_file=None,
                        host=expected_host,
                        scopes=None,
                        client_cert_source_for_mtls=expected_client_cert_source,
                        quota_project_id=None,
                        client_info=transports.base.DEFAULT_CLIENT_INFO,
                        always_use_jwt_access=True,
                        api_audience=None,
                    )

    # Check the case client_cert_source and ADC client cert are not provided.
    with mock.patch.dict(os.environ, {"GOOGLE_API_USE_CLIENT_CERTIFICATE": use_client_cert_env}):
        with mock.patch.object(transport_class, '__init__') as patched:
            with mock.patch("google.auth.transport.mtls.has_default_client_cert_source", return_value=False):
                patched.return_value = None
                client = client_class(transport=transport_name)
                patched.assert_called_once_with(
                    credentials=None,
                    credentials_file=None,
                    host=client._DEFAULT_ENDPOINT_TEMPLATE.format(UNIVERSE_DOMAIN=client._DEFAULT_UNIVERSE),
                    scopes=None,
                    client_cert_source_for_mtls=None,
                    quota_project_id=None,
                    client_info=transports.base.DEFAULT_CLIENT_INFO,
                    always_use_jwt_access=True,
                    api_audience=None,
                )


@pytest.mark.parametrize("client_class", [
    ModelMonitoringServiceClient, ModelMonitoringServiceAsyncClient
])
@mock.patch.object(ModelMonitoringServiceClient, "DEFAULT_ENDPOINT", modify_default_endpoint(ModelMonitoringServiceClient))
@mock.patch.object(ModelMonitoringServiceAsyncClient, "DEFAULT_ENDPOINT", modify_default_endpoint(ModelMonitoringServiceAsyncClient))
def test_model_monitoring_service_client_get_mtls_endpoint_and_cert_source(client_class):
    mock_client_cert_source = mock.Mock()

    # Test the case GOOGLE_API_USE_CLIENT_CERTIFICATE is "true".
    with mock.patch.dict(os.environ, {"GOOGLE_API_USE_CLIENT_CERTIFICATE": "true"}):
        mock_api_endpoint = "foo"
        options = client_options.ClientOptions(client_cert_source=mock_client_cert_source, api_endpoint=mock_api_endpoint)
        api_endpoint, cert_source = client_class.get_mtls_endpoint_and_cert_source(options)
        assert api_endpoint == mock_api_endpoint
        assert cert_source == mock_client_cert_source

    # Test the case GOOGLE_API_USE_CLIENT_CERTIFICATE is "false".
    with mock.patch.dict(os.environ, {"GOOGLE_API_USE_CLIENT_CERTIFICATE": "false"}):
        mock_client_cert_source = mock.Mock()
        mock_api_endpoint = "foo"
        options = client_options.ClientOptions(client_cert_source=mock_client_cert_source, api_endpoint=mock_api_endpoint)
        api_endpoint, cert_source = client_class.get_mtls_endpoint_and_cert_source(options)
        assert api_endpoint == mock_api_endpoint
        assert cert_source is None

    # Test the case GOOGLE_API_USE_MTLS_ENDPOINT is "never".
    with mock.patch.dict(os.environ, {"GOOGLE_API_USE_MTLS_ENDPOINT": "never"}):
        api_endpoint, cert_source = client_class.get_mtls_endpoint_and_cert_source()
        assert api_endpoint == client_class.DEFAULT_ENDPOINT
        assert cert_source is None

    # Test the case GOOGLE_API_USE_MTLS_ENDPOINT is "always".
    with mock.patch.dict(os.environ, {"GOOGLE_API_USE_MTLS_ENDPOINT": "always"}):
        api_endpoint, cert_source = client_class.get_mtls_endpoint_and_cert_source()
        assert api_endpoint == client_class.DEFAULT_MTLS_ENDPOINT
        assert cert_source is None

    # Test the case GOOGLE_API_USE_MTLS_ENDPOINT is "auto" and default cert doesn't exist.
    with mock.patch.dict(os.environ, {"GOOGLE_API_USE_CLIENT_CERTIFICATE": "true"}):
        with mock.patch('google.auth.transport.mtls.has_default_client_cert_source', return_value=False):
            api_endpoint, cert_source = client_class.get_mtls_endpoint_and_cert_source()
            assert api_endpoint == client_class.DEFAULT_ENDPOINT
            assert cert_source is None

    # Test the case GOOGLE_API_USE_MTLS_ENDPOINT is "auto" and default cert exists.
    with mock.patch.dict(os.environ, {"GOOGLE_API_USE_CLIENT_CERTIFICATE": "true"}):
        with mock.patch('google.auth.transport.mtls.has_default_client_cert_source', return_value=True):
            with mock.patch('google.auth.transport.mtls.default_client_cert_source', return_value=mock_client_cert_source):
                api_endpoint, cert_source = client_class.get_mtls_endpoint_and_cert_source()
                assert api_endpoint == client_class.DEFAULT_MTLS_ENDPOINT
                assert cert_source == mock_client_cert_source

    # Check the case api_endpoint is not provided and GOOGLE_API_USE_MTLS_ENDPOINT has
    # unsupported value.
    with mock.patch.dict(os.environ, {"GOOGLE_API_USE_MTLS_ENDPOINT": "Unsupported"}):
        with pytest.raises(MutualTLSChannelError) as excinfo:
            client_class.get_mtls_endpoint_and_cert_source()

        assert str(excinfo.value) == "Environment variable `GOOGLE_API_USE_MTLS_ENDPOINT` must be `never`, `auto` or `always`"

    # Check the case GOOGLE_API_USE_CLIENT_CERTIFICATE has unsupported value.
    with mock.patch.dict(os.environ, {"GOOGLE_API_USE_CLIENT_CERTIFICATE": "Unsupported"}):
        with pytest.raises(ValueError) as excinfo:
            client_class.get_mtls_endpoint_and_cert_source()

        assert str(excinfo.value) == "Environment variable `GOOGLE_API_USE_CLIENT_CERTIFICATE` must be either `true` or `false`"

@pytest.mark.parametrize("client_class", [
    ModelMonitoringServiceClient, ModelMonitoringServiceAsyncClient
])
@mock.patch.object(ModelMonitoringServiceClient, "_DEFAULT_ENDPOINT_TEMPLATE", modify_default_endpoint_template(ModelMonitoringServiceClient))
@mock.patch.object(ModelMonitoringServiceAsyncClient, "_DEFAULT_ENDPOINT_TEMPLATE", modify_default_endpoint_template(ModelMonitoringServiceAsyncClient))
def test_model_monitoring_service_client_client_api_endpoint(client_class):
    mock_client_cert_source = client_cert_source_callback
    api_override = "foo.com"
    default_universe = ModelMonitoringServiceClient._DEFAULT_UNIVERSE
    default_endpoint = ModelMonitoringServiceClient._DEFAULT_ENDPOINT_TEMPLATE.format(UNIVERSE_DOMAIN=default_universe)
    mock_universe = "bar.com"
    mock_endpoint = ModelMonitoringServiceClient._DEFAULT_ENDPOINT_TEMPLATE.format(UNIVERSE_DOMAIN=mock_universe)

    # If ClientOptions.api_endpoint is set and GOOGLE_API_USE_CLIENT_CERTIFICATE="true",
    # use ClientOptions.api_endpoint as the api endpoint regardless.
    with mock.patch.dict(os.environ, {"GOOGLE_API_USE_CLIENT_CERTIFICATE": "true"}):
        with mock.patch("google.auth.transport.requests.AuthorizedSession.configure_mtls_channel"):
            options = client_options.ClientOptions(client_cert_source=mock_client_cert_source, api_endpoint=api_override)
            client = client_class(client_options=options, credentials=ga_credentials.AnonymousCredentials())
            assert client.api_endpoint == api_override

    # If ClientOptions.api_endpoint is not set and GOOGLE_API_USE_MTLS_ENDPOINT="never",
    # use the _DEFAULT_ENDPOINT_TEMPLATE populated with GDU as the api endpoint.
    with mock.patch.dict(os.environ, {"GOOGLE_API_USE_MTLS_ENDPOINT": "never"}):
        client = client_class(credentials=ga_credentials.AnonymousCredentials())
        assert client.api_endpoint == default_endpoint

    # If ClientOptions.api_endpoint is not set and GOOGLE_API_USE_MTLS_ENDPOINT="always",
    # use the DEFAULT_MTLS_ENDPOINT as the api endpoint.
    with mock.patch.dict(os.environ, {"GOOGLE_API_USE_MTLS_ENDPOINT": "always"}):
        client = client_class(credentials=ga_credentials.AnonymousCredentials())
        assert client.api_endpoint == client_class.DEFAULT_MTLS_ENDPOINT

    # If ClientOptions.api_endpoint is not set, GOOGLE_API_USE_MTLS_ENDPOINT="auto" (default),
    # GOOGLE_API_USE_CLIENT_CERTIFICATE="false" (default), default cert source doesn't exist,
    # and ClientOptions.universe_domain="bar.com",
    # use the _DEFAULT_ENDPOINT_TEMPLATE populated with universe domain as the api endpoint.
    options = client_options.ClientOptions()
    universe_exists = hasattr(options, "universe_domain")
    if universe_exists:
        options = client_options.ClientOptions(universe_domain=mock_universe)
        client = client_class(client_options=options, credentials=ga_credentials.AnonymousCredentials())
    else:
        client = client_class(client_options=options, credentials=ga_credentials.AnonymousCredentials())
    assert client.api_endpoint == (mock_endpoint if universe_exists else default_endpoint)
    assert client.universe_domain == (mock_universe if universe_exists else default_universe)

    # If ClientOptions does not have a universe domain attribute and GOOGLE_API_USE_MTLS_ENDPOINT="never",
    # use the _DEFAULT_ENDPOINT_TEMPLATE populated with GDU as the api endpoint.
    options = client_options.ClientOptions()
    if hasattr(options, "universe_domain"):
        delattr(options, "universe_domain")
    with mock.patch.dict(os.environ, {"GOOGLE_API_USE_MTLS_ENDPOINT": "never"}):
        client = client_class(client_options=options, credentials=ga_credentials.AnonymousCredentials())
        assert client.api_endpoint == default_endpoint


@pytest.mark.parametrize("client_class,transport_class,transport_name", [
    (ModelMonitoringServiceClient, transports.ModelMonitoringServiceGrpcTransport, "grpc"),
    (ModelMonitoringServiceAsyncClient, transports.ModelMonitoringServiceGrpcAsyncIOTransport, "grpc_asyncio"),
    (ModelMonitoringServiceClient, transports.ModelMonitoringServiceRestTransport, "rest"),
])
def test_model_monitoring_service_client_client_options_scopes(client_class, transport_class, transport_name):
    # Check the case scopes are provided.
    options = client_options.ClientOptions(
        scopes=["1", "2"],
    )
    with mock.patch.object(transport_class, '__init__') as patched:
        patched.return_value = None
        client = client_class(client_options=options, transport=transport_name)
        patched.assert_called_once_with(
            credentials=None,
            credentials_file=None,
            host=client._DEFAULT_ENDPOINT_TEMPLATE.format(UNIVERSE_DOMAIN=client._DEFAULT_UNIVERSE),
            scopes=["1", "2"],
            client_cert_source_for_mtls=None,
            quota_project_id=None,
            client_info=transports.base.DEFAULT_CLIENT_INFO,
            always_use_jwt_access=True,
            api_audience=None,
        )

@pytest.mark.parametrize("client_class,transport_class,transport_name,grpc_helpers", [
    (ModelMonitoringServiceClient, transports.ModelMonitoringServiceGrpcTransport, "grpc", grpc_helpers),
    (ModelMonitoringServiceAsyncClient, transports.ModelMonitoringServiceGrpcAsyncIOTransport, "grpc_asyncio", grpc_helpers_async),
    (ModelMonitoringServiceClient, transports.ModelMonitoringServiceRestTransport, "rest", None),
])
def test_model_monitoring_service_client_client_options_credentials_file(client_class, transport_class, transport_name, grpc_helpers):
    # Check the case credentials file is provided.
    options = client_options.ClientOptions(
        credentials_file="credentials.json"
    )

    with mock.patch.object(transport_class, '__init__') as patched:
        patched.return_value = None
        client = client_class(client_options=options, transport=transport_name)
        patched.assert_called_once_with(
            credentials=None,
            credentials_file="credentials.json",
            host=client._DEFAULT_ENDPOINT_TEMPLATE.format(UNIVERSE_DOMAIN=client._DEFAULT_UNIVERSE),
            scopes=None,
            client_cert_source_for_mtls=None,
            quota_project_id=None,
            client_info=transports.base.DEFAULT_CLIENT_INFO,
            always_use_jwt_access=True,
            api_audience=None,
        )

def test_model_monitoring_service_client_client_options_from_dict():
    with mock.patch('google.cloud.aiplatform_v1beta1.services.model_monitoring_service.transports.ModelMonitoringServiceGrpcTransport.__init__') as grpc_transport:
        grpc_transport.return_value = None
        client = ModelMonitoringServiceClient(
            client_options={'api_endpoint': 'squid.clam.whelk'}
        )
        grpc_transport.assert_called_once_with(
            credentials=None,
            credentials_file=None,
            host="squid.clam.whelk",
            scopes=None,
            client_cert_source_for_mtls=None,
            quota_project_id=None,
            client_info=transports.base.DEFAULT_CLIENT_INFO,
            always_use_jwt_access=True,
            api_audience=None,
        )


@pytest.mark.parametrize("client_class,transport_class,transport_name,grpc_helpers", [
    (ModelMonitoringServiceClient, transports.ModelMonitoringServiceGrpcTransport, "grpc", grpc_helpers),
    (ModelMonitoringServiceAsyncClient, transports.ModelMonitoringServiceGrpcAsyncIOTransport, "grpc_asyncio", grpc_helpers_async),
])
def test_model_monitoring_service_client_create_channel_credentials_file(client_class, transport_class, transport_name, grpc_helpers):
    # Check the case credentials file is provided.
    options = client_options.ClientOptions(
        credentials_file="credentials.json"
    )

    with mock.patch.object(transport_class, '__init__') as patched:
        patched.return_value = None
        client = client_class(client_options=options, transport=transport_name)
        patched.assert_called_once_with(
            credentials=None,
            credentials_file="credentials.json",
            host=client._DEFAULT_ENDPOINT_TEMPLATE.format(UNIVERSE_DOMAIN=client._DEFAULT_UNIVERSE),
            scopes=None,
            client_cert_source_for_mtls=None,
            quota_project_id=None,
            client_info=transports.base.DEFAULT_CLIENT_INFO,
            always_use_jwt_access=True,
            api_audience=None,
        )

    # test that the credentials from file are saved and used as the credentials.
    with mock.patch.object(
        google.auth, "load_credentials_from_file", autospec=True
    ) as load_creds, mock.patch.object(
        google.auth, "default", autospec=True
    ) as adc, mock.patch.object(
        grpc_helpers, "create_channel"
    ) as create_channel:
        creds = ga_credentials.AnonymousCredentials()
        file_creds = ga_credentials.AnonymousCredentials()
        load_creds.return_value = (file_creds, None)
        adc.return_value = (creds, None)
        client = client_class(client_options=options, transport=transport_name)
        create_channel.assert_called_with(
            "aiplatform.googleapis.com:443",
            credentials=file_creds,
            credentials_file=None,
            quota_project_id=None,
            default_scopes=(
                'https://www.googleapis.com/auth/cloud-platform',
),
            scopes=None,
            default_host="aiplatform.googleapis.com",
            ssl_credentials=None,
            options=[
                ("grpc.max_send_message_length", -1),
                ("grpc.max_receive_message_length", -1),
            ],
        )


@pytest.mark.parametrize("request_type", [
  model_monitoring_service.CreateModelMonitorRequest,
  dict,
])
def test_create_model_monitor(request_type, transport: str = 'grpc'):
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport=transport,
    )

    # Everything is optional in proto3 as far as the runtime is concerned,
    # and we are mocking out the actual API, so just send an empty request.
    request = request_type()

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
            type(client.transport.create_model_monitor),
            '__call__') as call:
        # Designate an appropriate return value for the call.
        call.return_value = operations_pb2.Operation(name='operations/spam')
        response = client.create_model_monitor(request)

        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls) == 1
        _, args, _ = call.mock_calls[0]
        request = model_monitoring_service.CreateModelMonitorRequest()
        assert args[0] == request

    # Establish that the response is the type that we expect.
    assert isinstance(response, future.Future)


def test_create_model_monitor_non_empty_request_with_auto_populated_field():
    # This test is a coverage failsafe to make sure that UUID4 fields are
    # automatically populated, according to AIP-4235, with non-empty requests.
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport='grpc',
    )

    # Populate all string fields in the request which are not UUID4
    # since we want to check that UUID4 are populated automatically
    # if they meet the requirements of AIP 4235.
    request = model_monitoring_service.CreateModelMonitorRequest(
        parent='parent_value',
        model_monitor_id='model_monitor_id_value',
    )

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
            type(client.transport.create_model_monitor),
            '__call__') as call:
        call.return_value.name = "foo" # operation_request.operation in compute client(s) expect a string.
        client.create_model_monitor(request=request)
        call.assert_called()
        _, args, _ = call.mock_calls[0]
        assert args[0] == model_monitoring_service.CreateModelMonitorRequest(
            parent='parent_value',
            model_monitor_id='model_monitor_id_value',
        )

def test_create_model_monitor_use_cached_wrapped_rpc():
    # Clients should use _prep_wrapped_messages to create cached wrapped rpcs,
    # instead of constructing them on each call
    with mock.patch("google.api_core.gapic_v1.method.wrap_method") as wrapper_fn:
        client = ModelMonitoringServiceClient(
            credentials=ga_credentials.AnonymousCredentials(),
            transport="grpc",
        )

        # Should wrap all calls on client creation
        assert wrapper_fn.call_count > 0
        wrapper_fn.reset_mock()

        # Ensure method has been cached
        assert client._transport.create_model_monitor in client._transport._wrapped_methods

        # Replace cached wrapped function with mock
        mock_rpc = mock.Mock()
        mock_rpc.return_value.name = "foo" # operation_request.operation in compute client(s) expect a string.
        client._transport._wrapped_methods[client._transport.create_model_monitor] = mock_rpc
        request = {}
        client.create_model_monitor(request)

        # Establish that the underlying gRPC stub method was called.
        assert mock_rpc.call_count == 1

        # Operation methods call wrapper_fn to build a cached
        # client._transport.operations_client instance on first rpc call.
        # Subsequent calls should use the cached wrapper
        wrapper_fn.reset_mock()

        client.create_model_monitor(request)

        # Establish that a new wrapper was not created for this call
        assert wrapper_fn.call_count == 0
        assert mock_rpc.call_count == 2

@pytest.mark.asyncio
async def test_create_model_monitor_async_use_cached_wrapped_rpc(transport: str = "grpc_asyncio"):
    # Clients should use _prep_wrapped_messages to create cached wrapped rpcs,
    # instead of constructing them on each call
    with mock.patch("google.api_core.gapic_v1.method_async.wrap_method") as wrapper_fn:
        client = ModelMonitoringServiceAsyncClient(
            credentials=async_anonymous_credentials(),
            transport=transport,
        )

        # Should wrap all calls on client creation
        assert wrapper_fn.call_count > 0
        wrapper_fn.reset_mock()

        # Ensure method has been cached
        assert client._client._transport.create_model_monitor in client._client._transport._wrapped_methods

        # Replace cached wrapped function with mock
        mock_rpc = mock.AsyncMock()
        mock_rpc.return_value = mock.Mock()
        client._client._transport._wrapped_methods[client._client._transport.create_model_monitor] = mock_rpc

        request = {}
        await client.create_model_monitor(request)

        # Establish that the underlying gRPC stub method was called.
        assert mock_rpc.call_count == 1

        # Operation methods call wrapper_fn to build a cached
        # client._transport.operations_client instance on first rpc call.
        # Subsequent calls should use the cached wrapper
        wrapper_fn.reset_mock()

        await client.create_model_monitor(request)

        # Establish that a new wrapper was not created for this call
        assert wrapper_fn.call_count == 0
        assert mock_rpc.call_count == 2

@pytest.mark.asyncio
async def test_create_model_monitor_async(transport: str = 'grpc_asyncio', request_type=model_monitoring_service.CreateModelMonitorRequest):
    client = ModelMonitoringServiceAsyncClient(
        credentials=async_anonymous_credentials(),
        transport=transport,
    )

    # Everything is optional in proto3 as far as the runtime is concerned,
    # and we are mocking out the actual API, so just send an empty request.
    request = request_type()

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
            type(client.transport.create_model_monitor),
            '__call__') as call:
        # Designate an appropriate return value for the call.
        call.return_value = grpc_helpers_async.FakeUnaryUnaryCall(
            operations_pb2.Operation(name='operations/spam')
        )
        response = await client.create_model_monitor(request)

        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls)
        _, args, _ = call.mock_calls[0]
        request = model_monitoring_service.CreateModelMonitorRequest()
        assert args[0] == request

    # Establish that the response is the type that we expect.
    assert isinstance(response, future.Future)


@pytest.mark.asyncio
async def test_create_model_monitor_async_from_dict():
    await test_create_model_monitor_async(request_type=dict)

def test_create_model_monitor_field_headers():
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
    )

    # Any value that is part of the HTTP/1.1 URI should be sent as
    # a field header. Set these to a non-empty value.
    request = model_monitoring_service.CreateModelMonitorRequest()

    request.parent = 'parent_value'

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
            type(client.transport.create_model_monitor),
            '__call__') as call:
        call.return_value = operations_pb2.Operation(name='operations/op')
        client.create_model_monitor(request)

        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls) == 1
        _, args, _ = call.mock_calls[0]
        assert args[0] == request

    # Establish that the field header was sent.
    _, _, kw = call.mock_calls[0]
    assert (
        'x-goog-request-params',
        'parent=parent_value',
    ) in kw['metadata']


@pytest.mark.asyncio
async def test_create_model_monitor_field_headers_async():
    client = ModelMonitoringServiceAsyncClient(
        credentials=async_anonymous_credentials(),
    )

    # Any value that is part of the HTTP/1.1 URI should be sent as
    # a field header. Set these to a non-empty value.
    request = model_monitoring_service.CreateModelMonitorRequest()

    request.parent = 'parent_value'

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
            type(client.transport.create_model_monitor),
            '__call__') as call:
        call.return_value = grpc_helpers_async.FakeUnaryUnaryCall(operations_pb2.Operation(name='operations/op'))
        await client.create_model_monitor(request)

        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls)
        _, args, _ = call.mock_calls[0]
        assert args[0] == request

    # Establish that the field header was sent.
    _, _, kw = call.mock_calls[0]
    assert (
        'x-goog-request-params',
        'parent=parent_value',
    ) in kw['metadata']


def test_create_model_monitor_flattened():
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
    )

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
            type(client.transport.create_model_monitor),
            '__call__') as call:
        # Designate an appropriate return value for the call.
        call.return_value = operations_pb2.Operation(name='operations/op')
        # Call the method with a truthy value for each flattened field,
        # using the keyword arguments to the method.
        client.create_model_monitor(
            parent='parent_value',
            model_monitor=gca_model_monitor.ModelMonitor(tabular_objective=model_monitoring_spec.ModelMonitoringObjectiveSpec.TabularObjective(feature_drift_spec=model_monitoring_spec.ModelMonitoringObjectiveSpec.DataDriftSpec(features=['features_value']))),
        )

        # Establish that the underlying call was made with the expected
        # request object values.
        assert len(call.mock_calls) == 1
        _, args, _ = call.mock_calls[0]
        arg = args[0].parent
        mock_val = 'parent_value'
        assert arg == mock_val
        arg = args[0].model_monitor
        mock_val = gca_model_monitor.ModelMonitor(tabular_objective=model_monitoring_spec.ModelMonitoringObjectiveSpec.TabularObjective(feature_drift_spec=model_monitoring_spec.ModelMonitoringObjectiveSpec.DataDriftSpec(features=['features_value'])))
        assert arg == mock_val


def test_create_model_monitor_flattened_error():
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
    )

    # Attempting to call a method with both a request object and flattened
    # fields is an error.
    with pytest.raises(ValueError):
        client.create_model_monitor(
            model_monitoring_service.CreateModelMonitorRequest(),
            parent='parent_value',
            model_monitor=gca_model_monitor.ModelMonitor(tabular_objective=model_monitoring_spec.ModelMonitoringObjectiveSpec.TabularObjective(feature_drift_spec=model_monitoring_spec.ModelMonitoringObjectiveSpec.DataDriftSpec(features=['features_value']))),
        )

@pytest.mark.asyncio
async def test_create_model_monitor_flattened_async():
    client = ModelMonitoringServiceAsyncClient(
        credentials=async_anonymous_credentials(),
    )

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
            type(client.transport.create_model_monitor),
            '__call__') as call:
        # Designate an appropriate return value for the call.
        call.return_value = operations_pb2.Operation(name='operations/op')

        call.return_value = grpc_helpers_async.FakeUnaryUnaryCall(
            operations_pb2.Operation(name='operations/spam')
        )
        # Call the method with a truthy value for each flattened field,
        # using the keyword arguments to the method.
        response = await client.create_model_monitor(
            parent='parent_value',
            model_monitor=gca_model_monitor.ModelMonitor(tabular_objective=model_monitoring_spec.ModelMonitoringObjectiveSpec.TabularObjective(feature_drift_spec=model_monitoring_spec.ModelMonitoringObjectiveSpec.DataDriftSpec(features=['features_value']))),
        )

        # Establish that the underlying call was made with the expected
        # request object values.
        assert len(call.mock_calls)
        _, args, _ = call.mock_calls[0]
        arg = args[0].parent
        mock_val = 'parent_value'
        assert arg == mock_val
        arg = args[0].model_monitor
        mock_val = gca_model_monitor.ModelMonitor(tabular_objective=model_monitoring_spec.ModelMonitoringObjectiveSpec.TabularObjective(feature_drift_spec=model_monitoring_spec.ModelMonitoringObjectiveSpec.DataDriftSpec(features=['features_value'])))
        assert arg == mock_val

@pytest.mark.asyncio
async def test_create_model_monitor_flattened_error_async():
    client = ModelMonitoringServiceAsyncClient(
        credentials=async_anonymous_credentials(),
    )

    # Attempting to call a method with both a request object and flattened
    # fields is an error.
    with pytest.raises(ValueError):
        await client.create_model_monitor(
            model_monitoring_service.CreateModelMonitorRequest(),
            parent='parent_value',
            model_monitor=gca_model_monitor.ModelMonitor(tabular_objective=model_monitoring_spec.ModelMonitoringObjectiveSpec.TabularObjective(feature_drift_spec=model_monitoring_spec.ModelMonitoringObjectiveSpec.DataDriftSpec(features=['features_value']))),
        )


@pytest.mark.parametrize("request_type", [
  model_monitoring_service.UpdateModelMonitorRequest,
  dict,
])
def test_update_model_monitor(request_type, transport: str = 'grpc'):
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport=transport,
    )

    # Everything is optional in proto3 as far as the runtime is concerned,
    # and we are mocking out the actual API, so just send an empty request.
    request = request_type()

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
            type(client.transport.update_model_monitor),
            '__call__') as call:
        # Designate an appropriate return value for the call.
        call.return_value = operations_pb2.Operation(name='operations/spam')
        response = client.update_model_monitor(request)

        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls) == 1
        _, args, _ = call.mock_calls[0]
        request = model_monitoring_service.UpdateModelMonitorRequest()
        assert args[0] == request

    # Establish that the response is the type that we expect.
    assert isinstance(response, future.Future)


def test_update_model_monitor_non_empty_request_with_auto_populated_field():
    # This test is a coverage failsafe to make sure that UUID4 fields are
    # automatically populated, according to AIP-4235, with non-empty requests.
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport='grpc',
    )

    # Populate all string fields in the request which are not UUID4
    # since we want to check that UUID4 are populated automatically
    # if they meet the requirements of AIP 4235.
    request = model_monitoring_service.UpdateModelMonitorRequest(
    )

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
            type(client.transport.update_model_monitor),
            '__call__') as call:
        call.return_value.name = "foo" # operation_request.operation in compute client(s) expect a string.
        client.update_model_monitor(request=request)
        call.assert_called()
        _, args, _ = call.mock_calls[0]
        assert args[0] == model_monitoring_service.UpdateModelMonitorRequest(
        )

def test_update_model_monitor_use_cached_wrapped_rpc():
    # Clients should use _prep_wrapped_messages to create cached wrapped rpcs,
    # instead of constructing them on each call
    with mock.patch("google.api_core.gapic_v1.method.wrap_method") as wrapper_fn:
        client = ModelMonitoringServiceClient(
            credentials=ga_credentials.AnonymousCredentials(),
            transport="grpc",
        )

        # Should wrap all calls on client creation
        assert wrapper_fn.call_count > 0
        wrapper_fn.reset_mock()

        # Ensure method has been cached
        assert client._transport.update_model_monitor in client._transport._wrapped_methods

        # Replace cached wrapped function with mock
        mock_rpc = mock.Mock()
        mock_rpc.return_value.name = "foo" # operation_request.operation in compute client(s) expect a string.
        client._transport._wrapped_methods[client._transport.update_model_monitor] = mock_rpc
        request = {}
        client.update_model_monitor(request)

        # Establish that the underlying gRPC stub method was called.
        assert mock_rpc.call_count == 1

        # Operation methods call wrapper_fn to build a cached
        # client._transport.operations_client instance on first rpc call.
        # Subsequent calls should use the cached wrapper
        wrapper_fn.reset_mock()

        client.update_model_monitor(request)

        # Establish that a new wrapper was not created for this call
        assert wrapper_fn.call_count == 0
        assert mock_rpc.call_count == 2

@pytest.mark.asyncio
async def test_update_model_monitor_async_use_cached_wrapped_rpc(transport: str = "grpc_asyncio"):
    # Clients should use _prep_wrapped_messages to create cached wrapped rpcs,
    # instead of constructing them on each call
    with mock.patch("google.api_core.gapic_v1.method_async.wrap_method") as wrapper_fn:
        client = ModelMonitoringServiceAsyncClient(
            credentials=async_anonymous_credentials(),
            transport=transport,
        )

        # Should wrap all calls on client creation
        assert wrapper_fn.call_count > 0
        wrapper_fn.reset_mock()

        # Ensure method has been cached
        assert client._client._transport.update_model_monitor in client._client._transport._wrapped_methods

        # Replace cached wrapped function with mock
        mock_rpc = mock.AsyncMock()
        mock_rpc.return_value = mock.Mock()
        client._client._transport._wrapped_methods[client._client._transport.update_model_monitor] = mock_rpc

        request = {}
        await client.update_model_monitor(request)

        # Establish that the underlying gRPC stub method was called.
        assert mock_rpc.call_count == 1

        # Operation methods call wrapper_fn to build a cached
        # client._transport.operations_client instance on first rpc call.
        # Subsequent calls should use the cached wrapper
        wrapper_fn.reset_mock()

        await client.update_model_monitor(request)

        # Establish that a new wrapper was not created for this call
        assert wrapper_fn.call_count == 0
        assert mock_rpc.call_count == 2

@pytest.mark.asyncio
async def test_update_model_monitor_async(transport: str = 'grpc_asyncio', request_type=model_monitoring_service.UpdateModelMonitorRequest):
    client = ModelMonitoringServiceAsyncClient(
        credentials=async_anonymous_credentials(),
        transport=transport,
    )

    # Everything is optional in proto3 as far as the runtime is concerned,
    # and we are mocking out the actual API, so just send an empty request.
    request = request_type()

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
            type(client.transport.update_model_monitor),
            '__call__') as call:
        # Designate an appropriate return value for the call.
        call.return_value = grpc_helpers_async.FakeUnaryUnaryCall(
            operations_pb2.Operation(name='operations/spam')
        )
        response = await client.update_model_monitor(request)

        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls)
        _, args, _ = call.mock_calls[0]
        request = model_monitoring_service.UpdateModelMonitorRequest()
        assert args[0] == request

    # Establish that the response is the type that we expect.
    assert isinstance(response, future.Future)


@pytest.mark.asyncio
async def test_update_model_monitor_async_from_dict():
    await test_update_model_monitor_async(request_type=dict)

def test_update_model_monitor_field_headers():
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
    )

    # Any value that is part of the HTTP/1.1 URI should be sent as
    # a field header. Set these to a non-empty value.
    request = model_monitoring_service.UpdateModelMonitorRequest()

    request.model_monitor.name = 'name_value'

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
            type(client.transport.update_model_monitor),
            '__call__') as call:
        call.return_value = operations_pb2.Operation(name='operations/op')
        client.update_model_monitor(request)

        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls) == 1
        _, args, _ = call.mock_calls[0]
        assert args[0] == request

    # Establish that the field header was sent.
    _, _, kw = call.mock_calls[0]
    assert (
        'x-goog-request-params',
        'model_monitor.name=name_value',
    ) in kw['metadata']


@pytest.mark.asyncio
async def test_update_model_monitor_field_headers_async():
    client = ModelMonitoringServiceAsyncClient(
        credentials=async_anonymous_credentials(),
    )

    # Any value that is part of the HTTP/1.1 URI should be sent as
    # a field header. Set these to a non-empty value.
    request = model_monitoring_service.UpdateModelMonitorRequest()

    request.model_monitor.name = 'name_value'

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
            type(client.transport.update_model_monitor),
            '__call__') as call:
        call.return_value = grpc_helpers_async.FakeUnaryUnaryCall(operations_pb2.Operation(name='operations/op'))
        await client.update_model_monitor(request)

        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls)
        _, args, _ = call.mock_calls[0]
        assert args[0] == request

    # Establish that the field header was sent.
    _, _, kw = call.mock_calls[0]
    assert (
        'x-goog-request-params',
        'model_monitor.name=name_value',
    ) in kw['metadata']


def test_update_model_monitor_flattened():
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
    )

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
            type(client.transport.update_model_monitor),
            '__call__') as call:
        # Designate an appropriate return value for the call.
        call.return_value = operations_pb2.Operation(name='operations/op')
        # Call the method with a truthy value for each flattened field,
        # using the keyword arguments to the method.
        client.update_model_monitor(
            model_monitor=gca_model_monitor.ModelMonitor(tabular_objective=model_monitoring_spec.ModelMonitoringObjectiveSpec.TabularObjective(feature_drift_spec=model_monitoring_spec.ModelMonitoringObjectiveSpec.DataDriftSpec(features=['features_value']))),
            update_mask=field_mask_pb2.FieldMask(paths=['paths_value']),
        )

        # Establish that the underlying call was made with the expected
        # request object values.
        assert len(call.mock_calls) == 1
        _, args, _ = call.mock_calls[0]
        arg = args[0].model_monitor
        mock_val = gca_model_monitor.ModelMonitor(tabular_objective=model_monitoring_spec.ModelMonitoringObjectiveSpec.TabularObjective(feature_drift_spec=model_monitoring_spec.ModelMonitoringObjectiveSpec.DataDriftSpec(features=['features_value'])))
        assert arg == mock_val
        arg = args[0].update_mask
        mock_val = field_mask_pb2.FieldMask(paths=['paths_value'])
        assert arg == mock_val


def test_update_model_monitor_flattened_error():
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
    )

    # Attempting to call a method with both a request object and flattened
    # fields is an error.
    with pytest.raises(ValueError):
        client.update_model_monitor(
            model_monitoring_service.UpdateModelMonitorRequest(),
            model_monitor=gca_model_monitor.ModelMonitor(tabular_objective=model_monitoring_spec.ModelMonitoringObjectiveSpec.TabularObjective(feature_drift_spec=model_monitoring_spec.ModelMonitoringObjectiveSpec.DataDriftSpec(features=['features_value']))),
            update_mask=field_mask_pb2.FieldMask(paths=['paths_value']),
        )

@pytest.mark.asyncio
async def test_update_model_monitor_flattened_async():
    client = ModelMonitoringServiceAsyncClient(
        credentials=async_anonymous_credentials(),
    )

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
            type(client.transport.update_model_monitor),
            '__call__') as call:
        # Designate an appropriate return value for the call.
        call.return_value = operations_pb2.Operation(name='operations/op')

        call.return_value = grpc_helpers_async.FakeUnaryUnaryCall(
            operations_pb2.Operation(name='operations/spam')
        )
        # Call the method with a truthy value for each flattened field,
        # using the keyword arguments to the method.
        response = await client.update_model_monitor(
            model_monitor=gca_model_monitor.ModelMonitor(tabular_objective=model_monitoring_spec.ModelMonitoringObjectiveSpec.TabularObjective(feature_drift_spec=model_monitoring_spec.ModelMonitoringObjectiveSpec.DataDriftSpec(features=['features_value']))),
            update_mask=field_mask_pb2.FieldMask(paths=['paths_value']),
        )

        # Establish that the underlying call was made with the expected
        # request object values.
        assert len(call.mock_calls)
        _, args, _ = call.mock_calls[0]
        arg = args[0].model_monitor
        mock_val = gca_model_monitor.ModelMonitor(tabular_objective=model_monitoring_spec.ModelMonitoringObjectiveSpec.TabularObjective(feature_drift_spec=model_monitoring_spec.ModelMonitoringObjectiveSpec.DataDriftSpec(features=['features_value'])))
        assert arg == mock_val
        arg = args[0].update_mask
        mock_val = field_mask_pb2.FieldMask(paths=['paths_value'])
        assert arg == mock_val

@pytest.mark.asyncio
async def test_update_model_monitor_flattened_error_async():
    client = ModelMonitoringServiceAsyncClient(
        credentials=async_anonymous_credentials(),
    )

    # Attempting to call a method with both a request object and flattened
    # fields is an error.
    with pytest.raises(ValueError):
        await client.update_model_monitor(
            model_monitoring_service.UpdateModelMonitorRequest(),
            model_monitor=gca_model_monitor.ModelMonitor(tabular_objective=model_monitoring_spec.ModelMonitoringObjectiveSpec.TabularObjective(feature_drift_spec=model_monitoring_spec.ModelMonitoringObjectiveSpec.DataDriftSpec(features=['features_value']))),
            update_mask=field_mask_pb2.FieldMask(paths=['paths_value']),
        )


@pytest.mark.parametrize("request_type", [
  model_monitoring_service.GetModelMonitorRequest,
  dict,
])
def test_get_model_monitor(request_type, transport: str = 'grpc'):
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport=transport,
    )

    # Everything is optional in proto3 as far as the runtime is concerned,
    # and we are mocking out the actual API, so just send an empty request.
    request = request_type()

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
            type(client.transport.get_model_monitor),
            '__call__') as call:
        # Designate an appropriate return value for the call.
        call.return_value = model_monitor.ModelMonitor(
            name='name_value',
            display_name='display_name_value',
            satisfies_pzs=True,
            satisfies_pzi=True,
        )
        response = client.get_model_monitor(request)

        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls) == 1
        _, args, _ = call.mock_calls[0]
        request = model_monitoring_service.GetModelMonitorRequest()
        assert args[0] == request

    # Establish that the response is the type that we expect.
    assert isinstance(response, model_monitor.ModelMonitor)
    assert response.name == 'name_value'
    assert response.display_name == 'display_name_value'
    assert response.satisfies_pzs is True
    assert response.satisfies_pzi is True


def test_get_model_monitor_non_empty_request_with_auto_populated_field():
    # This test is a coverage failsafe to make sure that UUID4 fields are
    # automatically populated, according to AIP-4235, with non-empty requests.
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport='grpc',
    )

    # Populate all string fields in the request which are not UUID4
    # since we want to check that UUID4 are populated automatically
    # if they meet the requirements of AIP 4235.
    request = model_monitoring_service.GetModelMonitorRequest(
        name='name_value',
    )

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
            type(client.transport.get_model_monitor),
            '__call__') as call:
        call.return_value.name = "foo" # operation_request.operation in compute client(s) expect a string.
        client.get_model_monitor(request=request)
        call.assert_called()
        _, args, _ = call.mock_calls[0]
        assert args[0] == model_monitoring_service.GetModelMonitorRequest(
            name='name_value',
        )

def test_get_model_monitor_use_cached_wrapped_rpc():
    # Clients should use _prep_wrapped_messages to create cached wrapped rpcs,
    # instead of constructing them on each call
    with mock.patch("google.api_core.gapic_v1.method.wrap_method") as wrapper_fn:
        client = ModelMonitoringServiceClient(
            credentials=ga_credentials.AnonymousCredentials(),
            transport="grpc",
        )

        # Should wrap all calls on client creation
        assert wrapper_fn.call_count > 0
        wrapper_fn.reset_mock()

        # Ensure method has been cached
        assert client._transport.get_model_monitor in client._transport._wrapped_methods

        # Replace cached wrapped function with mock
        mock_rpc = mock.Mock()
        mock_rpc.return_value.name = "foo" # operation_request.operation in compute client(s) expect a string.
        client._transport._wrapped_methods[client._transport.get_model_monitor] = mock_rpc
        request = {}
        client.get_model_monitor(request)

        # Establish that the underlying gRPC stub method was called.
        assert mock_rpc.call_count == 1

        client.get_model_monitor(request)

        # Establish that a new wrapper was not created for this call
        assert wrapper_fn.call_count == 0
        assert mock_rpc.call_count == 2

@pytest.mark.asyncio
async def test_get_model_monitor_async_use_cached_wrapped_rpc(transport: str = "grpc_asyncio"):
    # Clients should use _prep_wrapped_messages to create cached wrapped rpcs,
    # instead of constructing them on each call
    with mock.patch("google.api_core.gapic_v1.method_async.wrap_method") as wrapper_fn:
        client = ModelMonitoringServiceAsyncClient(
            credentials=async_anonymous_credentials(),
            transport=transport,
        )

        # Should wrap all calls on client creation
        assert wrapper_fn.call_count > 0
        wrapper_fn.reset_mock()

        # Ensure method has been cached
        assert client._client._transport.get_model_monitor in client._client._transport._wrapped_methods

        # Replace cached wrapped function with mock
        mock_rpc = mock.AsyncMock()
        mock_rpc.return_value = mock.Mock()
        client._client._transport._wrapped_methods[client._client._transport.get_model_monitor] = mock_rpc

        request = {}
        await client.get_model_monitor(request)

        # Establish that the underlying gRPC stub method was called.
        assert mock_rpc.call_count == 1

        await client.get_model_monitor(request)

        # Establish that a new wrapper was not created for this call
        assert wrapper_fn.call_count == 0
        assert mock_rpc.call_count == 2

@pytest.mark.asyncio
async def test_get_model_monitor_async(transport: str = 'grpc_asyncio', request_type=model_monitoring_service.GetModelMonitorRequest):
    client = ModelMonitoringServiceAsyncClient(
        credentials=async_anonymous_credentials(),
        transport=transport,
    )

    # Everything is optional in proto3 as far as the runtime is concerned,
    # and we are mocking out the actual API, so just send an empty request.
    request = request_type()

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
            type(client.transport.get_model_monitor),
            '__call__') as call:
        # Designate an appropriate return value for the call.
        call.return_value =grpc_helpers_async.FakeUnaryUnaryCall(model_monitor.ModelMonitor(
            name='name_value',
            display_name='display_name_value',
            satisfies_pzs=True,
            satisfies_pzi=True,
        ))
        response = await client.get_model_monitor(request)

        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls)
        _, args, _ = call.mock_calls[0]
        request = model_monitoring_service.GetModelMonitorRequest()
        assert args[0] == request

    # Establish that the response is the type that we expect.
    assert isinstance(response, model_monitor.ModelMonitor)
    assert response.name == 'name_value'
    assert response.display_name == 'display_name_value'
    assert response.satisfies_pzs is True
    assert response.satisfies_pzi is True


@pytest.mark.asyncio
async def test_get_model_monitor_async_from_dict():
    await test_get_model_monitor_async(request_type=dict)

def test_get_model_monitor_field_headers():
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
    )

    # Any value that is part of the HTTP/1.1 URI should be sent as
    # a field header. Set these to a non-empty value.
    request = model_monitoring_service.GetModelMonitorRequest()

    request.name = 'name_value'

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
            type(client.transport.get_model_monitor),
            '__call__') as call:
        call.return_value = model_monitor.ModelMonitor()
        client.get_model_monitor(request)

        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls) == 1
        _, args, _ = call.mock_calls[0]
        assert args[0] == request

    # Establish that the field header was sent.
    _, _, kw = call.mock_calls[0]
    assert (
        'x-goog-request-params',
        'name=name_value',
    ) in kw['metadata']


@pytest.mark.asyncio
async def test_get_model_monitor_field_headers_async():
    client = ModelMonitoringServiceAsyncClient(
        credentials=async_anonymous_credentials(),
    )

    # Any value that is part of the HTTP/1.1 URI should be sent as
    # a field header. Set these to a non-empty value.
    request = model_monitoring_service.GetModelMonitorRequest()

    request.name = 'name_value'

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
            type(client.transport.get_model_monitor),
            '__call__') as call:
        call.return_value = grpc_helpers_async.FakeUnaryUnaryCall(model_monitor.ModelMonitor())
        await client.get_model_monitor(request)

        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls)
        _, args, _ = call.mock_calls[0]
        assert args[0] == request

    # Establish that the field header was sent.
    _, _, kw = call.mock_calls[0]
    assert (
        'x-goog-request-params',
        'name=name_value',
    ) in kw['metadata']


def test_get_model_monitor_flattened():
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
    )

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
            type(client.transport.get_model_monitor),
            '__call__') as call:
        # Designate an appropriate return value for the call.
        call.return_value = model_monitor.ModelMonitor()
        # Call the method with a truthy value for each flattened field,
        # using the keyword arguments to the method.
        client.get_model_monitor(
            name='name_value',
        )

        # Establish that the underlying call was made with the expected
        # request object values.
        assert len(call.mock_calls) == 1
        _, args, _ = call.mock_calls[0]
        arg = args[0].name
        mock_val = 'name_value'
        assert arg == mock_val


def test_get_model_monitor_flattened_error():
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
    )

    # Attempting to call a method with both a request object and flattened
    # fields is an error.
    with pytest.raises(ValueError):
        client.get_model_monitor(
            model_monitoring_service.GetModelMonitorRequest(),
            name='name_value',
        )

@pytest.mark.asyncio
async def test_get_model_monitor_flattened_async():
    client = ModelMonitoringServiceAsyncClient(
        credentials=async_anonymous_credentials(),
    )

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
            type(client.transport.get_model_monitor),
            '__call__') as call:
        # Designate an appropriate return value for the call.
        call.return_value = model_monitor.ModelMonitor()

        call.return_value = grpc_helpers_async.FakeUnaryUnaryCall(model_monitor.ModelMonitor())
        # Call the method with a truthy value for each flattened field,
        # using the keyword arguments to the method.
        response = await client.get_model_monitor(
            name='name_value',
        )

        # Establish that the underlying call was made with the expected
        # request object values.
        assert len(call.mock_calls)
        _, args, _ = call.mock_calls[0]
        arg = args[0].name
        mock_val = 'name_value'
        assert arg == mock_val

@pytest.mark.asyncio
async def test_get_model_monitor_flattened_error_async():
    client = ModelMonitoringServiceAsyncClient(
        credentials=async_anonymous_credentials(),
    )

    # Attempting to call a method with both a request object and flattened
    # fields is an error.
    with pytest.raises(ValueError):
        await client.get_model_monitor(
            model_monitoring_service.GetModelMonitorRequest(),
            name='name_value',
        )


@pytest.mark.parametrize("request_type", [
  model_monitoring_service.ListModelMonitorsRequest,
  dict,
])
def test_list_model_monitors(request_type, transport: str = 'grpc'):
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport=transport,
    )

    # Everything is optional in proto3 as far as the runtime is concerned,
    # and we are mocking out the actual API, so just send an empty request.
    request = request_type()

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
            type(client.transport.list_model_monitors),
            '__call__') as call:
        # Designate an appropriate return value for the call.
        call.return_value = model_monitoring_service.ListModelMonitorsResponse(
            next_page_token='next_page_token_value',
        )
        response = client.list_model_monitors(request)

        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls) == 1
        _, args, _ = call.mock_calls[0]
        request = model_monitoring_service.ListModelMonitorsRequest()
        assert args[0] == request

    # Establish that the response is the type that we expect.
    assert isinstance(response, pagers.ListModelMonitorsPager)
    assert response.next_page_token == 'next_page_token_value'


def test_list_model_monitors_non_empty_request_with_auto_populated_field():
    # This test is a coverage failsafe to make sure that UUID4 fields are
    # automatically populated, according to AIP-4235, with non-empty requests.
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport='grpc',
    )

    # Populate all string fields in the request which are not UUID4
    # since we want to check that UUID4 are populated automatically
    # if they meet the requirements of AIP 4235.
    request = model_monitoring_service.ListModelMonitorsRequest(
        parent='parent_value',
        filter='filter_value',
        page_token='page_token_value',
    )

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
            type(client.transport.list_model_monitors),
            '__call__') as call:
        call.return_value.name = "foo" # operation_request.operation in compute client(s) expect a string.
        client.list_model_monitors(request=request)
        call.assert_called()
        _, args, _ = call.mock_calls[0]
        assert args[0] == model_monitoring_service.ListModelMonitorsRequest(
            parent='parent_value',
            filter='filter_value',
            page_token='page_token_value',
        )

def test_list_model_monitors_use_cached_wrapped_rpc():
    # Clients should use _prep_wrapped_messages to create cached wrapped rpcs,
    # instead of constructing them on each call
    with mock.patch("google.api_core.gapic_v1.method.wrap_method") as wrapper_fn:
        client = ModelMonitoringServiceClient(
            credentials=ga_credentials.AnonymousCredentials(),
            transport="grpc",
        )

        # Should wrap all calls on client creation
        assert wrapper_fn.call_count > 0
        wrapper_fn.reset_mock()

        # Ensure method has been cached
        assert client._transport.list_model_monitors in client._transport._wrapped_methods

        # Replace cached wrapped function with mock
        mock_rpc = mock.Mock()
        mock_rpc.return_value.name = "foo" # operation_request.operation in compute client(s) expect a string.
        client._transport._wrapped_methods[client._transport.list_model_monitors] = mock_rpc
        request = {}
        client.list_model_monitors(request)

        # Establish that the underlying gRPC stub method was called.
        assert mock_rpc.call_count == 1

        client.list_model_monitors(request)

        # Establish that a new wrapper was not created for this call
        assert wrapper_fn.call_count == 0
        assert mock_rpc.call_count == 2

@pytest.mark.asyncio
async def test_list_model_monitors_async_use_cached_wrapped_rpc(transport: str = "grpc_asyncio"):
    # Clients should use _prep_wrapped_messages to create cached wrapped rpcs,
    # instead of constructing them on each call
    with mock.patch("google.api_core.gapic_v1.method_async.wrap_method") as wrapper_fn:
        client = ModelMonitoringServiceAsyncClient(
            credentials=async_anonymous_credentials(),
            transport=transport,
        )

        # Should wrap all calls on client creation
        assert wrapper_fn.call_count > 0
        wrapper_fn.reset_mock()

        # Ensure method has been cached
        assert client._client._transport.list_model_monitors in client._client._transport._wrapped_methods

        # Replace cached wrapped function with mock
        mock_rpc = mock.AsyncMock()
        mock_rpc.return_value = mock.Mock()
        client._client._transport._wrapped_methods[client._client._transport.list_model_monitors] = mock_rpc

        request = {}
        await client.list_model_monitors(request)

        # Establish that the underlying gRPC stub method was called.
        assert mock_rpc.call_count == 1

        await client.list_model_monitors(request)

        # Establish that a new wrapper was not created for this call
        assert wrapper_fn.call_count == 0
        assert mock_rpc.call_count == 2

@pytest.mark.asyncio
async def test_list_model_monitors_async(transport: str = 'grpc_asyncio', request_type=model_monitoring_service.ListModelMonitorsRequest):
    client = ModelMonitoringServiceAsyncClient(
        credentials=async_anonymous_credentials(),
        transport=transport,
    )

    # Everything is optional in proto3 as far as the runtime is concerned,
    # and we are mocking out the actual API, so just send an empty request.
    request = request_type()

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
            type(client.transport.list_model_monitors),
            '__call__') as call:
        # Designate an appropriate return value for the call.
        call.return_value =grpc_helpers_async.FakeUnaryUnaryCall(model_monitoring_service.ListModelMonitorsResponse(
            next_page_token='next_page_token_value',
        ))
        response = await client.list_model_monitors(request)

        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls)
        _, args, _ = call.mock_calls[0]
        request = model_monitoring_service.ListModelMonitorsRequest()
        assert args[0] == request

    # Establish that the response is the type that we expect.
    assert isinstance(response, pagers.ListModelMonitorsAsyncPager)
    assert response.next_page_token == 'next_page_token_value'


@pytest.mark.asyncio
async def test_list_model_monitors_async_from_dict():
    await test_list_model_monitors_async(request_type=dict)

def test_list_model_monitors_field_headers():
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
    )

    # Any value that is part of the HTTP/1.1 URI should be sent as
    # a field header. Set these to a non-empty value.
    request = model_monitoring_service.ListModelMonitorsRequest()

    request.parent = 'parent_value'

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
            type(client.transport.list_model_monitors),
            '__call__') as call:
        call.return_value = model_monitoring_service.ListModelMonitorsResponse()
        client.list_model_monitors(request)

        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls) == 1
        _, args, _ = call.mock_calls[0]
        assert args[0] == request

    # Establish that the field header was sent.
    _, _, kw = call.mock_calls[0]
    assert (
        'x-goog-request-params',
        'parent=parent_value',
    ) in kw['metadata']


@pytest.mark.asyncio
async def test_list_model_monitors_field_headers_async():
    client = ModelMonitoringServiceAsyncClient(
        credentials=async_anonymous_credentials(),
    )

    # Any value that is part of the HTTP/1.1 URI should be sent as
    # a field header. Set these to a non-empty value.
    request = model_monitoring_service.ListModelMonitorsRequest()

    request.parent = 'parent_value'

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
            type(client.transport.list_model_monitors),
            '__call__') as call:
        call.return_value = grpc_helpers_async.FakeUnaryUnaryCall(model_monitoring_service.ListModelMonitorsResponse())
        await client.list_model_monitors(request)

        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls)
        _, args, _ = call.mock_calls[0]
        assert args[0] == request

    # Establish that the field header was sent.
    _, _, kw = call.mock_calls[0]
    assert (
        'x-goog-request-params',
        'parent=parent_value',
    ) in kw['metadata']


def test_list_model_monitors_flattened():
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
    )

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
            type(client.transport.list_model_monitors),
            '__call__') as call:
        # Designate an appropriate return value for the call.
        call.return_value = model_monitoring_service.ListModelMonitorsResponse()
        # Call the method with a truthy value for each flattened field,
        # using the keyword arguments to the method.
        client.list_model_monitors(
            parent='parent_value',
        )

        # Establish that the underlying call was made with the expected
        # request object values.
        assert len(call.mock_calls) == 1
        _, args, _ = call.mock_calls[0]
        arg = args[0].parent
        mock_val = 'parent_value'
        assert arg == mock_val


def test_list_model_monitors_flattened_error():
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
    )

    # Attempting to call a method with both a request object and flattened
    # fields is an error.
    with pytest.raises(ValueError):
        client.list_model_monitors(
            model_monitoring_service.ListModelMonitorsRequest(),
            parent='parent_value',
        )

@pytest.mark.asyncio
async def test_list_model_monitors_flattened_async():
    client = ModelMonitoringServiceAsyncClient(
        credentials=async_anonymous_credentials(),
    )

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
            type(client.transport.list_model_monitors),
            '__call__') as call:
        # Designate an appropriate return value for the call.
        call.return_value = model_monitoring_service.ListModelMonitorsResponse()

        call.return_value = grpc_helpers_async.FakeUnaryUnaryCall(model_monitoring_service.ListModelMonitorsResponse())
        # Call the method with a truthy value for each flattened field,
        # using the keyword arguments to the method.
        response = await client.list_model_monitors(
            parent='parent_value',
        )

        # Establish that the underlying call was made with the expected
        # request object values.
        assert len(call.mock_calls)
        _, args, _ = call.mock_calls[0]
        arg = args[0].parent
        mock_val = 'parent_value'
        assert arg == mock_val

@pytest.mark.asyncio
async def test_list_model_monitors_flattened_error_async():
    client = ModelMonitoringServiceAsyncClient(
        credentials=async_anonymous_credentials(),
    )

    # Attempting to call a method with both a request object and flattened
    # fields is an error.
    with pytest.raises(ValueError):
        await client.list_model_monitors(
            model_monitoring_service.ListModelMonitorsRequest(),
            parent='parent_value',
        )


def test_list_model_monitors_pager(transport_name: str = "grpc"):
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport=transport_name,
    )

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
            type(client.transport.list_model_monitors),
            '__call__') as call:
        # Set the response to a series of pages.
        call.side_effect = (
            model_monitoring_service.ListModelMonitorsResponse(
                model_monitors=[
                    model_monitor.ModelMonitor(),
                    model_monitor.ModelMonitor(),
                    model_monitor.ModelMonitor(),
                ],
                next_page_token='abc',
            ),
            model_monitoring_service.ListModelMonitorsResponse(
                model_monitors=[],
                next_page_token='def',
            ),
            model_monitoring_service.ListModelMonitorsResponse(
                model_monitors=[
                    model_monitor.ModelMonitor(),
                ],
                next_page_token='ghi',
            ),
            model_monitoring_service.ListModelMonitorsResponse(
                model_monitors=[
                    model_monitor.ModelMonitor(),
                    model_monitor.ModelMonitor(),
                ],
            ),
            RuntimeError,
        )

        expected_metadata = ()
        retry = retries.Retry()
        timeout = 5
        expected_metadata = tuple(expected_metadata) + (
            gapic_v1.routing_header.to_grpc_metadata((
                ('parent', ''),
            )),
        )
        pager = client.list_model_monitors(request={}, retry=retry, timeout=timeout)

        assert pager._metadata == expected_metadata
        assert pager._retry == retry
        assert pager._timeout == timeout

        results = list(pager)
        assert len(results) == 6
        assert all(isinstance(i, model_monitor.ModelMonitor)
                   for i in results)
def test_list_model_monitors_pages(transport_name: str = "grpc"):
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport=transport_name,
    )

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
            type(client.transport.list_model_monitors),
            '__call__') as call:
        # Set the response to a series of pages.
        call.side_effect = (
            model_monitoring_service.ListModelMonitorsResponse(
                model_monitors=[
                    model_monitor.ModelMonitor(),
                    model_monitor.ModelMonitor(),
                    model_monitor.ModelMonitor(),
                ],
                next_page_token='abc',
            ),
            model_monitoring_service.ListModelMonitorsResponse(
                model_monitors=[],
                next_page_token='def',
            ),
            model_monitoring_service.ListModelMonitorsResponse(
                model_monitors=[
                    model_monitor.ModelMonitor(),
                ],
                next_page_token='ghi',
            ),
            model_monitoring_service.ListModelMonitorsResponse(
                model_monitors=[
                    model_monitor.ModelMonitor(),
                    model_monitor.ModelMonitor(),
                ],
            ),
            RuntimeError,
        )
        pages = list(client.list_model_monitors(request={}).pages)
        for page_, token in zip(pages, ['abc','def','ghi', '']):
            assert page_.raw_page.next_page_token == token

@pytest.mark.asyncio
async def test_list_model_monitors_async_pager():
    client = ModelMonitoringServiceAsyncClient(
        credentials=async_anonymous_credentials(),
    )

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
            type(client.transport.list_model_monitors),
            '__call__', new_callable=mock.AsyncMock) as call:
        # Set the response to a series of pages.
        call.side_effect = (
            model_monitoring_service.ListModelMonitorsResponse(
                model_monitors=[
                    model_monitor.ModelMonitor(),
                    model_monitor.ModelMonitor(),
                    model_monitor.ModelMonitor(),
                ],
                next_page_token='abc',
            ),
            model_monitoring_service.ListModelMonitorsResponse(
                model_monitors=[],
                next_page_token='def',
            ),
            model_monitoring_service.ListModelMonitorsResponse(
                model_monitors=[
                    model_monitor.ModelMonitor(),
                ],
                next_page_token='ghi',
            ),
            model_monitoring_service.ListModelMonitorsResponse(
                model_monitors=[
                    model_monitor.ModelMonitor(),
                    model_monitor.ModelMonitor(),
                ],
            ),
            RuntimeError,
        )
        async_pager = await client.list_model_monitors(request={},)
        assert async_pager.next_page_token == 'abc'
        responses = []
        async for response in async_pager: # pragma: no branch
            responses.append(response)

        assert len(responses) == 6
        assert all(isinstance(i, model_monitor.ModelMonitor)
                for i in responses)


@pytest.mark.asyncio
async def test_list_model_monitors_async_pages():
    client = ModelMonitoringServiceAsyncClient(
        credentials=async_anonymous_credentials(),
    )

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
            type(client.transport.list_model_monitors),
            '__call__', new_callable=mock.AsyncMock) as call:
        # Set the response to a series of pages.
        call.side_effect = (
            model_monitoring_service.ListModelMonitorsResponse(
                model_monitors=[
                    model_monitor.ModelMonitor(),
                    model_monitor.ModelMonitor(),
                    model_monitor.ModelMonitor(),
                ],
                next_page_token='abc',
            ),
            model_monitoring_service.ListModelMonitorsResponse(
                model_monitors=[],
                next_page_token='def',
            ),
            model_monitoring_service.ListModelMonitorsResponse(
                model_monitors=[
                    model_monitor.ModelMonitor(),
                ],
                next_page_token='ghi',
            ),
            model_monitoring_service.ListModelMonitorsResponse(
                model_monitors=[
                    model_monitor.ModelMonitor(),
                    model_monitor.ModelMonitor(),
                ],
            ),
            RuntimeError,
        )
        pages = []
        # Workaround issue in python 3.9 related to code coverage by adding `# pragma: no branch`
        # See https://github.com/googleapis/gapic-generator-python/pull/1174#issuecomment-1025132372
        async for page_ in ( # pragma: no branch
            await client.list_model_monitors(request={})
        ).pages:
            pages.append(page_)
        for page_, token in zip(pages, ['abc','def','ghi', '']):
            assert page_.raw_page.next_page_token == token

@pytest.mark.parametrize("request_type", [
  model_monitoring_service.DeleteModelMonitorRequest,
  dict,
])
def test_delete_model_monitor(request_type, transport: str = 'grpc'):
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport=transport,
    )

    # Everything is optional in proto3 as far as the runtime is concerned,
    # and we are mocking out the actual API, so just send an empty request.
    request = request_type()

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
            type(client.transport.delete_model_monitor),
            '__call__') as call:
        # Designate an appropriate return value for the call.
        call.return_value = operations_pb2.Operation(name='operations/spam')
        response = client.delete_model_monitor(request)

        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls) == 1
        _, args, _ = call.mock_calls[0]
        request = model_monitoring_service.DeleteModelMonitorRequest()
        assert args[0] == request

    # Establish that the response is the type that we expect.
    assert isinstance(response, future.Future)


def test_delete_model_monitor_non_empty_request_with_auto_populated_field():
    # This test is a coverage failsafe to make sure that UUID4 fields are
    # automatically populated, according to AIP-4235, with non-empty requests.
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport='grpc',
    )

    # Populate all string fields in the request which are not UUID4
    # since we want to check that UUID4 are populated automatically
    # if they meet the requirements of AIP 4235.
    request = model_monitoring_service.DeleteModelMonitorRequest(
        name='name_value',
    )

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
            type(client.transport.delete_model_monitor),
            '__call__') as call:
        call.return_value.name = "foo" # operation_request.operation in compute client(s) expect a string.
        client.delete_model_monitor(request=request)
        call.assert_called()
        _, args, _ = call.mock_calls[0]
        assert args[0] == model_monitoring_service.DeleteModelMonitorRequest(
            name='name_value',
        )

def test_delete_model_monitor_use_cached_wrapped_rpc():
    # Clients should use _prep_wrapped_messages to create cached wrapped rpcs,
    # instead of constructing them on each call
    with mock.patch("google.api_core.gapic_v1.method.wrap_method") as wrapper_fn:
        client = ModelMonitoringServiceClient(
            credentials=ga_credentials.AnonymousCredentials(),
            transport="grpc",
        )

        # Should wrap all calls on client creation
        assert wrapper_fn.call_count > 0
        wrapper_fn.reset_mock()

        # Ensure method has been cached
        assert client._transport.delete_model_monitor in client._transport._wrapped_methods

        # Replace cached wrapped function with mock
        mock_rpc = mock.Mock()
        mock_rpc.return_value.name = "foo" # operation_request.operation in compute client(s) expect a string.
        client._transport._wrapped_methods[client._transport.delete_model_monitor] = mock_rpc
        request = {}
        client.delete_model_monitor(request)

        # Establish that the underlying gRPC stub method was called.
        assert mock_rpc.call_count == 1

        # Operation methods call wrapper_fn to build a cached
        # client._transport.operations_client instance on first rpc call.
        # Subsequent calls should use the cached wrapper
        wrapper_fn.reset_mock()

        client.delete_model_monitor(request)

        # Establish that a new wrapper was not created for this call
        assert wrapper_fn.call_count == 0
        assert mock_rpc.call_count == 2

@pytest.mark.asyncio
async def test_delete_model_monitor_async_use_cached_wrapped_rpc(transport: str = "grpc_asyncio"):
    # Clients should use _prep_wrapped_messages to create cached wrapped rpcs,
    # instead of constructing them on each call
    with mock.patch("google.api_core.gapic_v1.method_async.wrap_method") as wrapper_fn:
        client = ModelMonitoringServiceAsyncClient(
            credentials=async_anonymous_credentials(),
            transport=transport,
        )

        # Should wrap all calls on client creation
        assert wrapper_fn.call_count > 0
        wrapper_fn.reset_mock()

        # Ensure method has been cached
        assert client._client._transport.delete_model_monitor in client._client._transport._wrapped_methods

        # Replace cached wrapped function with mock
        mock_rpc = mock.AsyncMock()
        mock_rpc.return_value = mock.Mock()
        client._client._transport._wrapped_methods[client._client._transport.delete_model_monitor] = mock_rpc

        request = {}
        await client.delete_model_monitor(request)

        # Establish that the underlying gRPC stub method was called.
        assert mock_rpc.call_count == 1

        # Operation methods call wrapper_fn to build a cached
        # client._transport.operations_client instance on first rpc call.
        # Subsequent calls should use the cached wrapper
        wrapper_fn.reset_mock()

        await client.delete_model_monitor(request)

        # Establish that a new wrapper was not created for this call
        assert wrapper_fn.call_count == 0
        assert mock_rpc.call_count == 2

@pytest.mark.asyncio
async def test_delete_model_monitor_async(transport: str = 'grpc_asyncio', request_type=model_monitoring_service.DeleteModelMonitorRequest):
    client = ModelMonitoringServiceAsyncClient(
        credentials=async_anonymous_credentials(),
        transport=transport,
    )

    # Everything is optional in proto3 as far as the runtime is concerned,
    # and we are mocking out the actual API, so just send an empty request.
    request = request_type()

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
            type(client.transport.delete_model_monitor),
            '__call__') as call:
        # Designate an appropriate return value for the call.
        call.return_value = grpc_helpers_async.FakeUnaryUnaryCall(
            operations_pb2.Operation(name='operations/spam')
        )
        response = await client.delete_model_monitor(request)

        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls)
        _, args, _ = call.mock_calls[0]
        request = model_monitoring_service.DeleteModelMonitorRequest()
        assert args[0] == request

    # Establish that the response is the type that we expect.
    assert isinstance(response, future.Future)


@pytest.mark.asyncio
async def test_delete_model_monitor_async_from_dict():
    await test_delete_model_monitor_async(request_type=dict)

def test_delete_model_monitor_field_headers():
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
    )

    # Any value that is part of the HTTP/1.1 URI should be sent as
    # a field header. Set these to a non-empty value.
    request = model_monitoring_service.DeleteModelMonitorRequest()

    request.name = 'name_value'

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
            type(client.transport.delete_model_monitor),
            '__call__') as call:
        call.return_value = operations_pb2.Operation(name='operations/op')
        client.delete_model_monitor(request)

        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls) == 1
        _, args, _ = call.mock_calls[0]
        assert args[0] == request

    # Establish that the field header was sent.
    _, _, kw = call.mock_calls[0]
    assert (
        'x-goog-request-params',
        'name=name_value',
    ) in kw['metadata']


@pytest.mark.asyncio
async def test_delete_model_monitor_field_headers_async():
    client = ModelMonitoringServiceAsyncClient(
        credentials=async_anonymous_credentials(),
    )

    # Any value that is part of the HTTP/1.1 URI should be sent as
    # a field header. Set these to a non-empty value.
    request = model_monitoring_service.DeleteModelMonitorRequest()

    request.name = 'name_value'

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
            type(client.transport.delete_model_monitor),
            '__call__') as call:
        call.return_value = grpc_helpers_async.FakeUnaryUnaryCall(operations_pb2.Operation(name='operations/op'))
        await client.delete_model_monitor(request)

        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls)
        _, args, _ = call.mock_calls[0]
        assert args[0] == request

    # Establish that the field header was sent.
    _, _, kw = call.mock_calls[0]
    assert (
        'x-goog-request-params',
        'name=name_value',
    ) in kw['metadata']


def test_delete_model_monitor_flattened():
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
    )

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
            type(client.transport.delete_model_monitor),
            '__call__') as call:
        # Designate an appropriate return value for the call.
        call.return_value = operations_pb2.Operation(name='operations/op')
        # Call the method with a truthy value for each flattened field,
        # using the keyword arguments to the method.
        client.delete_model_monitor(
            name='name_value',
        )

        # Establish that the underlying call was made with the expected
        # request object values.
        assert len(call.mock_calls) == 1
        _, args, _ = call.mock_calls[0]
        arg = args[0].name
        mock_val = 'name_value'
        assert arg == mock_val


def test_delete_model_monitor_flattened_error():
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
    )

    # Attempting to call a method with both a request object and flattened
    # fields is an error.
    with pytest.raises(ValueError):
        client.delete_model_monitor(
            model_monitoring_service.DeleteModelMonitorRequest(),
            name='name_value',
        )

@pytest.mark.asyncio
async def test_delete_model_monitor_flattened_async():
    client = ModelMonitoringServiceAsyncClient(
        credentials=async_anonymous_credentials(),
    )

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
            type(client.transport.delete_model_monitor),
            '__call__') as call:
        # Designate an appropriate return value for the call.
        call.return_value = operations_pb2.Operation(name='operations/op')

        call.return_value = grpc_helpers_async.FakeUnaryUnaryCall(
            operations_pb2.Operation(name='operations/spam')
        )
        # Call the method with a truthy value for each flattened field,
        # using the keyword arguments to the method.
        response = await client.delete_model_monitor(
            name='name_value',
        )

        # Establish that the underlying call was made with the expected
        # request object values.
        assert len(call.mock_calls)
        _, args, _ = call.mock_calls[0]
        arg = args[0].name
        mock_val = 'name_value'
        assert arg == mock_val

@pytest.mark.asyncio
async def test_delete_model_monitor_flattened_error_async():
    client = ModelMonitoringServiceAsyncClient(
        credentials=async_anonymous_credentials(),
    )

    # Attempting to call a method with both a request object and flattened
    # fields is an error.
    with pytest.raises(ValueError):
        await client.delete_model_monitor(
            model_monitoring_service.DeleteModelMonitorRequest(),
            name='name_value',
        )


@pytest.mark.parametrize("request_type", [
  model_monitoring_service.CreateModelMonitoringJobRequest,
  dict,
])
def test_create_model_monitoring_job(request_type, transport: str = 'grpc'):
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport=transport,
    )

    # Everything is optional in proto3 as far as the runtime is concerned,
    # and we are mocking out the actual API, so just send an empty request.
    request = request_type()

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
            type(client.transport.create_model_monitoring_job),
            '__call__') as call:
        # Designate an appropriate return value for the call.
        call.return_value = gca_model_monitoring_job.ModelMonitoringJob(
            name='name_value',
            display_name='display_name_value',
            state=job_state.JobState.JOB_STATE_QUEUED,
            schedule='schedule_value',
        )
        response = client.create_model_monitoring_job(request)

        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls) == 1
        _, args, _ = call.mock_calls[0]
        request = model_monitoring_service.CreateModelMonitoringJobRequest()
        assert args[0] == request

    # Establish that the response is the type that we expect.
    assert isinstance(response, gca_model_monitoring_job.ModelMonitoringJob)
    assert response.name == 'name_value'
    assert response.display_name == 'display_name_value'
    assert response.state == job_state.JobState.JOB_STATE_QUEUED
    assert response.schedule == 'schedule_value'


def test_create_model_monitoring_job_non_empty_request_with_auto_populated_field():
    # This test is a coverage failsafe to make sure that UUID4 fields are
    # automatically populated, according to AIP-4235, with non-empty requests.
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport='grpc',
    )

    # Populate all string fields in the request which are not UUID4
    # since we want to check that UUID4 are populated automatically
    # if they meet the requirements of AIP 4235.
    request = model_monitoring_service.CreateModelMonitoringJobRequest(
        parent='parent_value',
        model_monitoring_job_id='model_monitoring_job_id_value',
    )

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
            type(client.transport.create_model_monitoring_job),
            '__call__') as call:
        call.return_value.name = "foo" # operation_request.operation in compute client(s) expect a string.
        client.create_model_monitoring_job(request=request)
        call.assert_called()
        _, args, _ = call.mock_calls[0]
        assert args[0] == model_monitoring_service.CreateModelMonitoringJobRequest(
            parent='parent_value',
            model_monitoring_job_id='model_monitoring_job_id_value',
        )

def test_create_model_monitoring_job_use_cached_wrapped_rpc():
    # Clients should use _prep_wrapped_messages to create cached wrapped rpcs,
    # instead of constructing them on each call
    with mock.patch("google.api_core.gapic_v1.method.wrap_method") as wrapper_fn:
        client = ModelMonitoringServiceClient(
            credentials=ga_credentials.AnonymousCredentials(),
            transport="grpc",
        )

        # Should wrap all calls on client creation
        assert wrapper_fn.call_count > 0
        wrapper_fn.reset_mock()

        # Ensure method has been cached
        assert client._transport.create_model_monitoring_job in client._transport._wrapped_methods

        # Replace cached wrapped function with mock
        mock_rpc = mock.Mock()
        mock_rpc.return_value.name = "foo" # operation_request.operation in compute client(s) expect a string.
        client._transport._wrapped_methods[client._transport.create_model_monitoring_job] = mock_rpc
        request = {}
        client.create_model_monitoring_job(request)

        # Establish that the underlying gRPC stub method was called.
        assert mock_rpc.call_count == 1

        client.create_model_monitoring_job(request)

        # Establish that a new wrapper was not created for this call
        assert wrapper_fn.call_count == 0
        assert mock_rpc.call_count == 2

@pytest.mark.asyncio
async def test_create_model_monitoring_job_async_use_cached_wrapped_rpc(transport: str = "grpc_asyncio"):
    # Clients should use _prep_wrapped_messages to create cached wrapped rpcs,
    # instead of constructing them on each call
    with mock.patch("google.api_core.gapic_v1.method_async.wrap_method") as wrapper_fn:
        client = ModelMonitoringServiceAsyncClient(
            credentials=async_anonymous_credentials(),
            transport=transport,
        )

        # Should wrap all calls on client creation
        assert wrapper_fn.call_count > 0
        wrapper_fn.reset_mock()

        # Ensure method has been cached
        assert client._client._transport.create_model_monitoring_job in client._client._transport._wrapped_methods

        # Replace cached wrapped function with mock
        mock_rpc = mock.AsyncMock()
        mock_rpc.return_value = mock.Mock()
        client._client._transport._wrapped_methods[client._client._transport.create_model_monitoring_job] = mock_rpc

        request = {}
        await client.create_model_monitoring_job(request)

        # Establish that the underlying gRPC stub method was called.
        assert mock_rpc.call_count == 1

        await client.create_model_monitoring_job(request)

        # Establish that a new wrapper was not created for this call
        assert wrapper_fn.call_count == 0
        assert mock_rpc.call_count == 2

@pytest.mark.asyncio
async def test_create_model_monitoring_job_async(transport: str = 'grpc_asyncio', request_type=model_monitoring_service.CreateModelMonitoringJobRequest):
    client = ModelMonitoringServiceAsyncClient(
        credentials=async_anonymous_credentials(),
        transport=transport,
    )

    # Everything is optional in proto3 as far as the runtime is concerned,
    # and we are mocking out the actual API, so just send an empty request.
    request = request_type()

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
            type(client.transport.create_model_monitoring_job),
            '__call__') as call:
        # Designate an appropriate return value for the call.
        call.return_value =grpc_helpers_async.FakeUnaryUnaryCall(gca_model_monitoring_job.ModelMonitoringJob(
            name='name_value',
            display_name='display_name_value',
            state=job_state.JobState.JOB_STATE_QUEUED,
            schedule='schedule_value',
        ))
        response = await client.create_model_monitoring_job(request)

        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls)
        _, args, _ = call.mock_calls[0]
        request = model_monitoring_service.CreateModelMonitoringJobRequest()
        assert args[0] == request

    # Establish that the response is the type that we expect.
    assert isinstance(response, gca_model_monitoring_job.ModelMonitoringJob)
    assert response.name == 'name_value'
    assert response.display_name == 'display_name_value'
    assert response.state == job_state.JobState.JOB_STATE_QUEUED
    assert response.schedule == 'schedule_value'


@pytest.mark.asyncio
async def test_create_model_monitoring_job_async_from_dict():
    await test_create_model_monitoring_job_async(request_type=dict)

def test_create_model_monitoring_job_field_headers():
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
    )

    # Any value that is part of the HTTP/1.1 URI should be sent as
    # a field header. Set these to a non-empty value.
    request = model_monitoring_service.CreateModelMonitoringJobRequest()

    request.parent = 'parent_value'

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
            type(client.transport.create_model_monitoring_job),
            '__call__') as call:
        call.return_value = gca_model_monitoring_job.ModelMonitoringJob()
        client.create_model_monitoring_job(request)

        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls) == 1
        _, args, _ = call.mock_calls[0]
        assert args[0] == request

    # Establish that the field header was sent.
    _, _, kw = call.mock_calls[0]
    assert (
        'x-goog-request-params',
        'parent=parent_value',
    ) in kw['metadata']


@pytest.mark.asyncio
async def test_create_model_monitoring_job_field_headers_async():
    client = ModelMonitoringServiceAsyncClient(
        credentials=async_anonymous_credentials(),
    )

    # Any value that is part of the HTTP/1.1 URI should be sent as
    # a field header. Set these to a non-empty value.
    request = model_monitoring_service.CreateModelMonitoringJobRequest()

    request.parent = 'parent_value'

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
            type(client.transport.create_model_monitoring_job),
            '__call__') as call:
        call.return_value = grpc_helpers_async.FakeUnaryUnaryCall(gca_model_monitoring_job.ModelMonitoringJob())
        await client.create_model_monitoring_job(request)

        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls)
        _, args, _ = call.mock_calls[0]
        assert args[0] == request

    # Establish that the field header was sent.
    _, _, kw = call.mock_calls[0]
    assert (
        'x-goog-request-params',
        'parent=parent_value',
    ) in kw['metadata']


def test_create_model_monitoring_job_flattened():
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
    )

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
            type(client.transport.create_model_monitoring_job),
            '__call__') as call:
        # Designate an appropriate return value for the call.
        call.return_value = gca_model_monitoring_job.ModelMonitoringJob()
        # Call the method with a truthy value for each flattened field,
        # using the keyword arguments to the method.
        client.create_model_monitoring_job(
            parent='parent_value',
            model_monitoring_job=gca_model_monitoring_job.ModelMonitoringJob(name='name_value'),
        )

        # Establish that the underlying call was made with the expected
        # request object values.
        assert len(call.mock_calls) == 1
        _, args, _ = call.mock_calls[0]
        arg = args[0].parent
        mock_val = 'parent_value'
        assert arg == mock_val
        arg = args[0].model_monitoring_job
        mock_val = gca_model_monitoring_job.ModelMonitoringJob(name='name_value')
        assert arg == mock_val


def test_create_model_monitoring_job_flattened_error():
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
    )

    # Attempting to call a method with both a request object and flattened
    # fields is an error.
    with pytest.raises(ValueError):
        client.create_model_monitoring_job(
            model_monitoring_service.CreateModelMonitoringJobRequest(),
            parent='parent_value',
            model_monitoring_job=gca_model_monitoring_job.ModelMonitoringJob(name='name_value'),
        )

@pytest.mark.asyncio
async def test_create_model_monitoring_job_flattened_async():
    client = ModelMonitoringServiceAsyncClient(
        credentials=async_anonymous_credentials(),
    )

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
            type(client.transport.create_model_monitoring_job),
            '__call__') as call:
        # Designate an appropriate return value for the call.
        call.return_value = gca_model_monitoring_job.ModelMonitoringJob()

        call.return_value = grpc_helpers_async.FakeUnaryUnaryCall(gca_model_monitoring_job.ModelMonitoringJob())
        # Call the method with a truthy value for each flattened field,
        # using the keyword arguments to the method.
        response = await client.create_model_monitoring_job(
            parent='parent_value',
            model_monitoring_job=gca_model_monitoring_job.ModelMonitoringJob(name='name_value'),
        )

        # Establish that the underlying call was made with the expected
        # request object values.
        assert len(call.mock_calls)
        _, args, _ = call.mock_calls[0]
        arg = args[0].parent
        mock_val = 'parent_value'
        assert arg == mock_val
        arg = args[0].model_monitoring_job
        mock_val = gca_model_monitoring_job.ModelMonitoringJob(name='name_value')
        assert arg == mock_val

@pytest.mark.asyncio
async def test_create_model_monitoring_job_flattened_error_async():
    client = ModelMonitoringServiceAsyncClient(
        credentials=async_anonymous_credentials(),
    )

    # Attempting to call a method with both a request object and flattened
    # fields is an error.
    with pytest.raises(ValueError):
        await client.create_model_monitoring_job(
            model_monitoring_service.CreateModelMonitoringJobRequest(),
            parent='parent_value',
            model_monitoring_job=gca_model_monitoring_job.ModelMonitoringJob(name='name_value'),
        )


@pytest.mark.parametrize("request_type", [
  model_monitoring_service.GetModelMonitoringJobRequest,
  dict,
])
def test_get_model_monitoring_job(request_type, transport: str = 'grpc'):
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport=transport,
    )

    # Everything is optional in proto3 as far as the runtime is concerned,
    # and we are mocking out the actual API, so just send an empty request.
    request = request_type()

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
            type(client.transport.get_model_monitoring_job),
            '__call__') as call:
        # Designate an appropriate return value for the call.
        call.return_value = model_monitoring_job.ModelMonitoringJob(
            name='name_value',
            display_name='display_name_value',
            state=job_state.JobState.JOB_STATE_QUEUED,
            schedule='schedule_value',
        )
        response = client.get_model_monitoring_job(request)

        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls) == 1
        _, args, _ = call.mock_calls[0]
        request = model_monitoring_service.GetModelMonitoringJobRequest()
        assert args[0] == request

    # Establish that the response is the type that we expect.
    assert isinstance(response, model_monitoring_job.ModelMonitoringJob)
    assert response.name == 'name_value'
    assert response.display_name == 'display_name_value'
    assert response.state == job_state.JobState.JOB_STATE_QUEUED
    assert response.schedule == 'schedule_value'


def test_get_model_monitoring_job_non_empty_request_with_auto_populated_field():
    # This test is a coverage failsafe to make sure that UUID4 fields are
    # automatically populated, according to AIP-4235, with non-empty requests.
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport='grpc',
    )

    # Populate all string fields in the request which are not UUID4
    # since we want to check that UUID4 are populated automatically
    # if they meet the requirements of AIP 4235.
    request = model_monitoring_service.GetModelMonitoringJobRequest(
        name='name_value',
    )

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
            type(client.transport.get_model_monitoring_job),
            '__call__') as call:
        call.return_value.name = "foo" # operation_request.operation in compute client(s) expect a string.
        client.get_model_monitoring_job(request=request)
        call.assert_called()
        _, args, _ = call.mock_calls[0]
        assert args[0] == model_monitoring_service.GetModelMonitoringJobRequest(
            name='name_value',
        )

def test_get_model_monitoring_job_use_cached_wrapped_rpc():
    # Clients should use _prep_wrapped_messages to create cached wrapped rpcs,
    # instead of constructing them on each call
    with mock.patch("google.api_core.gapic_v1.method.wrap_method") as wrapper_fn:
        client = ModelMonitoringServiceClient(
            credentials=ga_credentials.AnonymousCredentials(),
            transport="grpc",
        )

        # Should wrap all calls on client creation
        assert wrapper_fn.call_count > 0
        wrapper_fn.reset_mock()

        # Ensure method has been cached
        assert client._transport.get_model_monitoring_job in client._transport._wrapped_methods

        # Replace cached wrapped function with mock
        mock_rpc = mock.Mock()
        mock_rpc.return_value.name = "foo" # operation_request.operation in compute client(s) expect a string.
        client._transport._wrapped_methods[client._transport.get_model_monitoring_job] = mock_rpc
        request = {}
        client.get_model_monitoring_job(request)

        # Establish that the underlying gRPC stub method was called.
        assert mock_rpc.call_count == 1

        client.get_model_monitoring_job(request)

        # Establish that a new wrapper was not created for this call
        assert wrapper_fn.call_count == 0
        assert mock_rpc.call_count == 2

@pytest.mark.asyncio
async def test_get_model_monitoring_job_async_use_cached_wrapped_rpc(transport: str = "grpc_asyncio"):
    # Clients should use _prep_wrapped_messages to create cached wrapped rpcs,
    # instead of constructing them on each call
    with mock.patch("google.api_core.gapic_v1.method_async.wrap_method") as wrapper_fn:
        client = ModelMonitoringServiceAsyncClient(
            credentials=async_anonymous_credentials(),
            transport=transport,
        )

        # Should wrap all calls on client creation
        assert wrapper_fn.call_count > 0
        wrapper_fn.reset_mock()

        # Ensure method has been cached
        assert client._client._transport.get_model_monitoring_job in client._client._transport._wrapped_methods

        # Replace cached wrapped function with mock
        mock_rpc = mock.AsyncMock()
        mock_rpc.return_value = mock.Mock()
        client._client._transport._wrapped_methods[client._client._transport.get_model_monitoring_job] = mock_rpc

        request = {}
        await client.get_model_monitoring_job(request)

        # Establish that the underlying gRPC stub method was called.
        assert mock_rpc.call_count == 1

        await client.get_model_monitoring_job(request)

        # Establish that a new wrapper was not created for this call
        assert wrapper_fn.call_count == 0
        assert mock_rpc.call_count == 2

@pytest.mark.asyncio
async def test_get_model_monitoring_job_async(transport: str = 'grpc_asyncio', request_type=model_monitoring_service.GetModelMonitoringJobRequest):
    client = ModelMonitoringServiceAsyncClient(
        credentials=async_anonymous_credentials(),
        transport=transport,
    )

    # Everything is optional in proto3 as far as the runtime is concerned,
    # and we are mocking out the actual API, so just send an empty request.
    request = request_type()

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
            type(client.transport.get_model_monitoring_job),
            '__call__') as call:
        # Designate an appropriate return value for the call.
        call.return_value =grpc_helpers_async.FakeUnaryUnaryCall(model_monitoring_job.ModelMonitoringJob(
            name='name_value',
            display_name='display_name_value',
            state=job_state.JobState.JOB_STATE_QUEUED,
            schedule='schedule_value',
        ))
        response = await client.get_model_monitoring_job(request)

        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls)
        _, args, _ = call.mock_calls[0]
        request = model_monitoring_service.GetModelMonitoringJobRequest()
        assert args[0] == request

    # Establish that the response is the type that we expect.
    assert isinstance(response, model_monitoring_job.ModelMonitoringJob)
    assert response.name == 'name_value'
    assert response.display_name == 'display_name_value'
    assert response.state == job_state.JobState.JOB_STATE_QUEUED
    assert response.schedule == 'schedule_value'


@pytest.mark.asyncio
async def test_get_model_monitoring_job_async_from_dict():
    await test_get_model_monitoring_job_async(request_type=dict)

def test_get_model_monitoring_job_field_headers():
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
    )

    # Any value that is part of the HTTP/1.1 URI should be sent as
    # a field header. Set these to a non-empty value.
    request = model_monitoring_service.GetModelMonitoringJobRequest()

    request.name = 'name_value'

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
            type(client.transport.get_model_monitoring_job),
            '__call__') as call:
        call.return_value = model_monitoring_job.ModelMonitoringJob()
        client.get_model_monitoring_job(request)

        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls) == 1
        _, args, _ = call.mock_calls[0]
        assert args[0] == request

    # Establish that the field header was sent.
    _, _, kw = call.mock_calls[0]
    assert (
        'x-goog-request-params',
        'name=name_value',
    ) in kw['metadata']


@pytest.mark.asyncio
async def test_get_model_monitoring_job_field_headers_async():
    client = ModelMonitoringServiceAsyncClient(
        credentials=async_anonymous_credentials(),
    )

    # Any value that is part of the HTTP/1.1 URI should be sent as
    # a field header. Set these to a non-empty value.
    request = model_monitoring_service.GetModelMonitoringJobRequest()

    request.name = 'name_value'

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
            type(client.transport.get_model_monitoring_job),
            '__call__') as call:
        call.return_value = grpc_helpers_async.FakeUnaryUnaryCall(model_monitoring_job.ModelMonitoringJob())
        await client.get_model_monitoring_job(request)

        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls)
        _, args, _ = call.mock_calls[0]
        assert args[0] == request

    # Establish that the field header was sent.
    _, _, kw = call.mock_calls[0]
    assert (
        'x-goog-request-params',
        'name=name_value',
    ) in kw['metadata']


def test_get_model_monitoring_job_flattened():
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
    )

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
            type(client.transport.get_model_monitoring_job),
            '__call__') as call:
        # Designate an appropriate return value for the call.
        call.return_value = model_monitoring_job.ModelMonitoringJob()
        # Call the method with a truthy value for each flattened field,
        # using the keyword arguments to the method.
        client.get_model_monitoring_job(
            name='name_value',
        )

        # Establish that the underlying call was made with the expected
        # request object values.
        assert len(call.mock_calls) == 1
        _, args, _ = call.mock_calls[0]
        arg = args[0].name
        mock_val = 'name_value'
        assert arg == mock_val


def test_get_model_monitoring_job_flattened_error():
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
    )

    # Attempting to call a method with both a request object and flattened
    # fields is an error.
    with pytest.raises(ValueError):
        client.get_model_monitoring_job(
            model_monitoring_service.GetModelMonitoringJobRequest(),
            name='name_value',
        )

@pytest.mark.asyncio
async def test_get_model_monitoring_job_flattened_async():
    client = ModelMonitoringServiceAsyncClient(
        credentials=async_anonymous_credentials(),
    )

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
            type(client.transport.get_model_monitoring_job),
            '__call__') as call:
        # Designate an appropriate return value for the call.
        call.return_value = model_monitoring_job.ModelMonitoringJob()

        call.return_value = grpc_helpers_async.FakeUnaryUnaryCall(model_monitoring_job.ModelMonitoringJob())
        # Call the method with a truthy value for each flattened field,
        # using the keyword arguments to the method.
        response = await client.get_model_monitoring_job(
            name='name_value',
        )

        # Establish that the underlying call was made with the expected
        # request object values.
        assert len(call.mock_calls)
        _, args, _ = call.mock_calls[0]
        arg = args[0].name
        mock_val = 'name_value'
        assert arg == mock_val

@pytest.mark.asyncio
async def test_get_model_monitoring_job_flattened_error_async():
    client = ModelMonitoringServiceAsyncClient(
        credentials=async_anonymous_credentials(),
    )

    # Attempting to call a method with both a request object and flattened
    # fields is an error.
    with pytest.raises(ValueError):
        await client.get_model_monitoring_job(
            model_monitoring_service.GetModelMonitoringJobRequest(),
            name='name_value',
        )


@pytest.mark.parametrize("request_type", [
  model_monitoring_service.ListModelMonitoringJobsRequest,
  dict,
])
def test_list_model_monitoring_jobs(request_type, transport: str = 'grpc'):
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport=transport,
    )

    # Everything is optional in proto3 as far as the runtime is concerned,
    # and we are mocking out the actual API, so just send an empty request.
    request = request_type()

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
            type(client.transport.list_model_monitoring_jobs),
            '__call__') as call:
        # Designate an appropriate return value for the call.
        call.return_value = model_monitoring_service.ListModelMonitoringJobsResponse(
            next_page_token='next_page_token_value',
        )
        response = client.list_model_monitoring_jobs(request)

        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls) == 1
        _, args, _ = call.mock_calls[0]
        request = model_monitoring_service.ListModelMonitoringJobsRequest()
        assert args[0] == request

    # Establish that the response is the type that we expect.
    assert isinstance(response, pagers.ListModelMonitoringJobsPager)
    assert response.next_page_token == 'next_page_token_value'


def test_list_model_monitoring_jobs_non_empty_request_with_auto_populated_field():
    # This test is a coverage failsafe to make sure that UUID4 fields are
    # automatically populated, according to AIP-4235, with non-empty requests.
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport='grpc',
    )

    # Populate all string fields in the request which are not UUID4
    # since we want to check that UUID4 are populated automatically
    # if they meet the requirements of AIP 4235.
    request = model_monitoring_service.ListModelMonitoringJobsRequest(
        parent='parent_value',
        filter='filter_value',
        page_token='page_token_value',
    )

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
            type(client.transport.list_model_monitoring_jobs),
            '__call__') as call:
        call.return_value.name = "foo" # operation_request.operation in compute client(s) expect a string.
        client.list_model_monitoring_jobs(request=request)
        call.assert_called()
        _, args, _ = call.mock_calls[0]
        assert args[0] == model_monitoring_service.ListModelMonitoringJobsRequest(
            parent='parent_value',
            filter='filter_value',
            page_token='page_token_value',
        )

def test_list_model_monitoring_jobs_use_cached_wrapped_rpc():
    # Clients should use _prep_wrapped_messages to create cached wrapped rpcs,
    # instead of constructing them on each call
    with mock.patch("google.api_core.gapic_v1.method.wrap_method") as wrapper_fn:
        client = ModelMonitoringServiceClient(
            credentials=ga_credentials.AnonymousCredentials(),
            transport="grpc",
        )

        # Should wrap all calls on client creation
        assert wrapper_fn.call_count > 0
        wrapper_fn.reset_mock()

        # Ensure method has been cached
        assert client._transport.list_model_monitoring_jobs in client._transport._wrapped_methods

        # Replace cached wrapped function with mock
        mock_rpc = mock.Mock()
        mock_rpc.return_value.name = "foo" # operation_request.operation in compute client(s) expect a string.
        client._transport._wrapped_methods[client._transport.list_model_monitoring_jobs] = mock_rpc
        request = {}
        client.list_model_monitoring_jobs(request)

        # Establish that the underlying gRPC stub method was called.
        assert mock_rpc.call_count == 1

        client.list_model_monitoring_jobs(request)

        # Establish that a new wrapper was not created for this call
        assert wrapper_fn.call_count == 0
        assert mock_rpc.call_count == 2

@pytest.mark.asyncio
async def test_list_model_monitoring_jobs_async_use_cached_wrapped_rpc(transport: str = "grpc_asyncio"):
    # Clients should use _prep_wrapped_messages to create cached wrapped rpcs,
    # instead of constructing them on each call
    with mock.patch("google.api_core.gapic_v1.method_async.wrap_method") as wrapper_fn:
        client = ModelMonitoringServiceAsyncClient(
            credentials=async_anonymous_credentials(),
            transport=transport,
        )

        # Should wrap all calls on client creation
        assert wrapper_fn.call_count > 0
        wrapper_fn.reset_mock()

        # Ensure method has been cached
        assert client._client._transport.list_model_monitoring_jobs in client._client._transport._wrapped_methods

        # Replace cached wrapped function with mock
        mock_rpc = mock.AsyncMock()
        mock_rpc.return_value = mock.Mock()
        client._client._transport._wrapped_methods[client._client._transport.list_model_monitoring_jobs] = mock_rpc

        request = {}
        await client.list_model_monitoring_jobs(request)

        # Establish that the underlying gRPC stub method was called.
        assert mock_rpc.call_count == 1

        await client.list_model_monitoring_jobs(request)

        # Establish that a new wrapper was not created for this call
        assert wrapper_fn.call_count == 0
        assert mock_rpc.call_count == 2

@pytest.mark.asyncio
async def test_list_model_monitoring_jobs_async(transport: str = 'grpc_asyncio', request_type=model_monitoring_service.ListModelMonitoringJobsRequest):
    client = ModelMonitoringServiceAsyncClient(
        credentials=async_anonymous_credentials(),
        transport=transport,
    )

    # Everything is optional in proto3 as far as the runtime is concerned,
    # and we are mocking out the actual API, so just send an empty request.
    request = request_type()

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
            type(client.transport.list_model_monitoring_jobs),
            '__call__') as call:
        # Designate an appropriate return value for the call.
        call.return_value =grpc_helpers_async.FakeUnaryUnaryCall(model_monitoring_service.ListModelMonitoringJobsResponse(
            next_page_token='next_page_token_value',
        ))
        response = await client.list_model_monitoring_jobs(request)

        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls)
        _, args, _ = call.mock_calls[0]
        request = model_monitoring_service.ListModelMonitoringJobsRequest()
        assert args[0] == request

    # Establish that the response is the type that we expect.
    assert isinstance(response, pagers.ListModelMonitoringJobsAsyncPager)
    assert response.next_page_token == 'next_page_token_value'


@pytest.mark.asyncio
async def test_list_model_monitoring_jobs_async_from_dict():
    await test_list_model_monitoring_jobs_async(request_type=dict)

def test_list_model_monitoring_jobs_field_headers():
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
    )

    # Any value that is part of the HTTP/1.1 URI should be sent as
    # a field header. Set these to a non-empty value.
    request = model_monitoring_service.ListModelMonitoringJobsRequest()

    request.parent = 'parent_value'

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
            type(client.transport.list_model_monitoring_jobs),
            '__call__') as call:
        call.return_value = model_monitoring_service.ListModelMonitoringJobsResponse()
        client.list_model_monitoring_jobs(request)

        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls) == 1
        _, args, _ = call.mock_calls[0]
        assert args[0] == request

    # Establish that the field header was sent.
    _, _, kw = call.mock_calls[0]
    assert (
        'x-goog-request-params',
        'parent=parent_value',
    ) in kw['metadata']


@pytest.mark.asyncio
async def test_list_model_monitoring_jobs_field_headers_async():
    client = ModelMonitoringServiceAsyncClient(
        credentials=async_anonymous_credentials(),
    )

    # Any value that is part of the HTTP/1.1 URI should be sent as
    # a field header. Set these to a non-empty value.
    request = model_monitoring_service.ListModelMonitoringJobsRequest()

    request.parent = 'parent_value'

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
            type(client.transport.list_model_monitoring_jobs),
            '__call__') as call:
        call.return_value = grpc_helpers_async.FakeUnaryUnaryCall(model_monitoring_service.ListModelMonitoringJobsResponse())
        await client.list_model_monitoring_jobs(request)

        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls)
        _, args, _ = call.mock_calls[0]
        assert args[0] == request

    # Establish that the field header was sent.
    _, _, kw = call.mock_calls[0]
    assert (
        'x-goog-request-params',
        'parent=parent_value',
    ) in kw['metadata']


def test_list_model_monitoring_jobs_flattened():
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
    )

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
            type(client.transport.list_model_monitoring_jobs),
            '__call__') as call:
        # Designate an appropriate return value for the call.
        call.return_value = model_monitoring_service.ListModelMonitoringJobsResponse()
        # Call the method with a truthy value for each flattened field,
        # using the keyword arguments to the method.
        client.list_model_monitoring_jobs(
            parent='parent_value',
        )

        # Establish that the underlying call was made with the expected
        # request object values.
        assert len(call.mock_calls) == 1
        _, args, _ = call.mock_calls[0]
        arg = args[0].parent
        mock_val = 'parent_value'
        assert arg == mock_val


def test_list_model_monitoring_jobs_flattened_error():
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
    )

    # Attempting to call a method with both a request object and flattened
    # fields is an error.
    with pytest.raises(ValueError):
        client.list_model_monitoring_jobs(
            model_monitoring_service.ListModelMonitoringJobsRequest(),
            parent='parent_value',
        )

@pytest.mark.asyncio
async def test_list_model_monitoring_jobs_flattened_async():
    client = ModelMonitoringServiceAsyncClient(
        credentials=async_anonymous_credentials(),
    )

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
            type(client.transport.list_model_monitoring_jobs),
            '__call__') as call:
        # Designate an appropriate return value for the call.
        call.return_value = model_monitoring_service.ListModelMonitoringJobsResponse()

        call.return_value = grpc_helpers_async.FakeUnaryUnaryCall(model_monitoring_service.ListModelMonitoringJobsResponse())
        # Call the method with a truthy value for each flattened field,
        # using the keyword arguments to the method.
        response = await client.list_model_monitoring_jobs(
            parent='parent_value',
        )

        # Establish that the underlying call was made with the expected
        # request object values.
        assert len(call.mock_calls)
        _, args, _ = call.mock_calls[0]
        arg = args[0].parent
        mock_val = 'parent_value'
        assert arg == mock_val

@pytest.mark.asyncio
async def test_list_model_monitoring_jobs_flattened_error_async():
    client = ModelMonitoringServiceAsyncClient(
        credentials=async_anonymous_credentials(),
    )

    # Attempting to call a method with both a request object and flattened
    # fields is an error.
    with pytest.raises(ValueError):
        await client.list_model_monitoring_jobs(
            model_monitoring_service.ListModelMonitoringJobsRequest(),
            parent='parent_value',
        )


def test_list_model_monitoring_jobs_pager(transport_name: str = "grpc"):
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport=transport_name,
    )

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
            type(client.transport.list_model_monitoring_jobs),
            '__call__') as call:
        # Set the response to a series of pages.
        call.side_effect = (
            model_monitoring_service.ListModelMonitoringJobsResponse(
                model_monitoring_jobs=[
                    model_monitoring_job.ModelMonitoringJob(),
                    model_monitoring_job.ModelMonitoringJob(),
                    model_monitoring_job.ModelMonitoringJob(),
                ],
                next_page_token='abc',
            ),
            model_monitoring_service.ListModelMonitoringJobsResponse(
                model_monitoring_jobs=[],
                next_page_token='def',
            ),
            model_monitoring_service.ListModelMonitoringJobsResponse(
                model_monitoring_jobs=[
                    model_monitoring_job.ModelMonitoringJob(),
                ],
                next_page_token='ghi',
            ),
            model_monitoring_service.ListModelMonitoringJobsResponse(
                model_monitoring_jobs=[
                    model_monitoring_job.ModelMonitoringJob(),
                    model_monitoring_job.ModelMonitoringJob(),
                ],
            ),
            RuntimeError,
        )

        expected_metadata = ()
        retry = retries.Retry()
        timeout = 5
        expected_metadata = tuple(expected_metadata) + (
            gapic_v1.routing_header.to_grpc_metadata((
                ('parent', ''),
            )),
        )
        pager = client.list_model_monitoring_jobs(request={}, retry=retry, timeout=timeout)

        assert pager._metadata == expected_metadata
        assert pager._retry == retry
        assert pager._timeout == timeout

        results = list(pager)
        assert len(results) == 6
        assert all(isinstance(i, model_monitoring_job.ModelMonitoringJob)
                   for i in results)
def test_list_model_monitoring_jobs_pages(transport_name: str = "grpc"):
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport=transport_name,
    )

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
            type(client.transport.list_model_monitoring_jobs),
            '__call__') as call:
        # Set the response to a series of pages.
        call.side_effect = (
            model_monitoring_service.ListModelMonitoringJobsResponse(
                model_monitoring_jobs=[
                    model_monitoring_job.ModelMonitoringJob(),
                    model_monitoring_job.ModelMonitoringJob(),
                    model_monitoring_job.ModelMonitoringJob(),
                ],
                next_page_token='abc',
            ),
            model_monitoring_service.ListModelMonitoringJobsResponse(
                model_monitoring_jobs=[],
                next_page_token='def',
            ),
            model_monitoring_service.ListModelMonitoringJobsResponse(
                model_monitoring_jobs=[
                    model_monitoring_job.ModelMonitoringJob(),
                ],
                next_page_token='ghi',
            ),
            model_monitoring_service.ListModelMonitoringJobsResponse(
                model_monitoring_jobs=[
                    model_monitoring_job.ModelMonitoringJob(),
                    model_monitoring_job.ModelMonitoringJob(),
                ],
            ),
            RuntimeError,
        )
        pages = list(client.list_model_monitoring_jobs(request={}).pages)
        for page_, token in zip(pages, ['abc','def','ghi', '']):
            assert page_.raw_page.next_page_token == token

@pytest.mark.asyncio
async def test_list_model_monitoring_jobs_async_pager():
    client = ModelMonitoringServiceAsyncClient(
        credentials=async_anonymous_credentials(),
    )

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
            type(client.transport.list_model_monitoring_jobs),
            '__call__', new_callable=mock.AsyncMock) as call:
        # Set the response to a series of pages.
        call.side_effect = (
            model_monitoring_service.ListModelMonitoringJobsResponse(
                model_monitoring_jobs=[
                    model_monitoring_job.ModelMonitoringJob(),
                    model_monitoring_job.ModelMonitoringJob(),
                    model_monitoring_job.ModelMonitoringJob(),
                ],
                next_page_token='abc',
            ),
            model_monitoring_service.ListModelMonitoringJobsResponse(
                model_monitoring_jobs=[],
                next_page_token='def',
            ),
            model_monitoring_service.ListModelMonitoringJobsResponse(
                model_monitoring_jobs=[
                    model_monitoring_job.ModelMonitoringJob(),
                ],
                next_page_token='ghi',
            ),
            model_monitoring_service.ListModelMonitoringJobsResponse(
                model_monitoring_jobs=[
                    model_monitoring_job.ModelMonitoringJob(),
                    model_monitoring_job.ModelMonitoringJob(),
                ],
            ),
            RuntimeError,
        )
        async_pager = await client.list_model_monitoring_jobs(request={},)
        assert async_pager.next_page_token == 'abc'
        responses = []
        async for response in async_pager: # pragma: no branch
            responses.append(response)

        assert len(responses) == 6
        assert all(isinstance(i, model_monitoring_job.ModelMonitoringJob)
                for i in responses)


@pytest.mark.asyncio
async def test_list_model_monitoring_jobs_async_pages():
    client = ModelMonitoringServiceAsyncClient(
        credentials=async_anonymous_credentials(),
    )

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
            type(client.transport.list_model_monitoring_jobs),
            '__call__', new_callable=mock.AsyncMock) as call:
        # Set the response to a series of pages.
        call.side_effect = (
            model_monitoring_service.ListModelMonitoringJobsResponse(
                model_monitoring_jobs=[
                    model_monitoring_job.ModelMonitoringJob(),
                    model_monitoring_job.ModelMonitoringJob(),
                    model_monitoring_job.ModelMonitoringJob(),
                ],
                next_page_token='abc',
            ),
            model_monitoring_service.ListModelMonitoringJobsResponse(
                model_monitoring_jobs=[],
                next_page_token='def',
            ),
            model_monitoring_service.ListModelMonitoringJobsResponse(
                model_monitoring_jobs=[
                    model_monitoring_job.ModelMonitoringJob(),
                ],
                next_page_token='ghi',
            ),
            model_monitoring_service.ListModelMonitoringJobsResponse(
                model_monitoring_jobs=[
                    model_monitoring_job.ModelMonitoringJob(),
                    model_monitoring_job.ModelMonitoringJob(),
                ],
            ),
            RuntimeError,
        )
        pages = []
        # Workaround issue in python 3.9 related to code coverage by adding `# pragma: no branch`
        # See https://github.com/googleapis/gapic-generator-python/pull/1174#issuecomment-1025132372
        async for page_ in ( # pragma: no branch
            await client.list_model_monitoring_jobs(request={})
        ).pages:
            pages.append(page_)
        for page_, token in zip(pages, ['abc','def','ghi', '']):
            assert page_.raw_page.next_page_token == token

@pytest.mark.parametrize("request_type", [
  model_monitoring_service.DeleteModelMonitoringJobRequest,
  dict,
])
def test_delete_model_monitoring_job(request_type, transport: str = 'grpc'):
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport=transport,
    )

    # Everything is optional in proto3 as far as the runtime is concerned,
    # and we are mocking out the actual API, so just send an empty request.
    request = request_type()

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
            type(client.transport.delete_model_monitoring_job),
            '__call__') as call:
        # Designate an appropriate return value for the call.
        call.return_value = operations_pb2.Operation(name='operations/spam')
        response = client.delete_model_monitoring_job(request)

        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls) == 1
        _, args, _ = call.mock_calls[0]
        request = model_monitoring_service.DeleteModelMonitoringJobRequest()
        assert args[0] == request

    # Establish that the response is the type that we expect.
    assert isinstance(response, future.Future)


def test_delete_model_monitoring_job_non_empty_request_with_auto_populated_field():
    # This test is a coverage failsafe to make sure that UUID4 fields are
    # automatically populated, according to AIP-4235, with non-empty requests.
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport='grpc',
    )

    # Populate all string fields in the request which are not UUID4
    # since we want to check that UUID4 are populated automatically
    # if they meet the requirements of AIP 4235.
    request = model_monitoring_service.DeleteModelMonitoringJobRequest(
        name='name_value',
    )

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
            type(client.transport.delete_model_monitoring_job),
            '__call__') as call:
        call.return_value.name = "foo" # operation_request.operation in compute client(s) expect a string.
        client.delete_model_monitoring_job(request=request)
        call.assert_called()
        _, args, _ = call.mock_calls[0]
        assert args[0] == model_monitoring_service.DeleteModelMonitoringJobRequest(
            name='name_value',
        )

def test_delete_model_monitoring_job_use_cached_wrapped_rpc():
    # Clients should use _prep_wrapped_messages to create cached wrapped rpcs,
    # instead of constructing them on each call
    with mock.patch("google.api_core.gapic_v1.method.wrap_method") as wrapper_fn:
        client = ModelMonitoringServiceClient(
            credentials=ga_credentials.AnonymousCredentials(),
            transport="grpc",
        )

        # Should wrap all calls on client creation
        assert wrapper_fn.call_count > 0
        wrapper_fn.reset_mock()

        # Ensure method has been cached
        assert client._transport.delete_model_monitoring_job in client._transport._wrapped_methods

        # Replace cached wrapped function with mock
        mock_rpc = mock.Mock()
        mock_rpc.return_value.name = "foo" # operation_request.operation in compute client(s) expect a string.
        client._transport._wrapped_methods[client._transport.delete_model_monitoring_job] = mock_rpc
        request = {}
        client.delete_model_monitoring_job(request)

        # Establish that the underlying gRPC stub method was called.
        assert mock_rpc.call_count == 1

        # Operation methods call wrapper_fn to build a cached
        # client._transport.operations_client instance on first rpc call.
        # Subsequent calls should use the cached wrapper
        wrapper_fn.reset_mock()

        client.delete_model_monitoring_job(request)

        # Establish that a new wrapper was not created for this call
        assert wrapper_fn.call_count == 0
        assert mock_rpc.call_count == 2

@pytest.mark.asyncio
async def test_delete_model_monitoring_job_async_use_cached_wrapped_rpc(transport: str = "grpc_asyncio"):
    # Clients should use _prep_wrapped_messages to create cached wrapped rpcs,
    # instead of constructing them on each call
    with mock.patch("google.api_core.gapic_v1.method_async.wrap_method") as wrapper_fn:
        client = ModelMonitoringServiceAsyncClient(
            credentials=async_anonymous_credentials(),
            transport=transport,
        )

        # Should wrap all calls on client creation
        assert wrapper_fn.call_count > 0
        wrapper_fn.reset_mock()

        # Ensure method has been cached
        assert client._client._transport.delete_model_monitoring_job in client._client._transport._wrapped_methods

        # Replace cached wrapped function with mock
        mock_rpc = mock.AsyncMock()
        mock_rpc.return_value = mock.Mock()
        client._client._transport._wrapped_methods[client._client._transport.delete_model_monitoring_job] = mock_rpc

        request = {}
        await client.delete_model_monitoring_job(request)

        # Establish that the underlying gRPC stub method was called.
        assert mock_rpc.call_count == 1

        # Operation methods call wrapper_fn to build a cached
        # client._transport.operations_client instance on first rpc call.
        # Subsequent calls should use the cached wrapper
        wrapper_fn.reset_mock()

        await client.delete_model_monitoring_job(request)

        # Establish that a new wrapper was not created for this call
        assert wrapper_fn.call_count == 0
        assert mock_rpc.call_count == 2

@pytest.mark.asyncio
async def test_delete_model_monitoring_job_async(transport: str = 'grpc_asyncio', request_type=model_monitoring_service.DeleteModelMonitoringJobRequest):
    client = ModelMonitoringServiceAsyncClient(
        credentials=async_anonymous_credentials(),
        transport=transport,
    )

    # Everything is optional in proto3 as far as the runtime is concerned,
    # and we are mocking out the actual API, so just send an empty request.
    request = request_type()

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
            type(client.transport.delete_model_monitoring_job),
            '__call__') as call:
        # Designate an appropriate return value for the call.
        call.return_value = grpc_helpers_async.FakeUnaryUnaryCall(
            operations_pb2.Operation(name='operations/spam')
        )
        response = await client.delete_model_monitoring_job(request)

        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls)
        _, args, _ = call.mock_calls[0]
        request = model_monitoring_service.DeleteModelMonitoringJobRequest()
        assert args[0] == request

    # Establish that the response is the type that we expect.
    assert isinstance(response, future.Future)


@pytest.mark.asyncio
async def test_delete_model_monitoring_job_async_from_dict():
    await test_delete_model_monitoring_job_async(request_type=dict)

def test_delete_model_monitoring_job_field_headers():
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
    )

    # Any value that is part of the HTTP/1.1 URI should be sent as
    # a field header. Set these to a non-empty value.
    request = model_monitoring_service.DeleteModelMonitoringJobRequest()

    request.name = 'name_value'

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
            type(client.transport.delete_model_monitoring_job),
            '__call__') as call:
        call.return_value = operations_pb2.Operation(name='operations/op')
        client.delete_model_monitoring_job(request)

        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls) == 1
        _, args, _ = call.mock_calls[0]
        assert args[0] == request

    # Establish that the field header was sent.
    _, _, kw = call.mock_calls[0]
    assert (
        'x-goog-request-params',
        'name=name_value',
    ) in kw['metadata']


@pytest.mark.asyncio
async def test_delete_model_monitoring_job_field_headers_async():
    client = ModelMonitoringServiceAsyncClient(
        credentials=async_anonymous_credentials(),
    )

    # Any value that is part of the HTTP/1.1 URI should be sent as
    # a field header. Set these to a non-empty value.
    request = model_monitoring_service.DeleteModelMonitoringJobRequest()

    request.name = 'name_value'

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
            type(client.transport.delete_model_monitoring_job),
            '__call__') as call:
        call.return_value = grpc_helpers_async.FakeUnaryUnaryCall(operations_pb2.Operation(name='operations/op'))
        await client.delete_model_monitoring_job(request)

        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls)
        _, args, _ = call.mock_calls[0]
        assert args[0] == request

    # Establish that the field header was sent.
    _, _, kw = call.mock_calls[0]
    assert (
        'x-goog-request-params',
        'name=name_value',
    ) in kw['metadata']


def test_delete_model_monitoring_job_flattened():
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
    )

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
            type(client.transport.delete_model_monitoring_job),
            '__call__') as call:
        # Designate an appropriate return value for the call.
        call.return_value = operations_pb2.Operation(name='operations/op')
        # Call the method with a truthy value for each flattened field,
        # using the keyword arguments to the method.
        client.delete_model_monitoring_job(
            name='name_value',
        )

        # Establish that the underlying call was made with the expected
        # request object values.
        assert len(call.mock_calls) == 1
        _, args, _ = call.mock_calls[0]
        arg = args[0].name
        mock_val = 'name_value'
        assert arg == mock_val


def test_delete_model_monitoring_job_flattened_error():
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
    )

    # Attempting to call a method with both a request object and flattened
    # fields is an error.
    with pytest.raises(ValueError):
        client.delete_model_monitoring_job(
            model_monitoring_service.DeleteModelMonitoringJobRequest(),
            name='name_value',
        )

@pytest.mark.asyncio
async def test_delete_model_monitoring_job_flattened_async():
    client = ModelMonitoringServiceAsyncClient(
        credentials=async_anonymous_credentials(),
    )

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
            type(client.transport.delete_model_monitoring_job),
            '__call__') as call:
        # Designate an appropriate return value for the call.
        call.return_value = operations_pb2.Operation(name='operations/op')

        call.return_value = grpc_helpers_async.FakeUnaryUnaryCall(
            operations_pb2.Operation(name='operations/spam')
        )
        # Call the method with a truthy value for each flattened field,
        # using the keyword arguments to the method.
        response = await client.delete_model_monitoring_job(
            name='name_value',
        )

        # Establish that the underlying call was made with the expected
        # request object values.
        assert len(call.mock_calls)
        _, args, _ = call.mock_calls[0]
        arg = args[0].name
        mock_val = 'name_value'
        assert arg == mock_val

@pytest.mark.asyncio
async def test_delete_model_monitoring_job_flattened_error_async():
    client = ModelMonitoringServiceAsyncClient(
        credentials=async_anonymous_credentials(),
    )

    # Attempting to call a method with both a request object and flattened
    # fields is an error.
    with pytest.raises(ValueError):
        await client.delete_model_monitoring_job(
            model_monitoring_service.DeleteModelMonitoringJobRequest(),
            name='name_value',
        )


@pytest.mark.parametrize("request_type", [
  model_monitoring_service.SearchModelMonitoringStatsRequest,
  dict,
])
def test_search_model_monitoring_stats(request_type, transport: str = 'grpc'):
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport=transport,
    )

    # Everything is optional in proto3 as far as the runtime is concerned,
    # and we are mocking out the actual API, so just send an empty request.
    request = request_type()

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
            type(client.transport.search_model_monitoring_stats),
            '__call__') as call:
        # Designate an appropriate return value for the call.
        call.return_value = model_monitoring_service.SearchModelMonitoringStatsResponse(
            next_page_token='next_page_token_value',
        )
        response = client.search_model_monitoring_stats(request)

        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls) == 1
        _, args, _ = call.mock_calls[0]
        request = model_monitoring_service.SearchModelMonitoringStatsRequest()
        assert args[0] == request

    # Establish that the response is the type that we expect.
    assert isinstance(response, pagers.SearchModelMonitoringStatsPager)
    assert response.next_page_token == 'next_page_token_value'


def test_search_model_monitoring_stats_non_empty_request_with_auto_populated_field():
    # This test is a coverage failsafe to make sure that UUID4 fields are
    # automatically populated, according to AIP-4235, with non-empty requests.
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport='grpc',
    )

    # Populate all string fields in the request which are not UUID4
    # since we want to check that UUID4 are populated automatically
    # if they meet the requirements of AIP 4235.
    request = model_monitoring_service.SearchModelMonitoringStatsRequest(
        model_monitor='model_monitor_value',
        page_token='page_token_value',
    )

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
            type(client.transport.search_model_monitoring_stats),
            '__call__') as call:
        call.return_value.name = "foo" # operation_request.operation in compute client(s) expect a string.
        client.search_model_monitoring_stats(request=request)
        call.assert_called()
        _, args, _ = call.mock_calls[0]
        assert args[0] == model_monitoring_service.SearchModelMonitoringStatsRequest(
            model_monitor='model_monitor_value',
            page_token='page_token_value',
        )

def test_search_model_monitoring_stats_use_cached_wrapped_rpc():
    # Clients should use _prep_wrapped_messages to create cached wrapped rpcs,
    # instead of constructing them on each call
    with mock.patch("google.api_core.gapic_v1.method.wrap_method") as wrapper_fn:
        client = ModelMonitoringServiceClient(
            credentials=ga_credentials.AnonymousCredentials(),
            transport="grpc",
        )

        # Should wrap all calls on client creation
        assert wrapper_fn.call_count > 0
        wrapper_fn.reset_mock()

        # Ensure method has been cached
        assert client._transport.search_model_monitoring_stats in client._transport._wrapped_methods

        # Replace cached wrapped function with mock
        mock_rpc = mock.Mock()
        mock_rpc.return_value.name = "foo" # operation_request.operation in compute client(s) expect a string.
        client._transport._wrapped_methods[client._transport.search_model_monitoring_stats] = mock_rpc
        request = {}
        client.search_model_monitoring_stats(request)

        # Establish that the underlying gRPC stub method was called.
        assert mock_rpc.call_count == 1

        client.search_model_monitoring_stats(request)

        # Establish that a new wrapper was not created for this call
        assert wrapper_fn.call_count == 0
        assert mock_rpc.call_count == 2

@pytest.mark.asyncio
async def test_search_model_monitoring_stats_async_use_cached_wrapped_rpc(transport: str = "grpc_asyncio"):
    # Clients should use _prep_wrapped_messages to create cached wrapped rpcs,
    # instead of constructing them on each call
    with mock.patch("google.api_core.gapic_v1.method_async.wrap_method") as wrapper_fn:
        client = ModelMonitoringServiceAsyncClient(
            credentials=async_anonymous_credentials(),
            transport=transport,
        )

        # Should wrap all calls on client creation
        assert wrapper_fn.call_count > 0
        wrapper_fn.reset_mock()

        # Ensure method has been cached
        assert client._client._transport.search_model_monitoring_stats in client._client._transport._wrapped_methods

        # Replace cached wrapped function with mock
        mock_rpc = mock.AsyncMock()
        mock_rpc.return_value = mock.Mock()
        client._client._transport._wrapped_methods[client._client._transport.search_model_monitoring_stats] = mock_rpc

        request = {}
        await client.search_model_monitoring_stats(request)

        # Establish that the underlying gRPC stub method was called.
        assert mock_rpc.call_count == 1

        await client.search_model_monitoring_stats(request)

        # Establish that a new wrapper was not created for this call
        assert wrapper_fn.call_count == 0
        assert mock_rpc.call_count == 2

@pytest.mark.asyncio
async def test_search_model_monitoring_stats_async(transport: str = 'grpc_asyncio', request_type=model_monitoring_service.SearchModelMonitoringStatsRequest):
    client = ModelMonitoringServiceAsyncClient(
        credentials=async_anonymous_credentials(),
        transport=transport,
    )

    # Everything is optional in proto3 as far as the runtime is concerned,
    # and we are mocking out the actual API, so just send an empty request.
    request = request_type()

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
            type(client.transport.search_model_monitoring_stats),
            '__call__') as call:
        # Designate an appropriate return value for the call.
        call.return_value =grpc_helpers_async.FakeUnaryUnaryCall(model_monitoring_service.SearchModelMonitoringStatsResponse(
            next_page_token='next_page_token_value',
        ))
        response = await client.search_model_monitoring_stats(request)

        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls)
        _, args, _ = call.mock_calls[0]
        request = model_monitoring_service.SearchModelMonitoringStatsRequest()
        assert args[0] == request

    # Establish that the response is the type that we expect.
    assert isinstance(response, pagers.SearchModelMonitoringStatsAsyncPager)
    assert response.next_page_token == 'next_page_token_value'


@pytest.mark.asyncio
async def test_search_model_monitoring_stats_async_from_dict():
    await test_search_model_monitoring_stats_async(request_type=dict)

def test_search_model_monitoring_stats_field_headers():
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
    )

    # Any value that is part of the HTTP/1.1 URI should be sent as
    # a field header. Set these to a non-empty value.
    request = model_monitoring_service.SearchModelMonitoringStatsRequest()

    request.model_monitor = 'model_monitor_value'

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
            type(client.transport.search_model_monitoring_stats),
            '__call__') as call:
        call.return_value = model_monitoring_service.SearchModelMonitoringStatsResponse()
        client.search_model_monitoring_stats(request)

        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls) == 1
        _, args, _ = call.mock_calls[0]
        assert args[0] == request

    # Establish that the field header was sent.
    _, _, kw = call.mock_calls[0]
    assert (
        'x-goog-request-params',
        'model_monitor=model_monitor_value',
    ) in kw['metadata']


@pytest.mark.asyncio
async def test_search_model_monitoring_stats_field_headers_async():
    client = ModelMonitoringServiceAsyncClient(
        credentials=async_anonymous_credentials(),
    )

    # Any value that is part of the HTTP/1.1 URI should be sent as
    # a field header. Set these to a non-empty value.
    request = model_monitoring_service.SearchModelMonitoringStatsRequest()

    request.model_monitor = 'model_monitor_value'

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
            type(client.transport.search_model_monitoring_stats),
            '__call__') as call:
        call.return_value = grpc_helpers_async.FakeUnaryUnaryCall(model_monitoring_service.SearchModelMonitoringStatsResponse())
        await client.search_model_monitoring_stats(request)

        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls)
        _, args, _ = call.mock_calls[0]
        assert args[0] == request

    # Establish that the field header was sent.
    _, _, kw = call.mock_calls[0]
    assert (
        'x-goog-request-params',
        'model_monitor=model_monitor_value',
    ) in kw['metadata']


def test_search_model_monitoring_stats_flattened():
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
    )

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
            type(client.transport.search_model_monitoring_stats),
            '__call__') as call:
        # Designate an appropriate return value for the call.
        call.return_value = model_monitoring_service.SearchModelMonitoringStatsResponse()
        # Call the method with a truthy value for each flattened field,
        # using the keyword arguments to the method.
        client.search_model_monitoring_stats(
            model_monitor='model_monitor_value',
        )

        # Establish that the underlying call was made with the expected
        # request object values.
        assert len(call.mock_calls) == 1
        _, args, _ = call.mock_calls[0]
        arg = args[0].model_monitor
        mock_val = 'model_monitor_value'
        assert arg == mock_val


def test_search_model_monitoring_stats_flattened_error():
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
    )

    # Attempting to call a method with both a request object and flattened
    # fields is an error.
    with pytest.raises(ValueError):
        client.search_model_monitoring_stats(
            model_monitoring_service.SearchModelMonitoringStatsRequest(),
            model_monitor='model_monitor_value',
        )

@pytest.mark.asyncio
async def test_search_model_monitoring_stats_flattened_async():
    client = ModelMonitoringServiceAsyncClient(
        credentials=async_anonymous_credentials(),
    )

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
            type(client.transport.search_model_monitoring_stats),
            '__call__') as call:
        # Designate an appropriate return value for the call.
        call.return_value = model_monitoring_service.SearchModelMonitoringStatsResponse()

        call.return_value = grpc_helpers_async.FakeUnaryUnaryCall(model_monitoring_service.SearchModelMonitoringStatsResponse())
        # Call the method with a truthy value for each flattened field,
        # using the keyword arguments to the method.
        response = await client.search_model_monitoring_stats(
            model_monitor='model_monitor_value',
        )

        # Establish that the underlying call was made with the expected
        # request object values.
        assert len(call.mock_calls)
        _, args, _ = call.mock_calls[0]
        arg = args[0].model_monitor
        mock_val = 'model_monitor_value'
        assert arg == mock_val

@pytest.mark.asyncio
async def test_search_model_monitoring_stats_flattened_error_async():
    client = ModelMonitoringServiceAsyncClient(
        credentials=async_anonymous_credentials(),
    )

    # Attempting to call a method with both a request object and flattened
    # fields is an error.
    with pytest.raises(ValueError):
        await client.search_model_monitoring_stats(
            model_monitoring_service.SearchModelMonitoringStatsRequest(),
            model_monitor='model_monitor_value',
        )


def test_search_model_monitoring_stats_pager(transport_name: str = "grpc"):
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport=transport_name,
    )

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
            type(client.transport.search_model_monitoring_stats),
            '__call__') as call:
        # Set the response to a series of pages.
        call.side_effect = (
            model_monitoring_service.SearchModelMonitoringStatsResponse(
                monitoring_stats=[
                    model_monitoring_stats.ModelMonitoringStats(),
                    model_monitoring_stats.ModelMonitoringStats(),
                    model_monitoring_stats.ModelMonitoringStats(),
                ],
                next_page_token='abc',
            ),
            model_monitoring_service.SearchModelMonitoringStatsResponse(
                monitoring_stats=[],
                next_page_token='def',
            ),
            model_monitoring_service.SearchModelMonitoringStatsResponse(
                monitoring_stats=[
                    model_monitoring_stats.ModelMonitoringStats(),
                ],
                next_page_token='ghi',
            ),
            model_monitoring_service.SearchModelMonitoringStatsResponse(
                monitoring_stats=[
                    model_monitoring_stats.ModelMonitoringStats(),
                    model_monitoring_stats.ModelMonitoringStats(),
                ],
            ),
            RuntimeError,
        )

        expected_metadata = ()
        retry = retries.Retry()
        timeout = 5
        expected_metadata = tuple(expected_metadata) + (
            gapic_v1.routing_header.to_grpc_metadata((
                ('model_monitor', ''),
            )),
        )
        pager = client.search_model_monitoring_stats(request={}, retry=retry, timeout=timeout)

        assert pager._metadata == expected_metadata
        assert pager._retry == retry
        assert pager._timeout == timeout

        results = list(pager)
        assert len(results) == 6
        assert all(isinstance(i, model_monitoring_stats.ModelMonitoringStats)
                   for i in results)
def test_search_model_monitoring_stats_pages(transport_name: str = "grpc"):
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport=transport_name,
    )

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
            type(client.transport.search_model_monitoring_stats),
            '__call__') as call:
        # Set the response to a series of pages.
        call.side_effect = (
            model_monitoring_service.SearchModelMonitoringStatsResponse(
                monitoring_stats=[
                    model_monitoring_stats.ModelMonitoringStats(),
                    model_monitoring_stats.ModelMonitoringStats(),
                    model_monitoring_stats.ModelMonitoringStats(),
                ],
                next_page_token='abc',
            ),
            model_monitoring_service.SearchModelMonitoringStatsResponse(
                monitoring_stats=[],
                next_page_token='def',
            ),
            model_monitoring_service.SearchModelMonitoringStatsResponse(
                monitoring_stats=[
                    model_monitoring_stats.ModelMonitoringStats(),
                ],
                next_page_token='ghi',
            ),
            model_monitoring_service.SearchModelMonitoringStatsResponse(
                monitoring_stats=[
                    model_monitoring_stats.ModelMonitoringStats(),
                    model_monitoring_stats.ModelMonitoringStats(),
                ],
            ),
            RuntimeError,
        )
        pages = list(client.search_model_monitoring_stats(request={}).pages)
        for page_, token in zip(pages, ['abc','def','ghi', '']):
            assert page_.raw_page.next_page_token == token

@pytest.mark.asyncio
async def test_search_model_monitoring_stats_async_pager():
    client = ModelMonitoringServiceAsyncClient(
        credentials=async_anonymous_credentials(),
    )

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
            type(client.transport.search_model_monitoring_stats),
            '__call__', new_callable=mock.AsyncMock) as call:
        # Set the response to a series of pages.
        call.side_effect = (
            model_monitoring_service.SearchModelMonitoringStatsResponse(
                monitoring_stats=[
                    model_monitoring_stats.ModelMonitoringStats(),
                    model_monitoring_stats.ModelMonitoringStats(),
                    model_monitoring_stats.ModelMonitoringStats(),
                ],
                next_page_token='abc',
            ),
            model_monitoring_service.SearchModelMonitoringStatsResponse(
                monitoring_stats=[],
                next_page_token='def',
            ),
            model_monitoring_service.SearchModelMonitoringStatsResponse(
                monitoring_stats=[
                    model_monitoring_stats.ModelMonitoringStats(),
                ],
                next_page_token='ghi',
            ),
            model_monitoring_service.SearchModelMonitoringStatsResponse(
                monitoring_stats=[
                    model_monitoring_stats.ModelMonitoringStats(),
                    model_monitoring_stats.ModelMonitoringStats(),
                ],
            ),
            RuntimeError,
        )
        async_pager = await client.search_model_monitoring_stats(request={},)
        assert async_pager.next_page_token == 'abc'
        responses = []
        async for response in async_pager: # pragma: no branch
            responses.append(response)

        assert len(responses) == 6
        assert all(isinstance(i, model_monitoring_stats.ModelMonitoringStats)
                for i in responses)


@pytest.mark.asyncio
async def test_search_model_monitoring_stats_async_pages():
    client = ModelMonitoringServiceAsyncClient(
        credentials=async_anonymous_credentials(),
    )

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
            type(client.transport.search_model_monitoring_stats),
            '__call__', new_callable=mock.AsyncMock) as call:
        # Set the response to a series of pages.
        call.side_effect = (
            model_monitoring_service.SearchModelMonitoringStatsResponse(
                monitoring_stats=[
                    model_monitoring_stats.ModelMonitoringStats(),
                    model_monitoring_stats.ModelMonitoringStats(),
                    model_monitoring_stats.ModelMonitoringStats(),
                ],
                next_page_token='abc',
            ),
            model_monitoring_service.SearchModelMonitoringStatsResponse(
                monitoring_stats=[],
                next_page_token='def',
            ),
            model_monitoring_service.SearchModelMonitoringStatsResponse(
                monitoring_stats=[
                    model_monitoring_stats.ModelMonitoringStats(),
                ],
                next_page_token='ghi',
            ),
            model_monitoring_service.SearchModelMonitoringStatsResponse(
                monitoring_stats=[
                    model_monitoring_stats.ModelMonitoringStats(),
                    model_monitoring_stats.ModelMonitoringStats(),
                ],
            ),
            RuntimeError,
        )
        pages = []
        # Workaround issue in python 3.9 related to code coverage by adding `# pragma: no branch`
        # See https://github.com/googleapis/gapic-generator-python/pull/1174#issuecomment-1025132372
        async for page_ in ( # pragma: no branch
            await client.search_model_monitoring_stats(request={})
        ).pages:
            pages.append(page_)
        for page_, token in zip(pages, ['abc','def','ghi', '']):
            assert page_.raw_page.next_page_token == token

@pytest.mark.parametrize("request_type", [
  model_monitoring_service.SearchModelMonitoringAlertsRequest,
  dict,
])
def test_search_model_monitoring_alerts(request_type, transport: str = 'grpc'):
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport=transport,
    )

    # Everything is optional in proto3 as far as the runtime is concerned,
    # and we are mocking out the actual API, so just send an empty request.
    request = request_type()

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
            type(client.transport.search_model_monitoring_alerts),
            '__call__') as call:
        # Designate an appropriate return value for the call.
        call.return_value = model_monitoring_service.SearchModelMonitoringAlertsResponse(
            total_number_alerts=2038,
            next_page_token='next_page_token_value',
        )
        response = client.search_model_monitoring_alerts(request)

        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls) == 1
        _, args, _ = call.mock_calls[0]
        request = model_monitoring_service.SearchModelMonitoringAlertsRequest()
        assert args[0] == request

    # Establish that the response is the type that we expect.
    assert isinstance(response, pagers.SearchModelMonitoringAlertsPager)
    assert response.total_number_alerts == 2038
    assert response.next_page_token == 'next_page_token_value'


def test_search_model_monitoring_alerts_non_empty_request_with_auto_populated_field():
    # This test is a coverage failsafe to make sure that UUID4 fields are
    # automatically populated, according to AIP-4235, with non-empty requests.
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport='grpc',
    )

    # Populate all string fields in the request which are not UUID4
    # since we want to check that UUID4 are populated automatically
    # if they meet the requirements of AIP 4235.
    request = model_monitoring_service.SearchModelMonitoringAlertsRequest(
        model_monitor='model_monitor_value',
        model_monitoring_job='model_monitoring_job_value',
        stats_name='stats_name_value',
        objective_type='objective_type_value',
        page_token='page_token_value',
    )

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
            type(client.transport.search_model_monitoring_alerts),
            '__call__') as call:
        call.return_value.name = "foo" # operation_request.operation in compute client(s) expect a string.
        client.search_model_monitoring_alerts(request=request)
        call.assert_called()
        _, args, _ = call.mock_calls[0]
        assert args[0] == model_monitoring_service.SearchModelMonitoringAlertsRequest(
            model_monitor='model_monitor_value',
            model_monitoring_job='model_monitoring_job_value',
            stats_name='stats_name_value',
            objective_type='objective_type_value',
            page_token='page_token_value',
        )

def test_search_model_monitoring_alerts_use_cached_wrapped_rpc():
    # Clients should use _prep_wrapped_messages to create cached wrapped rpcs,
    # instead of constructing them on each call
    with mock.patch("google.api_core.gapic_v1.method.wrap_method") as wrapper_fn:
        client = ModelMonitoringServiceClient(
            credentials=ga_credentials.AnonymousCredentials(),
            transport="grpc",
        )

        # Should wrap all calls on client creation
        assert wrapper_fn.call_count > 0
        wrapper_fn.reset_mock()

        # Ensure method has been cached
        assert client._transport.search_model_monitoring_alerts in client._transport._wrapped_methods

        # Replace cached wrapped function with mock
        mock_rpc = mock.Mock()
        mock_rpc.return_value.name = "foo" # operation_request.operation in compute client(s) expect a string.
        client._transport._wrapped_methods[client._transport.search_model_monitoring_alerts] = mock_rpc
        request = {}
        client.search_model_monitoring_alerts(request)

        # Establish that the underlying gRPC stub method was called.
        assert mock_rpc.call_count == 1

        client.search_model_monitoring_alerts(request)

        # Establish that a new wrapper was not created for this call
        assert wrapper_fn.call_count == 0
        assert mock_rpc.call_count == 2

@pytest.mark.asyncio
async def test_search_model_monitoring_alerts_async_use_cached_wrapped_rpc(transport: str = "grpc_asyncio"):
    # Clients should use _prep_wrapped_messages to create cached wrapped rpcs,
    # instead of constructing them on each call
    with mock.patch("google.api_core.gapic_v1.method_async.wrap_method") as wrapper_fn:
        client = ModelMonitoringServiceAsyncClient(
            credentials=async_anonymous_credentials(),
            transport=transport,
        )

        # Should wrap all calls on client creation
        assert wrapper_fn.call_count > 0
        wrapper_fn.reset_mock()

        # Ensure method has been cached
        assert client._client._transport.search_model_monitoring_alerts in client._client._transport._wrapped_methods

        # Replace cached wrapped function with mock
        mock_rpc = mock.AsyncMock()
        mock_rpc.return_value = mock.Mock()
        client._client._transport._wrapped_methods[client._client._transport.search_model_monitoring_alerts] = mock_rpc

        request = {}
        await client.search_model_monitoring_alerts(request)

        # Establish that the underlying gRPC stub method was called.
        assert mock_rpc.call_count == 1

        await client.search_model_monitoring_alerts(request)

        # Establish that a new wrapper was not created for this call
        assert wrapper_fn.call_count == 0
        assert mock_rpc.call_count == 2

@pytest.mark.asyncio
async def test_search_model_monitoring_alerts_async(transport: str = 'grpc_asyncio', request_type=model_monitoring_service.SearchModelMonitoringAlertsRequest):
    client = ModelMonitoringServiceAsyncClient(
        credentials=async_anonymous_credentials(),
        transport=transport,
    )

    # Everything is optional in proto3 as far as the runtime is concerned,
    # and we are mocking out the actual API, so just send an empty request.
    request = request_type()

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
            type(client.transport.search_model_monitoring_alerts),
            '__call__') as call:
        # Designate an appropriate return value for the call.
        call.return_value =grpc_helpers_async.FakeUnaryUnaryCall(model_monitoring_service.SearchModelMonitoringAlertsResponse(
            total_number_alerts=2038,
            next_page_token='next_page_token_value',
        ))
        response = await client.search_model_monitoring_alerts(request)

        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls)
        _, args, _ = call.mock_calls[0]
        request = model_monitoring_service.SearchModelMonitoringAlertsRequest()
        assert args[0] == request

    # Establish that the response is the type that we expect.
    assert isinstance(response, pagers.SearchModelMonitoringAlertsAsyncPager)
    assert response.total_number_alerts == 2038
    assert response.next_page_token == 'next_page_token_value'


@pytest.mark.asyncio
async def test_search_model_monitoring_alerts_async_from_dict():
    await test_search_model_monitoring_alerts_async(request_type=dict)

def test_search_model_monitoring_alerts_field_headers():
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
    )

    # Any value that is part of the HTTP/1.1 URI should be sent as
    # a field header. Set these to a non-empty value.
    request = model_monitoring_service.SearchModelMonitoringAlertsRequest()

    request.model_monitor = 'model_monitor_value'

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
            type(client.transport.search_model_monitoring_alerts),
            '__call__') as call:
        call.return_value = model_monitoring_service.SearchModelMonitoringAlertsResponse()
        client.search_model_monitoring_alerts(request)

        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls) == 1
        _, args, _ = call.mock_calls[0]
        assert args[0] == request

    # Establish that the field header was sent.
    _, _, kw = call.mock_calls[0]
    assert (
        'x-goog-request-params',
        'model_monitor=model_monitor_value',
    ) in kw['metadata']


@pytest.mark.asyncio
async def test_search_model_monitoring_alerts_field_headers_async():
    client = ModelMonitoringServiceAsyncClient(
        credentials=async_anonymous_credentials(),
    )

    # Any value that is part of the HTTP/1.1 URI should be sent as
    # a field header. Set these to a non-empty value.
    request = model_monitoring_service.SearchModelMonitoringAlertsRequest()

    request.model_monitor = 'model_monitor_value'

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
            type(client.transport.search_model_monitoring_alerts),
            '__call__') as call:
        call.return_value = grpc_helpers_async.FakeUnaryUnaryCall(model_monitoring_service.SearchModelMonitoringAlertsResponse())
        await client.search_model_monitoring_alerts(request)

        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls)
        _, args, _ = call.mock_calls[0]
        assert args[0] == request

    # Establish that the field header was sent.
    _, _, kw = call.mock_calls[0]
    assert (
        'x-goog-request-params',
        'model_monitor=model_monitor_value',
    ) in kw['metadata']


def test_search_model_monitoring_alerts_flattened():
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
    )

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
            type(client.transport.search_model_monitoring_alerts),
            '__call__') as call:
        # Designate an appropriate return value for the call.
        call.return_value = model_monitoring_service.SearchModelMonitoringAlertsResponse()
        # Call the method with a truthy value for each flattened field,
        # using the keyword arguments to the method.
        client.search_model_monitoring_alerts(
            model_monitor='model_monitor_value',
        )

        # Establish that the underlying call was made with the expected
        # request object values.
        assert len(call.mock_calls) == 1
        _, args, _ = call.mock_calls[0]
        arg = args[0].model_monitor
        mock_val = 'model_monitor_value'
        assert arg == mock_val


def test_search_model_monitoring_alerts_flattened_error():
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
    )

    # Attempting to call a method with both a request object and flattened
    # fields is an error.
    with pytest.raises(ValueError):
        client.search_model_monitoring_alerts(
            model_monitoring_service.SearchModelMonitoringAlertsRequest(),
            model_monitor='model_monitor_value',
        )

@pytest.mark.asyncio
async def test_search_model_monitoring_alerts_flattened_async():
    client = ModelMonitoringServiceAsyncClient(
        credentials=async_anonymous_credentials(),
    )

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
            type(client.transport.search_model_monitoring_alerts),
            '__call__') as call:
        # Designate an appropriate return value for the call.
        call.return_value = model_monitoring_service.SearchModelMonitoringAlertsResponse()

        call.return_value = grpc_helpers_async.FakeUnaryUnaryCall(model_monitoring_service.SearchModelMonitoringAlertsResponse())
        # Call the method with a truthy value for each flattened field,
        # using the keyword arguments to the method.
        response = await client.search_model_monitoring_alerts(
            model_monitor='model_monitor_value',
        )

        # Establish that the underlying call was made with the expected
        # request object values.
        assert len(call.mock_calls)
        _, args, _ = call.mock_calls[0]
        arg = args[0].model_monitor
        mock_val = 'model_monitor_value'
        assert arg == mock_val

@pytest.mark.asyncio
async def test_search_model_monitoring_alerts_flattened_error_async():
    client = ModelMonitoringServiceAsyncClient(
        credentials=async_anonymous_credentials(),
    )

    # Attempting to call a method with both a request object and flattened
    # fields is an error.
    with pytest.raises(ValueError):
        await client.search_model_monitoring_alerts(
            model_monitoring_service.SearchModelMonitoringAlertsRequest(),
            model_monitor='model_monitor_value',
        )


def test_search_model_monitoring_alerts_pager(transport_name: str = "grpc"):
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport=transport_name,
    )

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
            type(client.transport.search_model_monitoring_alerts),
            '__call__') as call:
        # Set the response to a series of pages.
        call.side_effect = (
            model_monitoring_service.SearchModelMonitoringAlertsResponse(
                model_monitoring_alerts=[
                    model_monitoring_alert.ModelMonitoringAlert(),
                    model_monitoring_alert.ModelMonitoringAlert(),
                    model_monitoring_alert.ModelMonitoringAlert(),
                ],
                next_page_token='abc',
            ),
            model_monitoring_service.SearchModelMonitoringAlertsResponse(
                model_monitoring_alerts=[],
                next_page_token='def',
            ),
            model_monitoring_service.SearchModelMonitoringAlertsResponse(
                model_monitoring_alerts=[
                    model_monitoring_alert.ModelMonitoringAlert(),
                ],
                next_page_token='ghi',
            ),
            model_monitoring_service.SearchModelMonitoringAlertsResponse(
                model_monitoring_alerts=[
                    model_monitoring_alert.ModelMonitoringAlert(),
                    model_monitoring_alert.ModelMonitoringAlert(),
                ],
            ),
            RuntimeError,
        )

        expected_metadata = ()
        retry = retries.Retry()
        timeout = 5
        expected_metadata = tuple(expected_metadata) + (
            gapic_v1.routing_header.to_grpc_metadata((
                ('model_monitor', ''),
            )),
        )
        pager = client.search_model_monitoring_alerts(request={}, retry=retry, timeout=timeout)

        assert pager._metadata == expected_metadata
        assert pager._retry == retry
        assert pager._timeout == timeout

        results = list(pager)
        assert len(results) == 6
        assert all(isinstance(i, model_monitoring_alert.ModelMonitoringAlert)
                   for i in results)
def test_search_model_monitoring_alerts_pages(transport_name: str = "grpc"):
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport=transport_name,
    )

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
            type(client.transport.search_model_monitoring_alerts),
            '__call__') as call:
        # Set the response to a series of pages.
        call.side_effect = (
            model_monitoring_service.SearchModelMonitoringAlertsResponse(
                model_monitoring_alerts=[
                    model_monitoring_alert.ModelMonitoringAlert(),
                    model_monitoring_alert.ModelMonitoringAlert(),
                    model_monitoring_alert.ModelMonitoringAlert(),
                ],
                next_page_token='abc',
            ),
            model_monitoring_service.SearchModelMonitoringAlertsResponse(
                model_monitoring_alerts=[],
                next_page_token='def',
            ),
            model_monitoring_service.SearchModelMonitoringAlertsResponse(
                model_monitoring_alerts=[
                    model_monitoring_alert.ModelMonitoringAlert(),
                ],
                next_page_token='ghi',
            ),
            model_monitoring_service.SearchModelMonitoringAlertsResponse(
                model_monitoring_alerts=[
                    model_monitoring_alert.ModelMonitoringAlert(),
                    model_monitoring_alert.ModelMonitoringAlert(),
                ],
            ),
            RuntimeError,
        )
        pages = list(client.search_model_monitoring_alerts(request={}).pages)
        for page_, token in zip(pages, ['abc','def','ghi', '']):
            assert page_.raw_page.next_page_token == token

@pytest.mark.asyncio
async def test_search_model_monitoring_alerts_async_pager():
    client = ModelMonitoringServiceAsyncClient(
        credentials=async_anonymous_credentials(),
    )

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
            type(client.transport.search_model_monitoring_alerts),
            '__call__', new_callable=mock.AsyncMock) as call:
        # Set the response to a series of pages.
        call.side_effect = (
            model_monitoring_service.SearchModelMonitoringAlertsResponse(
                model_monitoring_alerts=[
                    model_monitoring_alert.ModelMonitoringAlert(),
                    model_monitoring_alert.ModelMonitoringAlert(),
                    model_monitoring_alert.ModelMonitoringAlert(),
                ],
                next_page_token='abc',
            ),
            model_monitoring_service.SearchModelMonitoringAlertsResponse(
                model_monitoring_alerts=[],
                next_page_token='def',
            ),
            model_monitoring_service.SearchModelMonitoringAlertsResponse(
                model_monitoring_alerts=[
                    model_monitoring_alert.ModelMonitoringAlert(),
                ],
                next_page_token='ghi',
            ),
            model_monitoring_service.SearchModelMonitoringAlertsResponse(
                model_monitoring_alerts=[
                    model_monitoring_alert.ModelMonitoringAlert(),
                    model_monitoring_alert.ModelMonitoringAlert(),
                ],
            ),
            RuntimeError,
        )
        async_pager = await client.search_model_monitoring_alerts(request={},)
        assert async_pager.next_page_token == 'abc'
        responses = []
        async for response in async_pager: # pragma: no branch
            responses.append(response)

        assert len(responses) == 6
        assert all(isinstance(i, model_monitoring_alert.ModelMonitoringAlert)
                for i in responses)


@pytest.mark.asyncio
async def test_search_model_monitoring_alerts_async_pages():
    client = ModelMonitoringServiceAsyncClient(
        credentials=async_anonymous_credentials(),
    )

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
            type(client.transport.search_model_monitoring_alerts),
            '__call__', new_callable=mock.AsyncMock) as call:
        # Set the response to a series of pages.
        call.side_effect = (
            model_monitoring_service.SearchModelMonitoringAlertsResponse(
                model_monitoring_alerts=[
                    model_monitoring_alert.ModelMonitoringAlert(),
                    model_monitoring_alert.ModelMonitoringAlert(),
                    model_monitoring_alert.ModelMonitoringAlert(),
                ],
                next_page_token='abc',
            ),
            model_monitoring_service.SearchModelMonitoringAlertsResponse(
                model_monitoring_alerts=[],
                next_page_token='def',
            ),
            model_monitoring_service.SearchModelMonitoringAlertsResponse(
                model_monitoring_alerts=[
                    model_monitoring_alert.ModelMonitoringAlert(),
                ],
                next_page_token='ghi',
            ),
            model_monitoring_service.SearchModelMonitoringAlertsResponse(
                model_monitoring_alerts=[
                    model_monitoring_alert.ModelMonitoringAlert(),
                    model_monitoring_alert.ModelMonitoringAlert(),
                ],
            ),
            RuntimeError,
        )
        pages = []
        # Workaround issue in python 3.9 related to code coverage by adding `# pragma: no branch`
        # See https://github.com/googleapis/gapic-generator-python/pull/1174#issuecomment-1025132372
        async for page_ in ( # pragma: no branch
            await client.search_model_monitoring_alerts(request={})
        ).pages:
            pages.append(page_)
        for page_, token in zip(pages, ['abc','def','ghi', '']):
            assert page_.raw_page.next_page_token == token


def test_create_model_monitor_rest_use_cached_wrapped_rpc():
    # Clients should use _prep_wrapped_messages to create cached wrapped rpcs,
    # instead of constructing them on each call
    with mock.patch("google.api_core.gapic_v1.method.wrap_method") as wrapper_fn:
        client = ModelMonitoringServiceClient(
            credentials=ga_credentials.AnonymousCredentials(),
            transport="rest",
        )

        # Should wrap all calls on client creation
        assert wrapper_fn.call_count > 0
        wrapper_fn.reset_mock()

        # Ensure method has been cached
        assert client._transport.create_model_monitor in client._transport._wrapped_methods

        # Replace cached wrapped function with mock
        mock_rpc = mock.Mock()
        mock_rpc.return_value.name = "foo" # operation_request.operation in compute client(s) expect a string.
        client._transport._wrapped_methods[client._transport.create_model_monitor] = mock_rpc

        request = {}
        client.create_model_monitor(request)

        # Establish that the underlying gRPC stub method was called.
        assert mock_rpc.call_count == 1

        # Operation methods build a cached wrapper on first rpc call
        # subsequent calls should use the cached wrapper
        wrapper_fn.reset_mock()

        client.create_model_monitor(request)

        # Establish that a new wrapper was not created for this call
        assert wrapper_fn.call_count == 0
        assert mock_rpc.call_count == 2


def test_create_model_monitor_rest_required_fields(request_type=model_monitoring_service.CreateModelMonitorRequest):
    transport_class = transports.ModelMonitoringServiceRestTransport

    request_init = {}
    request_init["parent"] = ""
    request = request_type(**request_init)
    pb_request = request_type.pb(request)
    jsonified_request = json.loads(json_format.MessageToJson(
        pb_request,
        use_integers_for_enums=False
    ))

    # verify fields with default values are dropped

    unset_fields = transport_class(credentials=ga_credentials.AnonymousCredentials()).create_model_monitor._get_unset_required_fields(jsonified_request)
    jsonified_request.update(unset_fields)

    # verify required fields with default values are now present

    jsonified_request["parent"] = 'parent_value'

    unset_fields = transport_class(credentials=ga_credentials.AnonymousCredentials()).create_model_monitor._get_unset_required_fields(jsonified_request)
    # Check that path parameters and body parameters are not mixing in.
    assert not set(unset_fields) - set(("model_monitor_id", ))
    jsonified_request.update(unset_fields)

    # verify required fields with non-default values are left alone
    assert "parent" in jsonified_request
    assert jsonified_request["parent"] == 'parent_value'

    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport='rest',
    )
    request = request_type(**request_init)

    # Designate an appropriate value for the returned response.
    return_value = operations_pb2.Operation(name='operations/spam')
    # Mock the http request call within the method and fake a response.
    with mock.patch.object(Session, 'request') as req:
        # We need to mock transcode() because providing default values
        # for required fields will fail the real version if the http_options
        # expect actual values for those fields.
        with mock.patch.object(path_template, 'transcode') as transcode:
            # A uri without fields and an empty body will force all the
            # request fields to show up in the query_params.
            pb_request = request_type.pb(request)
            transcode_result = {
                'uri': 'v1/sample_method',
                'method': "post",
                'query_params': pb_request,
            }
            transcode_result['body'] = pb_request
            transcode.return_value = transcode_result

            response_value = Response()
            response_value.status_code = 200
            json_return_value = json_format.MessageToJson(return_value)

            response_value._content = json_return_value.encode('UTF-8')
            req.return_value = response_value

            response = client.create_model_monitor(request)

            expected_params = [
                ('$alt', 'json;enum-encoding=int')
            ]
            actual_params = req.call_args.kwargs['params']
            assert expected_params == actual_params


def test_create_model_monitor_rest_unset_required_fields():
    transport = transports.ModelMonitoringServiceRestTransport(credentials=ga_credentials.AnonymousCredentials)

    unset_fields = transport.create_model_monitor._get_unset_required_fields({})
    assert set(unset_fields) == (set(("modelMonitorId", )) & set(("parent", "modelMonitor", )))


def test_create_model_monitor_rest_flattened():
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport="rest",
    )

    # Mock the http request call within the method and fake a response.
    with mock.patch.object(type(client.transport._session), 'request') as req:
        # Designate an appropriate value for the returned response.
        return_value = operations_pb2.Operation(name='operations/spam')

        # get arguments that satisfy an http rule for this method
        sample_request = {'parent': 'projects/sample1/locations/sample2'}

        # get truthy value for each flattened field
        mock_args = dict(
            parent='parent_value',
            model_monitor=gca_model_monitor.ModelMonitor(tabular_objective=model_monitoring_spec.ModelMonitoringObjectiveSpec.TabularObjective(feature_drift_spec=model_monitoring_spec.ModelMonitoringObjectiveSpec.DataDriftSpec(features=['features_value']))),
        )
        mock_args.update(sample_request)

        # Wrap the value into a proper Response obj
        response_value = Response()
        response_value.status_code = 200
        json_return_value = json_format.MessageToJson(return_value)
        response_value._content = json_return_value.encode('UTF-8')
        req.return_value = response_value

        client.create_model_monitor(**mock_args)

        # Establish that the underlying call was made with the expected
        # request object values.
        assert len(req.mock_calls) == 1
        _, args, _ = req.mock_calls[0]
        assert path_template.validate("%s/v1beta1/{parent=projects/*/locations/*}/modelMonitors" % client.transport._host, args[1])


def test_create_model_monitor_rest_flattened_error(transport: str = 'rest'):
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport=transport,
    )

    # Attempting to call a method with both a request object and flattened
    # fields is an error.
    with pytest.raises(ValueError):
        client.create_model_monitor(
            model_monitoring_service.CreateModelMonitorRequest(),
            parent='parent_value',
            model_monitor=gca_model_monitor.ModelMonitor(tabular_objective=model_monitoring_spec.ModelMonitoringObjectiveSpec.TabularObjective(feature_drift_spec=model_monitoring_spec.ModelMonitoringObjectiveSpec.DataDriftSpec(features=['features_value']))),
        )


def test_update_model_monitor_rest_use_cached_wrapped_rpc():
    # Clients should use _prep_wrapped_messages to create cached wrapped rpcs,
    # instead of constructing them on each call
    with mock.patch("google.api_core.gapic_v1.method.wrap_method") as wrapper_fn:
        client = ModelMonitoringServiceClient(
            credentials=ga_credentials.AnonymousCredentials(),
            transport="rest",
        )

        # Should wrap all calls on client creation
        assert wrapper_fn.call_count > 0
        wrapper_fn.reset_mock()

        # Ensure method has been cached
        assert client._transport.update_model_monitor in client._transport._wrapped_methods

        # Replace cached wrapped function with mock
        mock_rpc = mock.Mock()
        mock_rpc.return_value.name = "foo" # operation_request.operation in compute client(s) expect a string.
        client._transport._wrapped_methods[client._transport.update_model_monitor] = mock_rpc

        request = {}
        client.update_model_monitor(request)

        # Establish that the underlying gRPC stub method was called.
        assert mock_rpc.call_count == 1

        # Operation methods build a cached wrapper on first rpc call
        # subsequent calls should use the cached wrapper
        wrapper_fn.reset_mock()

        client.update_model_monitor(request)

        # Establish that a new wrapper was not created for this call
        assert wrapper_fn.call_count == 0
        assert mock_rpc.call_count == 2


def test_update_model_monitor_rest_required_fields(request_type=model_monitoring_service.UpdateModelMonitorRequest):
    transport_class = transports.ModelMonitoringServiceRestTransport

    request_init = {}
    request = request_type(**request_init)
    pb_request = request_type.pb(request)
    jsonified_request = json.loads(json_format.MessageToJson(
        pb_request,
        use_integers_for_enums=False
    ))

    # verify fields with default values are dropped

    unset_fields = transport_class(credentials=ga_credentials.AnonymousCredentials()).update_model_monitor._get_unset_required_fields(jsonified_request)
    jsonified_request.update(unset_fields)

    # verify required fields with default values are now present

    unset_fields = transport_class(credentials=ga_credentials.AnonymousCredentials()).update_model_monitor._get_unset_required_fields(jsonified_request)
    # Check that path parameters and body parameters are not mixing in.
    assert not set(unset_fields) - set(("update_mask", ))
    jsonified_request.update(unset_fields)

    # verify required fields with non-default values are left alone

    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport='rest',
    )
    request = request_type(**request_init)

    # Designate an appropriate value for the returned response.
    return_value = operations_pb2.Operation(name='operations/spam')
    # Mock the http request call within the method and fake a response.
    with mock.patch.object(Session, 'request') as req:
        # We need to mock transcode() because providing default values
        # for required fields will fail the real version if the http_options
        # expect actual values for those fields.
        with mock.patch.object(path_template, 'transcode') as transcode:
            # A uri without fields and an empty body will force all the
            # request fields to show up in the query_params.
            pb_request = request_type.pb(request)
            transcode_result = {
                'uri': 'v1/sample_method',
                'method': "patch",
                'query_params': pb_request,
            }
            transcode_result['body'] = pb_request
            transcode.return_value = transcode_result

            response_value = Response()
            response_value.status_code = 200
            json_return_value = json_format.MessageToJson(return_value)

            response_value._content = json_return_value.encode('UTF-8')
            req.return_value = response_value

            response = client.update_model_monitor(request)

            expected_params = [
                ('$alt', 'json;enum-encoding=int')
            ]
            actual_params = req.call_args.kwargs['params']
            assert expected_params == actual_params


def test_update_model_monitor_rest_unset_required_fields():
    transport = transports.ModelMonitoringServiceRestTransport(credentials=ga_credentials.AnonymousCredentials)

    unset_fields = transport.update_model_monitor._get_unset_required_fields({})
    assert set(unset_fields) == (set(("updateMask", )) & set(("modelMonitor", "updateMask", )))


def test_update_model_monitor_rest_flattened():
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport="rest",
    )

    # Mock the http request call within the method and fake a response.
    with mock.patch.object(type(client.transport._session), 'request') as req:
        # Designate an appropriate value for the returned response.
        return_value = operations_pb2.Operation(name='operations/spam')

        # get arguments that satisfy an http rule for this method
        sample_request = {'model_monitor': {'name': 'projects/sample1/locations/sample2/modelMonitors/sample3'}}

        # get truthy value for each flattened field
        mock_args = dict(
            model_monitor=gca_model_monitor.ModelMonitor(tabular_objective=model_monitoring_spec.ModelMonitoringObjectiveSpec.TabularObjective(feature_drift_spec=model_monitoring_spec.ModelMonitoringObjectiveSpec.DataDriftSpec(features=['features_value']))),
            update_mask=field_mask_pb2.FieldMask(paths=['paths_value']),
        )
        mock_args.update(sample_request)

        # Wrap the value into a proper Response obj
        response_value = Response()
        response_value.status_code = 200
        json_return_value = json_format.MessageToJson(return_value)
        response_value._content = json_return_value.encode('UTF-8')
        req.return_value = response_value

        client.update_model_monitor(**mock_args)

        # Establish that the underlying call was made with the expected
        # request object values.
        assert len(req.mock_calls) == 1
        _, args, _ = req.mock_calls[0]
        assert path_template.validate("%s/v1beta1/{model_monitor.name=projects/*/locations/*/modelMonitors/*}" % client.transport._host, args[1])


def test_update_model_monitor_rest_flattened_error(transport: str = 'rest'):
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport=transport,
    )

    # Attempting to call a method with both a request object and flattened
    # fields is an error.
    with pytest.raises(ValueError):
        client.update_model_monitor(
            model_monitoring_service.UpdateModelMonitorRequest(),
            model_monitor=gca_model_monitor.ModelMonitor(tabular_objective=model_monitoring_spec.ModelMonitoringObjectiveSpec.TabularObjective(feature_drift_spec=model_monitoring_spec.ModelMonitoringObjectiveSpec.DataDriftSpec(features=['features_value']))),
            update_mask=field_mask_pb2.FieldMask(paths=['paths_value']),
        )


def test_get_model_monitor_rest_use_cached_wrapped_rpc():
    # Clients should use _prep_wrapped_messages to create cached wrapped rpcs,
    # instead of constructing them on each call
    with mock.patch("google.api_core.gapic_v1.method.wrap_method") as wrapper_fn:
        client = ModelMonitoringServiceClient(
            credentials=ga_credentials.AnonymousCredentials(),
            transport="rest",
        )

        # Should wrap all calls on client creation
        assert wrapper_fn.call_count > 0
        wrapper_fn.reset_mock()

        # Ensure method has been cached
        assert client._transport.get_model_monitor in client._transport._wrapped_methods

        # Replace cached wrapped function with mock
        mock_rpc = mock.Mock()
        mock_rpc.return_value.name = "foo" # operation_request.operation in compute client(s) expect a string.
        client._transport._wrapped_methods[client._transport.get_model_monitor] = mock_rpc

        request = {}
        client.get_model_monitor(request)

        # Establish that the underlying gRPC stub method was called.
        assert mock_rpc.call_count == 1

        client.get_model_monitor(request)

        # Establish that a new wrapper was not created for this call
        assert wrapper_fn.call_count == 0
        assert mock_rpc.call_count == 2


def test_get_model_monitor_rest_required_fields(request_type=model_monitoring_service.GetModelMonitorRequest):
    transport_class = transports.ModelMonitoringServiceRestTransport

    request_init = {}
    request_init["name"] = ""
    request = request_type(**request_init)
    pb_request = request_type.pb(request)
    jsonified_request = json.loads(json_format.MessageToJson(
        pb_request,
        use_integers_for_enums=False
    ))

    # verify fields with default values are dropped

    unset_fields = transport_class(credentials=ga_credentials.AnonymousCredentials()).get_model_monitor._get_unset_required_fields(jsonified_request)
    jsonified_request.update(unset_fields)

    # verify required fields with default values are now present

    jsonified_request["name"] = 'name_value'

    unset_fields = transport_class(credentials=ga_credentials.AnonymousCredentials()).get_model_monitor._get_unset_required_fields(jsonified_request)
    jsonified_request.update(unset_fields)

    # verify required fields with non-default values are left alone
    assert "name" in jsonified_request
    assert jsonified_request["name"] == 'name_value'

    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport='rest',
    )
    request = request_type(**request_init)

    # Designate an appropriate value for the returned response.
    return_value = model_monitor.ModelMonitor()
    # Mock the http request call within the method and fake a response.
    with mock.patch.object(Session, 'request') as req:
        # We need to mock transcode() because providing default values
        # for required fields will fail the real version if the http_options
        # expect actual values for those fields.
        with mock.patch.object(path_template, 'transcode') as transcode:
            # A uri without fields and an empty body will force all the
            # request fields to show up in the query_params.
            pb_request = request_type.pb(request)
            transcode_result = {
                'uri': 'v1/sample_method',
                'method': "get",
                'query_params': pb_request,
            }
            transcode.return_value = transcode_result

            response_value = Response()
            response_value.status_code = 200

            # Convert return value to protobuf type
            return_value = model_monitor.ModelMonitor.pb(return_value)
            json_return_value = json_format.MessageToJson(return_value)

            response_value._content = json_return_value.encode('UTF-8')
            req.return_value = response_value

            response = client.get_model_monitor(request)

            expected_params = [
                ('$alt', 'json;enum-encoding=int')
            ]
            actual_params = req.call_args.kwargs['params']
            assert expected_params == actual_params


def test_get_model_monitor_rest_unset_required_fields():
    transport = transports.ModelMonitoringServiceRestTransport(credentials=ga_credentials.AnonymousCredentials)

    unset_fields = transport.get_model_monitor._get_unset_required_fields({})
    assert set(unset_fields) == (set(()) & set(("name", )))


def test_get_model_monitor_rest_flattened():
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport="rest",
    )

    # Mock the http request call within the method and fake a response.
    with mock.patch.object(type(client.transport._session), 'request') as req:
        # Designate an appropriate value for the returned response.
        return_value = model_monitor.ModelMonitor()

        # get arguments that satisfy an http rule for this method
        sample_request = {'name': 'projects/sample1/locations/sample2/modelMonitors/sample3'}

        # get truthy value for each flattened field
        mock_args = dict(
            name='name_value',
        )
        mock_args.update(sample_request)

        # Wrap the value into a proper Response obj
        response_value = Response()
        response_value.status_code = 200
        # Convert return value to protobuf type
        return_value = model_monitor.ModelMonitor.pb(return_value)
        json_return_value = json_format.MessageToJson(return_value)
        response_value._content = json_return_value.encode('UTF-8')
        req.return_value = response_value

        client.get_model_monitor(**mock_args)

        # Establish that the underlying call was made with the expected
        # request object values.
        assert len(req.mock_calls) == 1
        _, args, _ = req.mock_calls[0]
        assert path_template.validate("%s/v1beta1/{name=projects/*/locations/*/modelMonitors/*}" % client.transport._host, args[1])


def test_get_model_monitor_rest_flattened_error(transport: str = 'rest'):
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport=transport,
    )

    # Attempting to call a method with both a request object and flattened
    # fields is an error.
    with pytest.raises(ValueError):
        client.get_model_monitor(
            model_monitoring_service.GetModelMonitorRequest(),
            name='name_value',
        )


def test_list_model_monitors_rest_use_cached_wrapped_rpc():
    # Clients should use _prep_wrapped_messages to create cached wrapped rpcs,
    # instead of constructing them on each call
    with mock.patch("google.api_core.gapic_v1.method.wrap_method") as wrapper_fn:
        client = ModelMonitoringServiceClient(
            credentials=ga_credentials.AnonymousCredentials(),
            transport="rest",
        )

        # Should wrap all calls on client creation
        assert wrapper_fn.call_count > 0
        wrapper_fn.reset_mock()

        # Ensure method has been cached
        assert client._transport.list_model_monitors in client._transport._wrapped_methods

        # Replace cached wrapped function with mock
        mock_rpc = mock.Mock()
        mock_rpc.return_value.name = "foo" # operation_request.operation in compute client(s) expect a string.
        client._transport._wrapped_methods[client._transport.list_model_monitors] = mock_rpc

        request = {}
        client.list_model_monitors(request)

        # Establish that the underlying gRPC stub method was called.
        assert mock_rpc.call_count == 1

        client.list_model_monitors(request)

        # Establish that a new wrapper was not created for this call
        assert wrapper_fn.call_count == 0
        assert mock_rpc.call_count == 2


def test_list_model_monitors_rest_required_fields(request_type=model_monitoring_service.ListModelMonitorsRequest):
    transport_class = transports.ModelMonitoringServiceRestTransport

    request_init = {}
    request_init["parent"] = ""
    request = request_type(**request_init)
    pb_request = request_type.pb(request)
    jsonified_request = json.loads(json_format.MessageToJson(
        pb_request,
        use_integers_for_enums=False
    ))

    # verify fields with default values are dropped

    unset_fields = transport_class(credentials=ga_credentials.AnonymousCredentials()).list_model_monitors._get_unset_required_fields(jsonified_request)
    jsonified_request.update(unset_fields)

    # verify required fields with default values are now present

    jsonified_request["parent"] = 'parent_value'

    unset_fields = transport_class(credentials=ga_credentials.AnonymousCredentials()).list_model_monitors._get_unset_required_fields(jsonified_request)
    # Check that path parameters and body parameters are not mixing in.
    assert not set(unset_fields) - set(("filter", "page_size", "page_token", "read_mask", ))
    jsonified_request.update(unset_fields)

    # verify required fields with non-default values are left alone
    assert "parent" in jsonified_request
    assert jsonified_request["parent"] == 'parent_value'

    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport='rest',
    )
    request = request_type(**request_init)

    # Designate an appropriate value for the returned response.
    return_value = model_monitoring_service.ListModelMonitorsResponse()
    # Mock the http request call within the method and fake a response.
    with mock.patch.object(Session, 'request') as req:
        # We need to mock transcode() because providing default values
        # for required fields will fail the real version if the http_options
        # expect actual values for those fields.
        with mock.patch.object(path_template, 'transcode') as transcode:
            # A uri without fields and an empty body will force all the
            # request fields to show up in the query_params.
            pb_request = request_type.pb(request)
            transcode_result = {
                'uri': 'v1/sample_method',
                'method': "get",
                'query_params': pb_request,
            }
            transcode.return_value = transcode_result

            response_value = Response()
            response_value.status_code = 200

            # Convert return value to protobuf type
            return_value = model_monitoring_service.ListModelMonitorsResponse.pb(return_value)
            json_return_value = json_format.MessageToJson(return_value)

            response_value._content = json_return_value.encode('UTF-8')
            req.return_value = response_value

            response = client.list_model_monitors(request)

            expected_params = [
                ('$alt', 'json;enum-encoding=int')
            ]
            actual_params = req.call_args.kwargs['params']
            assert expected_params == actual_params


def test_list_model_monitors_rest_unset_required_fields():
    transport = transports.ModelMonitoringServiceRestTransport(credentials=ga_credentials.AnonymousCredentials)

    unset_fields = transport.list_model_monitors._get_unset_required_fields({})
    assert set(unset_fields) == (set(("filter", "pageSize", "pageToken", "readMask", )) & set(("parent", )))


def test_list_model_monitors_rest_flattened():
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport="rest",
    )

    # Mock the http request call within the method and fake a response.
    with mock.patch.object(type(client.transport._session), 'request') as req:
        # Designate an appropriate value for the returned response.
        return_value = model_monitoring_service.ListModelMonitorsResponse()

        # get arguments that satisfy an http rule for this method
        sample_request = {'parent': 'projects/sample1/locations/sample2'}

        # get truthy value for each flattened field
        mock_args = dict(
            parent='parent_value',
        )
        mock_args.update(sample_request)

        # Wrap the value into a proper Response obj
        response_value = Response()
        response_value.status_code = 200
        # Convert return value to protobuf type
        return_value = model_monitoring_service.ListModelMonitorsResponse.pb(return_value)
        json_return_value = json_format.MessageToJson(return_value)
        response_value._content = json_return_value.encode('UTF-8')
        req.return_value = response_value

        client.list_model_monitors(**mock_args)

        # Establish that the underlying call was made with the expected
        # request object values.
        assert len(req.mock_calls) == 1
        _, args, _ = req.mock_calls[0]
        assert path_template.validate("%s/v1beta1/{parent=projects/*/locations/*}/modelMonitors" % client.transport._host, args[1])


def test_list_model_monitors_rest_flattened_error(transport: str = 'rest'):
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport=transport,
    )

    # Attempting to call a method with both a request object and flattened
    # fields is an error.
    with pytest.raises(ValueError):
        client.list_model_monitors(
            model_monitoring_service.ListModelMonitorsRequest(),
            parent='parent_value',
        )


def test_list_model_monitors_rest_pager(transport: str = 'rest'):
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport=transport,
    )

    # Mock the http request call within the method and fake a response.
    with mock.patch.object(Session, 'request') as req:
        # TODO(kbandes): remove this mock unless there's a good reason for it.
        #with mock.patch.object(path_template, 'transcode') as transcode:
        # Set the response as a series of pages
        response = (
            model_monitoring_service.ListModelMonitorsResponse(
                model_monitors=[
                    model_monitor.ModelMonitor(),
                    model_monitor.ModelMonitor(),
                    model_monitor.ModelMonitor(),
                ],
                next_page_token='abc',
            ),
            model_monitoring_service.ListModelMonitorsResponse(
                model_monitors=[],
                next_page_token='def',
            ),
            model_monitoring_service.ListModelMonitorsResponse(
                model_monitors=[
                    model_monitor.ModelMonitor(),
                ],
                next_page_token='ghi',
            ),
            model_monitoring_service.ListModelMonitorsResponse(
                model_monitors=[
                    model_monitor.ModelMonitor(),
                    model_monitor.ModelMonitor(),
                ],
            ),
        )
        # Two responses for two calls
        response = response + response

        # Wrap the values into proper Response objs
        response = tuple(model_monitoring_service.ListModelMonitorsResponse.to_json(x) for x in response)
        return_values = tuple(Response() for i in response)
        for return_val, response_val in zip(return_values, response):
            return_val._content = response_val.encode('UTF-8')
            return_val.status_code = 200
        req.side_effect = return_values

        sample_request = {'parent': 'projects/sample1/locations/sample2'}

        pager = client.list_model_monitors(request=sample_request)

        results = list(pager)
        assert len(results) == 6
        assert all(isinstance(i, model_monitor.ModelMonitor)
                for i in results)

        pages = list(client.list_model_monitors(request=sample_request).pages)
        for page_, token in zip(pages, ['abc','def','ghi', '']):
            assert page_.raw_page.next_page_token == token


def test_delete_model_monitor_rest_use_cached_wrapped_rpc():
    # Clients should use _prep_wrapped_messages to create cached wrapped rpcs,
    # instead of constructing them on each call
    with mock.patch("google.api_core.gapic_v1.method.wrap_method") as wrapper_fn:
        client = ModelMonitoringServiceClient(
            credentials=ga_credentials.AnonymousCredentials(),
            transport="rest",
        )

        # Should wrap all calls on client creation
        assert wrapper_fn.call_count > 0
        wrapper_fn.reset_mock()

        # Ensure method has been cached
        assert client._transport.delete_model_monitor in client._transport._wrapped_methods

        # Replace cached wrapped function with mock
        mock_rpc = mock.Mock()
        mock_rpc.return_value.name = "foo" # operation_request.operation in compute client(s) expect a string.
        client._transport._wrapped_methods[client._transport.delete_model_monitor] = mock_rpc

        request = {}
        client.delete_model_monitor(request)

        # Establish that the underlying gRPC stub method was called.
        assert mock_rpc.call_count == 1

        # Operation methods build a cached wrapper on first rpc call
        # subsequent calls should use the cached wrapper
        wrapper_fn.reset_mock()

        client.delete_model_monitor(request)

        # Establish that a new wrapper was not created for this call
        assert wrapper_fn.call_count == 0
        assert mock_rpc.call_count == 2


def test_delete_model_monitor_rest_required_fields(request_type=model_monitoring_service.DeleteModelMonitorRequest):
    transport_class = transports.ModelMonitoringServiceRestTransport

    request_init = {}
    request_init["name"] = ""
    request = request_type(**request_init)
    pb_request = request_type.pb(request)
    jsonified_request = json.loads(json_format.MessageToJson(
        pb_request,
        use_integers_for_enums=False
    ))

    # verify fields with default values are dropped

    unset_fields = transport_class(credentials=ga_credentials.AnonymousCredentials()).delete_model_monitor._get_unset_required_fields(jsonified_request)
    jsonified_request.update(unset_fields)

    # verify required fields with default values are now present

    jsonified_request["name"] = 'name_value'

    unset_fields = transport_class(credentials=ga_credentials.AnonymousCredentials()).delete_model_monitor._get_unset_required_fields(jsonified_request)
    # Check that path parameters and body parameters are not mixing in.
    assert not set(unset_fields) - set(("force", ))
    jsonified_request.update(unset_fields)

    # verify required fields with non-default values are left alone
    assert "name" in jsonified_request
    assert jsonified_request["name"] == 'name_value'

    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport='rest',
    )
    request = request_type(**request_init)

    # Designate an appropriate value for the returned response.
    return_value = operations_pb2.Operation(name='operations/spam')
    # Mock the http request call within the method and fake a response.
    with mock.patch.object(Session, 'request') as req:
        # We need to mock transcode() because providing default values
        # for required fields will fail the real version if the http_options
        # expect actual values for those fields.
        with mock.patch.object(path_template, 'transcode') as transcode:
            # A uri without fields and an empty body will force all the
            # request fields to show up in the query_params.
            pb_request = request_type.pb(request)
            transcode_result = {
                'uri': 'v1/sample_method',
                'method': "delete",
                'query_params': pb_request,
            }
            transcode.return_value = transcode_result

            response_value = Response()
            response_value.status_code = 200
            json_return_value = json_format.MessageToJson(return_value)

            response_value._content = json_return_value.encode('UTF-8')
            req.return_value = response_value

            response = client.delete_model_monitor(request)

            expected_params = [
                ('$alt', 'json;enum-encoding=int')
            ]
            actual_params = req.call_args.kwargs['params']
            assert expected_params == actual_params


def test_delete_model_monitor_rest_unset_required_fields():
    transport = transports.ModelMonitoringServiceRestTransport(credentials=ga_credentials.AnonymousCredentials)

    unset_fields = transport.delete_model_monitor._get_unset_required_fields({})
    assert set(unset_fields) == (set(("force", )) & set(("name", )))


def test_delete_model_monitor_rest_flattened():
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport="rest",
    )

    # Mock the http request call within the method and fake a response.
    with mock.patch.object(type(client.transport._session), 'request') as req:
        # Designate an appropriate value for the returned response.
        return_value = operations_pb2.Operation(name='operations/spam')

        # get arguments that satisfy an http rule for this method
        sample_request = {'name': 'projects/sample1/locations/sample2/modelMonitors/sample3'}

        # get truthy value for each flattened field
        mock_args = dict(
            name='name_value',
        )
        mock_args.update(sample_request)

        # Wrap the value into a proper Response obj
        response_value = Response()
        response_value.status_code = 200
        json_return_value = json_format.MessageToJson(return_value)
        response_value._content = json_return_value.encode('UTF-8')
        req.return_value = response_value

        client.delete_model_monitor(**mock_args)

        # Establish that the underlying call was made with the expected
        # request object values.
        assert len(req.mock_calls) == 1
        _, args, _ = req.mock_calls[0]
        assert path_template.validate("%s/v1beta1/{name=projects/*/locations/*/modelMonitors/*}" % client.transport._host, args[1])


def test_delete_model_monitor_rest_flattened_error(transport: str = 'rest'):
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport=transport,
    )

    # Attempting to call a method with both a request object and flattened
    # fields is an error.
    with pytest.raises(ValueError):
        client.delete_model_monitor(
            model_monitoring_service.DeleteModelMonitorRequest(),
            name='name_value',
        )


def test_create_model_monitoring_job_rest_use_cached_wrapped_rpc():
    # Clients should use _prep_wrapped_messages to create cached wrapped rpcs,
    # instead of constructing them on each call
    with mock.patch("google.api_core.gapic_v1.method.wrap_method") as wrapper_fn:
        client = ModelMonitoringServiceClient(
            credentials=ga_credentials.AnonymousCredentials(),
            transport="rest",
        )

        # Should wrap all calls on client creation
        assert wrapper_fn.call_count > 0
        wrapper_fn.reset_mock()

        # Ensure method has been cached
        assert client._transport.create_model_monitoring_job in client._transport._wrapped_methods

        # Replace cached wrapped function with mock
        mock_rpc = mock.Mock()
        mock_rpc.return_value.name = "foo" # operation_request.operation in compute client(s) expect a string.
        client._transport._wrapped_methods[client._transport.create_model_monitoring_job] = mock_rpc

        request = {}
        client.create_model_monitoring_job(request)

        # Establish that the underlying gRPC stub method was called.
        assert mock_rpc.call_count == 1

        client.create_model_monitoring_job(request)

        # Establish that a new wrapper was not created for this call
        assert wrapper_fn.call_count == 0
        assert mock_rpc.call_count == 2


def test_create_model_monitoring_job_rest_required_fields(request_type=model_monitoring_service.CreateModelMonitoringJobRequest):
    transport_class = transports.ModelMonitoringServiceRestTransport

    request_init = {}
    request_init["parent"] = ""
    request = request_type(**request_init)
    pb_request = request_type.pb(request)
    jsonified_request = json.loads(json_format.MessageToJson(
        pb_request,
        use_integers_for_enums=False
    ))

    # verify fields with default values are dropped

    unset_fields = transport_class(credentials=ga_credentials.AnonymousCredentials()).create_model_monitoring_job._get_unset_required_fields(jsonified_request)
    jsonified_request.update(unset_fields)

    # verify required fields with default values are now present

    jsonified_request["parent"] = 'parent_value'

    unset_fields = transport_class(credentials=ga_credentials.AnonymousCredentials()).create_model_monitoring_job._get_unset_required_fields(jsonified_request)
    # Check that path parameters and body parameters are not mixing in.
    assert not set(unset_fields) - set(("model_monitoring_job_id", ))
    jsonified_request.update(unset_fields)

    # verify required fields with non-default values are left alone
    assert "parent" in jsonified_request
    assert jsonified_request["parent"] == 'parent_value'

    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport='rest',
    )
    request = request_type(**request_init)

    # Designate an appropriate value for the returned response.
    return_value = gca_model_monitoring_job.ModelMonitoringJob()
    # Mock the http request call within the method and fake a response.
    with mock.patch.object(Session, 'request') as req:
        # We need to mock transcode() because providing default values
        # for required fields will fail the real version if the http_options
        # expect actual values for those fields.
        with mock.patch.object(path_template, 'transcode') as transcode:
            # A uri without fields and an empty body will force all the
            # request fields to show up in the query_params.
            pb_request = request_type.pb(request)
            transcode_result = {
                'uri': 'v1/sample_method',
                'method': "post",
                'query_params': pb_request,
            }
            transcode_result['body'] = pb_request
            transcode.return_value = transcode_result

            response_value = Response()
            response_value.status_code = 200

            # Convert return value to protobuf type
            return_value = gca_model_monitoring_job.ModelMonitoringJob.pb(return_value)
            json_return_value = json_format.MessageToJson(return_value)

            response_value._content = json_return_value.encode('UTF-8')
            req.return_value = response_value

            response = client.create_model_monitoring_job(request)

            expected_params = [
                ('$alt', 'json;enum-encoding=int')
            ]
            actual_params = req.call_args.kwargs['params']
            assert expected_params == actual_params


def test_create_model_monitoring_job_rest_unset_required_fields():
    transport = transports.ModelMonitoringServiceRestTransport(credentials=ga_credentials.AnonymousCredentials)

    unset_fields = transport.create_model_monitoring_job._get_unset_required_fields({})
    assert set(unset_fields) == (set(("modelMonitoringJobId", )) & set(("parent", "modelMonitoringJob", )))


def test_create_model_monitoring_job_rest_flattened():
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport="rest",
    )

    # Mock the http request call within the method and fake a response.
    with mock.patch.object(type(client.transport._session), 'request') as req:
        # Designate an appropriate value for the returned response.
        return_value = gca_model_monitoring_job.ModelMonitoringJob()

        # get arguments that satisfy an http rule for this method
        sample_request = {'parent': 'projects/sample1/locations/sample2/modelMonitors/sample3'}

        # get truthy value for each flattened field
        mock_args = dict(
            parent='parent_value',
            model_monitoring_job=gca_model_monitoring_job.ModelMonitoringJob(name='name_value'),
        )
        mock_args.update(sample_request)

        # Wrap the value into a proper Response obj
        response_value = Response()
        response_value.status_code = 200
        # Convert return value to protobuf type
        return_value = gca_model_monitoring_job.ModelMonitoringJob.pb(return_value)
        json_return_value = json_format.MessageToJson(return_value)
        response_value._content = json_return_value.encode('UTF-8')
        req.return_value = response_value

        client.create_model_monitoring_job(**mock_args)

        # Establish that the underlying call was made with the expected
        # request object values.
        assert len(req.mock_calls) == 1
        _, args, _ = req.mock_calls[0]
        assert path_template.validate("%s/v1beta1/{parent=projects/*/locations/*/modelMonitors/*}/modelMonitoringJobs" % client.transport._host, args[1])


def test_create_model_monitoring_job_rest_flattened_error(transport: str = 'rest'):
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport=transport,
    )

    # Attempting to call a method with both a request object and flattened
    # fields is an error.
    with pytest.raises(ValueError):
        client.create_model_monitoring_job(
            model_monitoring_service.CreateModelMonitoringJobRequest(),
            parent='parent_value',
            model_monitoring_job=gca_model_monitoring_job.ModelMonitoringJob(name='name_value'),
        )


def test_get_model_monitoring_job_rest_use_cached_wrapped_rpc():
    # Clients should use _prep_wrapped_messages to create cached wrapped rpcs,
    # instead of constructing them on each call
    with mock.patch("google.api_core.gapic_v1.method.wrap_method") as wrapper_fn:
        client = ModelMonitoringServiceClient(
            credentials=ga_credentials.AnonymousCredentials(),
            transport="rest",
        )

        # Should wrap all calls on client creation
        assert wrapper_fn.call_count > 0
        wrapper_fn.reset_mock()

        # Ensure method has been cached
        assert client._transport.get_model_monitoring_job in client._transport._wrapped_methods

        # Replace cached wrapped function with mock
        mock_rpc = mock.Mock()
        mock_rpc.return_value.name = "foo" # operation_request.operation in compute client(s) expect a string.
        client._transport._wrapped_methods[client._transport.get_model_monitoring_job] = mock_rpc

        request = {}
        client.get_model_monitoring_job(request)

        # Establish that the underlying gRPC stub method was called.
        assert mock_rpc.call_count == 1

        client.get_model_monitoring_job(request)

        # Establish that a new wrapper was not created for this call
        assert wrapper_fn.call_count == 0
        assert mock_rpc.call_count == 2


def test_get_model_monitoring_job_rest_required_fields(request_type=model_monitoring_service.GetModelMonitoringJobRequest):
    transport_class = transports.ModelMonitoringServiceRestTransport

    request_init = {}
    request_init["name"] = ""
    request = request_type(**request_init)
    pb_request = request_type.pb(request)
    jsonified_request = json.loads(json_format.MessageToJson(
        pb_request,
        use_integers_for_enums=False
    ))

    # verify fields with default values are dropped

    unset_fields = transport_class(credentials=ga_credentials.AnonymousCredentials()).get_model_monitoring_job._get_unset_required_fields(jsonified_request)
    jsonified_request.update(unset_fields)

    # verify required fields with default values are now present

    jsonified_request["name"] = 'name_value'

    unset_fields = transport_class(credentials=ga_credentials.AnonymousCredentials()).get_model_monitoring_job._get_unset_required_fields(jsonified_request)
    jsonified_request.update(unset_fields)

    # verify required fields with non-default values are left alone
    assert "name" in jsonified_request
    assert jsonified_request["name"] == 'name_value'

    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport='rest',
    )
    request = request_type(**request_init)

    # Designate an appropriate value for the returned response.
    return_value = model_monitoring_job.ModelMonitoringJob()
    # Mock the http request call within the method and fake a response.
    with mock.patch.object(Session, 'request') as req:
        # We need to mock transcode() because providing default values
        # for required fields will fail the real version if the http_options
        # expect actual values for those fields.
        with mock.patch.object(path_template, 'transcode') as transcode:
            # A uri without fields and an empty body will force all the
            # request fields to show up in the query_params.
            pb_request = request_type.pb(request)
            transcode_result = {
                'uri': 'v1/sample_method',
                'method': "get",
                'query_params': pb_request,
            }
            transcode.return_value = transcode_result

            response_value = Response()
            response_value.status_code = 200

            # Convert return value to protobuf type
            return_value = model_monitoring_job.ModelMonitoringJob.pb(return_value)
            json_return_value = json_format.MessageToJson(return_value)

            response_value._content = json_return_value.encode('UTF-8')
            req.return_value = response_value

            response = client.get_model_monitoring_job(request)

            expected_params = [
                ('$alt', 'json;enum-encoding=int')
            ]
            actual_params = req.call_args.kwargs['params']
            assert expected_params == actual_params


def test_get_model_monitoring_job_rest_unset_required_fields():
    transport = transports.ModelMonitoringServiceRestTransport(credentials=ga_credentials.AnonymousCredentials)

    unset_fields = transport.get_model_monitoring_job._get_unset_required_fields({})
    assert set(unset_fields) == (set(()) & set(("name", )))


def test_get_model_monitoring_job_rest_flattened():
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport="rest",
    )

    # Mock the http request call within the method and fake a response.
    with mock.patch.object(type(client.transport._session), 'request') as req:
        # Designate an appropriate value for the returned response.
        return_value = model_monitoring_job.ModelMonitoringJob()

        # get arguments that satisfy an http rule for this method
        sample_request = {'name': 'projects/sample1/locations/sample2/modelMonitors/sample3/modelMonitoringJobs/sample4'}

        # get truthy value for each flattened field
        mock_args = dict(
            name='name_value',
        )
        mock_args.update(sample_request)

        # Wrap the value into a proper Response obj
        response_value = Response()
        response_value.status_code = 200
        # Convert return value to protobuf type
        return_value = model_monitoring_job.ModelMonitoringJob.pb(return_value)
        json_return_value = json_format.MessageToJson(return_value)
        response_value._content = json_return_value.encode('UTF-8')
        req.return_value = response_value

        client.get_model_monitoring_job(**mock_args)

        # Establish that the underlying call was made with the expected
        # request object values.
        assert len(req.mock_calls) == 1
        _, args, _ = req.mock_calls[0]
        assert path_template.validate("%s/v1beta1/{name=projects/*/locations/*/modelMonitors/*/modelMonitoringJobs/*}" % client.transport._host, args[1])


def test_get_model_monitoring_job_rest_flattened_error(transport: str = 'rest'):
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport=transport,
    )

    # Attempting to call a method with both a request object and flattened
    # fields is an error.
    with pytest.raises(ValueError):
        client.get_model_monitoring_job(
            model_monitoring_service.GetModelMonitoringJobRequest(),
            name='name_value',
        )


def test_list_model_monitoring_jobs_rest_use_cached_wrapped_rpc():
    # Clients should use _prep_wrapped_messages to create cached wrapped rpcs,
    # instead of constructing them on each call
    with mock.patch("google.api_core.gapic_v1.method.wrap_method") as wrapper_fn:
        client = ModelMonitoringServiceClient(
            credentials=ga_credentials.AnonymousCredentials(),
            transport="rest",
        )

        # Should wrap all calls on client creation
        assert wrapper_fn.call_count > 0
        wrapper_fn.reset_mock()

        # Ensure method has been cached
        assert client._transport.list_model_monitoring_jobs in client._transport._wrapped_methods

        # Replace cached wrapped function with mock
        mock_rpc = mock.Mock()
        mock_rpc.return_value.name = "foo" # operation_request.operation in compute client(s) expect a string.
        client._transport._wrapped_methods[client._transport.list_model_monitoring_jobs] = mock_rpc

        request = {}
        client.list_model_monitoring_jobs(request)

        # Establish that the underlying gRPC stub method was called.
        assert mock_rpc.call_count == 1

        client.list_model_monitoring_jobs(request)

        # Establish that a new wrapper was not created for this call
        assert wrapper_fn.call_count == 0
        assert mock_rpc.call_count == 2


def test_list_model_monitoring_jobs_rest_required_fields(request_type=model_monitoring_service.ListModelMonitoringJobsRequest):
    transport_class = transports.ModelMonitoringServiceRestTransport

    request_init = {}
    request_init["parent"] = ""
    request = request_type(**request_init)
    pb_request = request_type.pb(request)
    jsonified_request = json.loads(json_format.MessageToJson(
        pb_request,
        use_integers_for_enums=False
    ))

    # verify fields with default values are dropped

    unset_fields = transport_class(credentials=ga_credentials.AnonymousCredentials()).list_model_monitoring_jobs._get_unset_required_fields(jsonified_request)
    jsonified_request.update(unset_fields)

    # verify required fields with default values are now present

    jsonified_request["parent"] = 'parent_value'

    unset_fields = transport_class(credentials=ga_credentials.AnonymousCredentials()).list_model_monitoring_jobs._get_unset_required_fields(jsonified_request)
    # Check that path parameters and body parameters are not mixing in.
    assert not set(unset_fields) - set(("filter", "page_size", "page_token", "read_mask", ))
    jsonified_request.update(unset_fields)

    # verify required fields with non-default values are left alone
    assert "parent" in jsonified_request
    assert jsonified_request["parent"] == 'parent_value'

    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport='rest',
    )
    request = request_type(**request_init)

    # Designate an appropriate value for the returned response.
    return_value = model_monitoring_service.ListModelMonitoringJobsResponse()
    # Mock the http request call within the method and fake a response.
    with mock.patch.object(Session, 'request') as req:
        # We need to mock transcode() because providing default values
        # for required fields will fail the real version if the http_options
        # expect actual values for those fields.
        with mock.patch.object(path_template, 'transcode') as transcode:
            # A uri without fields and an empty body will force all the
            # request fields to show up in the query_params.
            pb_request = request_type.pb(request)
            transcode_result = {
                'uri': 'v1/sample_method',
                'method': "get",
                'query_params': pb_request,
            }
            transcode.return_value = transcode_result

            response_value = Response()
            response_value.status_code = 200

            # Convert return value to protobuf type
            return_value = model_monitoring_service.ListModelMonitoringJobsResponse.pb(return_value)
            json_return_value = json_format.MessageToJson(return_value)

            response_value._content = json_return_value.encode('UTF-8')
            req.return_value = response_value

            response = client.list_model_monitoring_jobs(request)

            expected_params = [
                ('$alt', 'json;enum-encoding=int')
            ]
            actual_params = req.call_args.kwargs['params']
            assert expected_params == actual_params


def test_list_model_monitoring_jobs_rest_unset_required_fields():
    transport = transports.ModelMonitoringServiceRestTransport(credentials=ga_credentials.AnonymousCredentials)

    unset_fields = transport.list_model_monitoring_jobs._get_unset_required_fields({})
    assert set(unset_fields) == (set(("filter", "pageSize", "pageToken", "readMask", )) & set(("parent", )))


def test_list_model_monitoring_jobs_rest_flattened():
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport="rest",
    )

    # Mock the http request call within the method and fake a response.
    with mock.patch.object(type(client.transport._session), 'request') as req:
        # Designate an appropriate value for the returned response.
        return_value = model_monitoring_service.ListModelMonitoringJobsResponse()

        # get arguments that satisfy an http rule for this method
        sample_request = {'parent': 'projects/sample1/locations/sample2/modelMonitors/sample3'}

        # get truthy value for each flattened field
        mock_args = dict(
            parent='parent_value',
        )
        mock_args.update(sample_request)

        # Wrap the value into a proper Response obj
        response_value = Response()
        response_value.status_code = 200
        # Convert return value to protobuf type
        return_value = model_monitoring_service.ListModelMonitoringJobsResponse.pb(return_value)
        json_return_value = json_format.MessageToJson(return_value)
        response_value._content = json_return_value.encode('UTF-8')
        req.return_value = response_value

        client.list_model_monitoring_jobs(**mock_args)

        # Establish that the underlying call was made with the expected
        # request object values.
        assert len(req.mock_calls) == 1
        _, args, _ = req.mock_calls[0]
        assert path_template.validate("%s/v1beta1/{parent=projects/*/locations/*/modelMonitors/*}/modelMonitoringJobs" % client.transport._host, args[1])


def test_list_model_monitoring_jobs_rest_flattened_error(transport: str = 'rest'):
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport=transport,
    )

    # Attempting to call a method with both a request object and flattened
    # fields is an error.
    with pytest.raises(ValueError):
        client.list_model_monitoring_jobs(
            model_monitoring_service.ListModelMonitoringJobsRequest(),
            parent='parent_value',
        )


def test_list_model_monitoring_jobs_rest_pager(transport: str = 'rest'):
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport=transport,
    )

    # Mock the http request call within the method and fake a response.
    with mock.patch.object(Session, 'request') as req:
        # TODO(kbandes): remove this mock unless there's a good reason for it.
        #with mock.patch.object(path_template, 'transcode') as transcode:
        # Set the response as a series of pages
        response = (
            model_monitoring_service.ListModelMonitoringJobsResponse(
                model_monitoring_jobs=[
                    model_monitoring_job.ModelMonitoringJob(),
                    model_monitoring_job.ModelMonitoringJob(),
                    model_monitoring_job.ModelMonitoringJob(),
                ],
                next_page_token='abc',
            ),
            model_monitoring_service.ListModelMonitoringJobsResponse(
                model_monitoring_jobs=[],
                next_page_token='def',
            ),
            model_monitoring_service.ListModelMonitoringJobsResponse(
                model_monitoring_jobs=[
                    model_monitoring_job.ModelMonitoringJob(),
                ],
                next_page_token='ghi',
            ),
            model_monitoring_service.ListModelMonitoringJobsResponse(
                model_monitoring_jobs=[
                    model_monitoring_job.ModelMonitoringJob(),
                    model_monitoring_job.ModelMonitoringJob(),
                ],
            ),
        )
        # Two responses for two calls
        response = response + response

        # Wrap the values into proper Response objs
        response = tuple(model_monitoring_service.ListModelMonitoringJobsResponse.to_json(x) for x in response)
        return_values = tuple(Response() for i in response)
        for return_val, response_val in zip(return_values, response):
            return_val._content = response_val.encode('UTF-8')
            return_val.status_code = 200
        req.side_effect = return_values

        sample_request = {'parent': 'projects/sample1/locations/sample2/modelMonitors/sample3'}

        pager = client.list_model_monitoring_jobs(request=sample_request)

        results = list(pager)
        assert len(results) == 6
        assert all(isinstance(i, model_monitoring_job.ModelMonitoringJob)
                for i in results)

        pages = list(client.list_model_monitoring_jobs(request=sample_request).pages)
        for page_, token in zip(pages, ['abc','def','ghi', '']):
            assert page_.raw_page.next_page_token == token


def test_delete_model_monitoring_job_rest_use_cached_wrapped_rpc():
    # Clients should use _prep_wrapped_messages to create cached wrapped rpcs,
    # instead of constructing them on each call
    with mock.patch("google.api_core.gapic_v1.method.wrap_method") as wrapper_fn:
        client = ModelMonitoringServiceClient(
            credentials=ga_credentials.AnonymousCredentials(),
            transport="rest",
        )

        # Should wrap all calls on client creation
        assert wrapper_fn.call_count > 0
        wrapper_fn.reset_mock()

        # Ensure method has been cached
        assert client._transport.delete_model_monitoring_job in client._transport._wrapped_methods

        # Replace cached wrapped function with mock
        mock_rpc = mock.Mock()
        mock_rpc.return_value.name = "foo" # operation_request.operation in compute client(s) expect a string.
        client._transport._wrapped_methods[client._transport.delete_model_monitoring_job] = mock_rpc

        request = {}
        client.delete_model_monitoring_job(request)

        # Establish that the underlying gRPC stub method was called.
        assert mock_rpc.call_count == 1

        # Operation methods build a cached wrapper on first rpc call
        # subsequent calls should use the cached wrapper
        wrapper_fn.reset_mock()

        client.delete_model_monitoring_job(request)

        # Establish that a new wrapper was not created for this call
        assert wrapper_fn.call_count == 0
        assert mock_rpc.call_count == 2


def test_delete_model_monitoring_job_rest_required_fields(request_type=model_monitoring_service.DeleteModelMonitoringJobRequest):
    transport_class = transports.ModelMonitoringServiceRestTransport

    request_init = {}
    request_init["name"] = ""
    request = request_type(**request_init)
    pb_request = request_type.pb(request)
    jsonified_request = json.loads(json_format.MessageToJson(
        pb_request,
        use_integers_for_enums=False
    ))

    # verify fields with default values are dropped

    unset_fields = transport_class(credentials=ga_credentials.AnonymousCredentials()).delete_model_monitoring_job._get_unset_required_fields(jsonified_request)
    jsonified_request.update(unset_fields)

    # verify required fields with default values are now present

    jsonified_request["name"] = 'name_value'

    unset_fields = transport_class(credentials=ga_credentials.AnonymousCredentials()).delete_model_monitoring_job._get_unset_required_fields(jsonified_request)
    jsonified_request.update(unset_fields)

    # verify required fields with non-default values are left alone
    assert "name" in jsonified_request
    assert jsonified_request["name"] == 'name_value'

    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport='rest',
    )
    request = request_type(**request_init)

    # Designate an appropriate value for the returned response.
    return_value = operations_pb2.Operation(name='operations/spam')
    # Mock the http request call within the method and fake a response.
    with mock.patch.object(Session, 'request') as req:
        # We need to mock transcode() because providing default values
        # for required fields will fail the real version if the http_options
        # expect actual values for those fields.
        with mock.patch.object(path_template, 'transcode') as transcode:
            # A uri without fields and an empty body will force all the
            # request fields to show up in the query_params.
            pb_request = request_type.pb(request)
            transcode_result = {
                'uri': 'v1/sample_method',
                'method': "delete",
                'query_params': pb_request,
            }
            transcode.return_value = transcode_result

            response_value = Response()
            response_value.status_code = 200
            json_return_value = json_format.MessageToJson(return_value)

            response_value._content = json_return_value.encode('UTF-8')
            req.return_value = response_value

            response = client.delete_model_monitoring_job(request)

            expected_params = [
                ('$alt', 'json;enum-encoding=int')
            ]
            actual_params = req.call_args.kwargs['params']
            assert expected_params == actual_params


def test_delete_model_monitoring_job_rest_unset_required_fields():
    transport = transports.ModelMonitoringServiceRestTransport(credentials=ga_credentials.AnonymousCredentials)

    unset_fields = transport.delete_model_monitoring_job._get_unset_required_fields({})
    assert set(unset_fields) == (set(()) & set(("name", )))


def test_delete_model_monitoring_job_rest_flattened():
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport="rest",
    )

    # Mock the http request call within the method and fake a response.
    with mock.patch.object(type(client.transport._session), 'request') as req:
        # Designate an appropriate value for the returned response.
        return_value = operations_pb2.Operation(name='operations/spam')

        # get arguments that satisfy an http rule for this method
        sample_request = {'name': 'projects/sample1/locations/sample2/modelMonitors/sample3/modelMonitoringJobs/sample4'}

        # get truthy value for each flattened field
        mock_args = dict(
            name='name_value',
        )
        mock_args.update(sample_request)

        # Wrap the value into a proper Response obj
        response_value = Response()
        response_value.status_code = 200
        json_return_value = json_format.MessageToJson(return_value)
        response_value._content = json_return_value.encode('UTF-8')
        req.return_value = response_value

        client.delete_model_monitoring_job(**mock_args)

        # Establish that the underlying call was made with the expected
        # request object values.
        assert len(req.mock_calls) == 1
        _, args, _ = req.mock_calls[0]
        assert path_template.validate("%s/v1beta1/{name=projects/*/locations/*/modelMonitors/*/modelMonitoringJobs/*}" % client.transport._host, args[1])


def test_delete_model_monitoring_job_rest_flattened_error(transport: str = 'rest'):
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport=transport,
    )

    # Attempting to call a method with both a request object and flattened
    # fields is an error.
    with pytest.raises(ValueError):
        client.delete_model_monitoring_job(
            model_monitoring_service.DeleteModelMonitoringJobRequest(),
            name='name_value',
        )


def test_search_model_monitoring_stats_rest_use_cached_wrapped_rpc():
    # Clients should use _prep_wrapped_messages to create cached wrapped rpcs,
    # instead of constructing them on each call
    with mock.patch("google.api_core.gapic_v1.method.wrap_method") as wrapper_fn:
        client = ModelMonitoringServiceClient(
            credentials=ga_credentials.AnonymousCredentials(),
            transport="rest",
        )

        # Should wrap all calls on client creation
        assert wrapper_fn.call_count > 0
        wrapper_fn.reset_mock()

        # Ensure method has been cached
        assert client._transport.search_model_monitoring_stats in client._transport._wrapped_methods

        # Replace cached wrapped function with mock
        mock_rpc = mock.Mock()
        mock_rpc.return_value.name = "foo" # operation_request.operation in compute client(s) expect a string.
        client._transport._wrapped_methods[client._transport.search_model_monitoring_stats] = mock_rpc

        request = {}
        client.search_model_monitoring_stats(request)

        # Establish that the underlying gRPC stub method was called.
        assert mock_rpc.call_count == 1

        client.search_model_monitoring_stats(request)

        # Establish that a new wrapper was not created for this call
        assert wrapper_fn.call_count == 0
        assert mock_rpc.call_count == 2


def test_search_model_monitoring_stats_rest_required_fields(request_type=model_monitoring_service.SearchModelMonitoringStatsRequest):
    transport_class = transports.ModelMonitoringServiceRestTransport

    request_init = {}
    request_init["model_monitor"] = ""
    request = request_type(**request_init)
    pb_request = request_type.pb(request)
    jsonified_request = json.loads(json_format.MessageToJson(
        pb_request,
        use_integers_for_enums=False
    ))

    # verify fields with default values are dropped

    unset_fields = transport_class(credentials=ga_credentials.AnonymousCredentials()).search_model_monitoring_stats._get_unset_required_fields(jsonified_request)
    jsonified_request.update(unset_fields)

    # verify required fields with default values are now present

    jsonified_request["modelMonitor"] = 'model_monitor_value'

    unset_fields = transport_class(credentials=ga_credentials.AnonymousCredentials()).search_model_monitoring_stats._get_unset_required_fields(jsonified_request)
    jsonified_request.update(unset_fields)

    # verify required fields with non-default values are left alone
    assert "modelMonitor" in jsonified_request
    assert jsonified_request["modelMonitor"] == 'model_monitor_value'

    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport='rest',
    )
    request = request_type(**request_init)

    # Designate an appropriate value for the returned response.
    return_value = model_monitoring_service.SearchModelMonitoringStatsResponse()
    # Mock the http request call within the method and fake a response.
    with mock.patch.object(Session, 'request') as req:
        # We need to mock transcode() because providing default values
        # for required fields will fail the real version if the http_options
        # expect actual values for those fields.
        with mock.patch.object(path_template, 'transcode') as transcode:
            # A uri without fields and an empty body will force all the
            # request fields to show up in the query_params.
            pb_request = request_type.pb(request)
            transcode_result = {
                'uri': 'v1/sample_method',
                'method': "post",
                'query_params': pb_request,
            }
            transcode_result['body'] = pb_request
            transcode.return_value = transcode_result

            response_value = Response()
            response_value.status_code = 200

            # Convert return value to protobuf type
            return_value = model_monitoring_service.SearchModelMonitoringStatsResponse.pb(return_value)
            json_return_value = json_format.MessageToJson(return_value)

            response_value._content = json_return_value.encode('UTF-8')
            req.return_value = response_value

            response = client.search_model_monitoring_stats(request)

            expected_params = [
                ('$alt', 'json;enum-encoding=int')
            ]
            actual_params = req.call_args.kwargs['params']
            assert expected_params == actual_params


def test_search_model_monitoring_stats_rest_unset_required_fields():
    transport = transports.ModelMonitoringServiceRestTransport(credentials=ga_credentials.AnonymousCredentials)

    unset_fields = transport.search_model_monitoring_stats._get_unset_required_fields({})
    assert set(unset_fields) == (set(()) & set(("modelMonitor", )))


def test_search_model_monitoring_stats_rest_flattened():
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport="rest",
    )

    # Mock the http request call within the method and fake a response.
    with mock.patch.object(type(client.transport._session), 'request') as req:
        # Designate an appropriate value for the returned response.
        return_value = model_monitoring_service.SearchModelMonitoringStatsResponse()

        # get arguments that satisfy an http rule for this method
        sample_request = {'model_monitor': 'projects/sample1/locations/sample2/modelMonitors/sample3'}

        # get truthy value for each flattened field
        mock_args = dict(
            model_monitor='model_monitor_value',
        )
        mock_args.update(sample_request)

        # Wrap the value into a proper Response obj
        response_value = Response()
        response_value.status_code = 200
        # Convert return value to protobuf type
        return_value = model_monitoring_service.SearchModelMonitoringStatsResponse.pb(return_value)
        json_return_value = json_format.MessageToJson(return_value)
        response_value._content = json_return_value.encode('UTF-8')
        req.return_value = response_value

        client.search_model_monitoring_stats(**mock_args)

        # Establish that the underlying call was made with the expected
        # request object values.
        assert len(req.mock_calls) == 1
        _, args, _ = req.mock_calls[0]
        assert path_template.validate("%s/v1beta1/{model_monitor=projects/*/locations/*/modelMonitors/*}:searchModelMonitoringStats" % client.transport._host, args[1])


def test_search_model_monitoring_stats_rest_flattened_error(transport: str = 'rest'):
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport=transport,
    )

    # Attempting to call a method with both a request object and flattened
    # fields is an error.
    with pytest.raises(ValueError):
        client.search_model_monitoring_stats(
            model_monitoring_service.SearchModelMonitoringStatsRequest(),
            model_monitor='model_monitor_value',
        )


def test_search_model_monitoring_stats_rest_pager(transport: str = 'rest'):
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport=transport,
    )

    # Mock the http request call within the method and fake a response.
    with mock.patch.object(Session, 'request') as req:
        # TODO(kbandes): remove this mock unless there's a good reason for it.
        #with mock.patch.object(path_template, 'transcode') as transcode:
        # Set the response as a series of pages
        response = (
            model_monitoring_service.SearchModelMonitoringStatsResponse(
                monitoring_stats=[
                    model_monitoring_stats.ModelMonitoringStats(),
                    model_monitoring_stats.ModelMonitoringStats(),
                    model_monitoring_stats.ModelMonitoringStats(),
                ],
                next_page_token='abc',
            ),
            model_monitoring_service.SearchModelMonitoringStatsResponse(
                monitoring_stats=[],
                next_page_token='def',
            ),
            model_monitoring_service.SearchModelMonitoringStatsResponse(
                monitoring_stats=[
                    model_monitoring_stats.ModelMonitoringStats(),
                ],
                next_page_token='ghi',
            ),
            model_monitoring_service.SearchModelMonitoringStatsResponse(
                monitoring_stats=[
                    model_monitoring_stats.ModelMonitoringStats(),
                    model_monitoring_stats.ModelMonitoringStats(),
                ],
            ),
        )
        # Two responses for two calls
        response = response + response

        # Wrap the values into proper Response objs
        response = tuple(model_monitoring_service.SearchModelMonitoringStatsResponse.to_json(x) for x in response)
        return_values = tuple(Response() for i in response)
        for return_val, response_val in zip(return_values, response):
            return_val._content = response_val.encode('UTF-8')
            return_val.status_code = 200
        req.side_effect = return_values

        sample_request = {'model_monitor': 'projects/sample1/locations/sample2/modelMonitors/sample3'}

        pager = client.search_model_monitoring_stats(request=sample_request)

        results = list(pager)
        assert len(results) == 6
        assert all(isinstance(i, model_monitoring_stats.ModelMonitoringStats)
                for i in results)

        pages = list(client.search_model_monitoring_stats(request=sample_request).pages)
        for page_, token in zip(pages, ['abc','def','ghi', '']):
            assert page_.raw_page.next_page_token == token


def test_search_model_monitoring_alerts_rest_use_cached_wrapped_rpc():
    # Clients should use _prep_wrapped_messages to create cached wrapped rpcs,
    # instead of constructing them on each call
    with mock.patch("google.api_core.gapic_v1.method.wrap_method") as wrapper_fn:
        client = ModelMonitoringServiceClient(
            credentials=ga_credentials.AnonymousCredentials(),
            transport="rest",
        )

        # Should wrap all calls on client creation
        assert wrapper_fn.call_count > 0
        wrapper_fn.reset_mock()

        # Ensure method has been cached
        assert client._transport.search_model_monitoring_alerts in client._transport._wrapped_methods

        # Replace cached wrapped function with mock
        mock_rpc = mock.Mock()
        mock_rpc.return_value.name = "foo" # operation_request.operation in compute client(s) expect a string.
        client._transport._wrapped_methods[client._transport.search_model_monitoring_alerts] = mock_rpc

        request = {}
        client.search_model_monitoring_alerts(request)

        # Establish that the underlying gRPC stub method was called.
        assert mock_rpc.call_count == 1

        client.search_model_monitoring_alerts(request)

        # Establish that a new wrapper was not created for this call
        assert wrapper_fn.call_count == 0
        assert mock_rpc.call_count == 2


def test_search_model_monitoring_alerts_rest_required_fields(request_type=model_monitoring_service.SearchModelMonitoringAlertsRequest):
    transport_class = transports.ModelMonitoringServiceRestTransport

    request_init = {}
    request_init["model_monitor"] = ""
    request = request_type(**request_init)
    pb_request = request_type.pb(request)
    jsonified_request = json.loads(json_format.MessageToJson(
        pb_request,
        use_integers_for_enums=False
    ))

    # verify fields with default values are dropped

    unset_fields = transport_class(credentials=ga_credentials.AnonymousCredentials()).search_model_monitoring_alerts._get_unset_required_fields(jsonified_request)
    jsonified_request.update(unset_fields)

    # verify required fields with default values are now present

    jsonified_request["modelMonitor"] = 'model_monitor_value'

    unset_fields = transport_class(credentials=ga_credentials.AnonymousCredentials()).search_model_monitoring_alerts._get_unset_required_fields(jsonified_request)
    jsonified_request.update(unset_fields)

    # verify required fields with non-default values are left alone
    assert "modelMonitor" in jsonified_request
    assert jsonified_request["modelMonitor"] == 'model_monitor_value'

    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport='rest',
    )
    request = request_type(**request_init)

    # Designate an appropriate value for the returned response.
    return_value = model_monitoring_service.SearchModelMonitoringAlertsResponse()
    # Mock the http request call within the method and fake a response.
    with mock.patch.object(Session, 'request') as req:
        # We need to mock transcode() because providing default values
        # for required fields will fail the real version if the http_options
        # expect actual values for those fields.
        with mock.patch.object(path_template, 'transcode') as transcode:
            # A uri without fields and an empty body will force all the
            # request fields to show up in the query_params.
            pb_request = request_type.pb(request)
            transcode_result = {
                'uri': 'v1/sample_method',
                'method': "post",
                'query_params': pb_request,
            }
            transcode_result['body'] = pb_request
            transcode.return_value = transcode_result

            response_value = Response()
            response_value.status_code = 200

            # Convert return value to protobuf type
            return_value = model_monitoring_service.SearchModelMonitoringAlertsResponse.pb(return_value)
            json_return_value = json_format.MessageToJson(return_value)

            response_value._content = json_return_value.encode('UTF-8')
            req.return_value = response_value

            response = client.search_model_monitoring_alerts(request)

            expected_params = [
                ('$alt', 'json;enum-encoding=int')
            ]
            actual_params = req.call_args.kwargs['params']
            assert expected_params == actual_params


def test_search_model_monitoring_alerts_rest_unset_required_fields():
    transport = transports.ModelMonitoringServiceRestTransport(credentials=ga_credentials.AnonymousCredentials)

    unset_fields = transport.search_model_monitoring_alerts._get_unset_required_fields({})
    assert set(unset_fields) == (set(()) & set(("modelMonitor", )))


def test_search_model_monitoring_alerts_rest_flattened():
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport="rest",
    )

    # Mock the http request call within the method and fake a response.
    with mock.patch.object(type(client.transport._session), 'request') as req:
        # Designate an appropriate value for the returned response.
        return_value = model_monitoring_service.SearchModelMonitoringAlertsResponse()

        # get arguments that satisfy an http rule for this method
        sample_request = {'model_monitor': 'projects/sample1/locations/sample2/modelMonitors/sample3'}

        # get truthy value for each flattened field
        mock_args = dict(
            model_monitor='model_monitor_value',
        )
        mock_args.update(sample_request)

        # Wrap the value into a proper Response obj
        response_value = Response()
        response_value.status_code = 200
        # Convert return value to protobuf type
        return_value = model_monitoring_service.SearchModelMonitoringAlertsResponse.pb(return_value)
        json_return_value = json_format.MessageToJson(return_value)
        response_value._content = json_return_value.encode('UTF-8')
        req.return_value = response_value

        client.search_model_monitoring_alerts(**mock_args)

        # Establish that the underlying call was made with the expected
        # request object values.
        assert len(req.mock_calls) == 1
        _, args, _ = req.mock_calls[0]
        assert path_template.validate("%s/v1beta1/{model_monitor=projects/*/locations/*/modelMonitors/*}:searchModelMonitoringAlerts" % client.transport._host, args[1])


def test_search_model_monitoring_alerts_rest_flattened_error(transport: str = 'rest'):
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport=transport,
    )

    # Attempting to call a method with both a request object and flattened
    # fields is an error.
    with pytest.raises(ValueError):
        client.search_model_monitoring_alerts(
            model_monitoring_service.SearchModelMonitoringAlertsRequest(),
            model_monitor='model_monitor_value',
        )


def test_search_model_monitoring_alerts_rest_pager(transport: str = 'rest'):
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport=transport,
    )

    # Mock the http request call within the method and fake a response.
    with mock.patch.object(Session, 'request') as req:
        # TODO(kbandes): remove this mock unless there's a good reason for it.
        #with mock.patch.object(path_template, 'transcode') as transcode:
        # Set the response as a series of pages
        response = (
            model_monitoring_service.SearchModelMonitoringAlertsResponse(
                model_monitoring_alerts=[
                    model_monitoring_alert.ModelMonitoringAlert(),
                    model_monitoring_alert.ModelMonitoringAlert(),
                    model_monitoring_alert.ModelMonitoringAlert(),
                ],
                next_page_token='abc',
            ),
            model_monitoring_service.SearchModelMonitoringAlertsResponse(
                model_monitoring_alerts=[],
                next_page_token='def',
            ),
            model_monitoring_service.SearchModelMonitoringAlertsResponse(
                model_monitoring_alerts=[
                    model_monitoring_alert.ModelMonitoringAlert(),
                ],
                next_page_token='ghi',
            ),
            model_monitoring_service.SearchModelMonitoringAlertsResponse(
                model_monitoring_alerts=[
                    model_monitoring_alert.ModelMonitoringAlert(),
                    model_monitoring_alert.ModelMonitoringAlert(),
                ],
            ),
        )
        # Two responses for two calls
        response = response + response

        # Wrap the values into proper Response objs
        response = tuple(model_monitoring_service.SearchModelMonitoringAlertsResponse.to_json(x) for x in response)
        return_values = tuple(Response() for i in response)
        for return_val, response_val in zip(return_values, response):
            return_val._content = response_val.encode('UTF-8')
            return_val.status_code = 200
        req.side_effect = return_values

        sample_request = {'model_monitor': 'projects/sample1/locations/sample2/modelMonitors/sample3'}

        pager = client.search_model_monitoring_alerts(request=sample_request)

        results = list(pager)
        assert len(results) == 6
        assert all(isinstance(i, model_monitoring_alert.ModelMonitoringAlert)
                for i in results)

        pages = list(client.search_model_monitoring_alerts(request=sample_request).pages)
        for page_, token in zip(pages, ['abc','def','ghi', '']):
            assert page_.raw_page.next_page_token == token


def test_credentials_transport_error():
    # It is an error to provide credentials and a transport instance.
    transport = transports.ModelMonitoringServiceGrpcTransport(
        credentials=ga_credentials.AnonymousCredentials(),
    )
    with pytest.raises(ValueError):
        client = ModelMonitoringServiceClient(
            credentials=ga_credentials.AnonymousCredentials(),
            transport=transport,
        )

    # It is an error to provide a credentials file and a transport instance.
    transport = transports.ModelMonitoringServiceGrpcTransport(
        credentials=ga_credentials.AnonymousCredentials(),
    )
    with pytest.raises(ValueError):
        client = ModelMonitoringServiceClient(
            client_options={"credentials_file": "credentials.json"},
            transport=transport,
        )

    # It is an error to provide an api_key and a transport instance.
    transport = transports.ModelMonitoringServiceGrpcTransport(
        credentials=ga_credentials.AnonymousCredentials(),
    )
    options = client_options.ClientOptions()
    options.api_key = "api_key"
    with pytest.raises(ValueError):
        client = ModelMonitoringServiceClient(
            client_options=options,
            transport=transport,
        )

    # It is an error to provide an api_key and a credential.
    options = client_options.ClientOptions()
    options.api_key = "api_key"
    with pytest.raises(ValueError):
        client = ModelMonitoringServiceClient(
            client_options=options,
            credentials=ga_credentials.AnonymousCredentials()
        )

    # It is an error to provide scopes and a transport instance.
    transport = transports.ModelMonitoringServiceGrpcTransport(
        credentials=ga_credentials.AnonymousCredentials(),
    )
    with pytest.raises(ValueError):
        client = ModelMonitoringServiceClient(
            client_options={"scopes": ["1", "2"]},
            transport=transport,
        )


def test_transport_instance():
    # A client may be instantiated with a custom transport instance.
    transport = transports.ModelMonitoringServiceGrpcTransport(
        credentials=ga_credentials.AnonymousCredentials(),
    )
    client = ModelMonitoringServiceClient(transport=transport)
    assert client.transport is transport

def test_transport_get_channel():
    # A client may be instantiated with a custom transport instance.
    transport = transports.ModelMonitoringServiceGrpcTransport(
        credentials=ga_credentials.AnonymousCredentials(),
    )
    channel = transport.grpc_channel
    assert channel

    transport = transports.ModelMonitoringServiceGrpcAsyncIOTransport(
        credentials=ga_credentials.AnonymousCredentials(),
    )
    channel = transport.grpc_channel
    assert channel

@pytest.mark.parametrize("transport_class", [
    transports.ModelMonitoringServiceGrpcTransport,
    transports.ModelMonitoringServiceGrpcAsyncIOTransport,
    transports.ModelMonitoringServiceRestTransport,
])
def test_transport_adc(transport_class):
    # Test default credentials are used if not provided.
    with mock.patch.object(google.auth, 'default') as adc:
        adc.return_value = (ga_credentials.AnonymousCredentials(), None)
        transport_class()
        adc.assert_called_once()

def test_transport_kind_grpc():
    transport = ModelMonitoringServiceClient.get_transport_class("grpc")(
        credentials=ga_credentials.AnonymousCredentials()
    )
    assert transport.kind == "grpc"


def test_initialize_client_w_grpc():
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport="grpc"
    )
    assert client is not None


# This test is a coverage failsafe to make sure that totally empty calls,
# i.e. request == None and no flattened fields passed, work.
def test_create_model_monitor_empty_call_grpc():
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport="grpc",
    )

    # Mock the actual call, and fake the request.
    with mock.patch.object(
            type(client.transport.create_model_monitor),
            '__call__') as call:
        call.return_value = operations_pb2.Operation(name='operations/op')
        client.create_model_monitor(request=None)

        # Establish that the underlying stub method was called.
        call.assert_called()
        _, args, _ = call.mock_calls[0]
        request_msg = model_monitoring_service.CreateModelMonitorRequest()

        assert args[0] == request_msg


# This test is a coverage failsafe to make sure that totally empty calls,
# i.e. request == None and no flattened fields passed, work.
def test_update_model_monitor_empty_call_grpc():
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport="grpc",
    )

    # Mock the actual call, and fake the request.
    with mock.patch.object(
            type(client.transport.update_model_monitor),
            '__call__') as call:
        call.return_value = operations_pb2.Operation(name='operations/op')
        client.update_model_monitor(request=None)

        # Establish that the underlying stub method was called.
        call.assert_called()
        _, args, _ = call.mock_calls[0]
        request_msg = model_monitoring_service.UpdateModelMonitorRequest()

        assert args[0] == request_msg


# This test is a coverage failsafe to make sure that totally empty calls,
# i.e. request == None and no flattened fields passed, work.
def test_get_model_monitor_empty_call_grpc():
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport="grpc",
    )

    # Mock the actual call, and fake the request.
    with mock.patch.object(
            type(client.transport.get_model_monitor),
            '__call__') as call:
        call.return_value = model_monitor.ModelMonitor()
        client.get_model_monitor(request=None)

        # Establish that the underlying stub method was called.
        call.assert_called()
        _, args, _ = call.mock_calls[0]
        request_msg = model_monitoring_service.GetModelMonitorRequest()

        assert args[0] == request_msg


# This test is a coverage failsafe to make sure that totally empty calls,
# i.e. request == None and no flattened fields passed, work.
def test_list_model_monitors_empty_call_grpc():
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport="grpc",
    )

    # Mock the actual call, and fake the request.
    with mock.patch.object(
            type(client.transport.list_model_monitors),
            '__call__') as call:
        call.return_value = model_monitoring_service.ListModelMonitorsResponse()
        client.list_model_monitors(request=None)

        # Establish that the underlying stub method was called.
        call.assert_called()
        _, args, _ = call.mock_calls[0]
        request_msg = model_monitoring_service.ListModelMonitorsRequest()

        assert args[0] == request_msg


# This test is a coverage failsafe to make sure that totally empty calls,
# i.e. request == None and no flattened fields passed, work.
def test_delete_model_monitor_empty_call_grpc():
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport="grpc",
    )

    # Mock the actual call, and fake the request.
    with mock.patch.object(
            type(client.transport.delete_model_monitor),
            '__call__') as call:
        call.return_value = operations_pb2.Operation(name='operations/op')
        client.delete_model_monitor(request=None)

        # Establish that the underlying stub method was called.
        call.assert_called()
        _, args, _ = call.mock_calls[0]
        request_msg = model_monitoring_service.DeleteModelMonitorRequest()

        assert args[0] == request_msg


# This test is a coverage failsafe to make sure that totally empty calls,
# i.e. request == None and no flattened fields passed, work.
def test_create_model_monitoring_job_empty_call_grpc():
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport="grpc",
    )

    # Mock the actual call, and fake the request.
    with mock.patch.object(
            type(client.transport.create_model_monitoring_job),
            '__call__') as call:
        call.return_value = gca_model_monitoring_job.ModelMonitoringJob()
        client.create_model_monitoring_job(request=None)

        # Establish that the underlying stub method was called.
        call.assert_called()
        _, args, _ = call.mock_calls[0]
        request_msg = model_monitoring_service.CreateModelMonitoringJobRequest()

        assert args[0] == request_msg


# This test is a coverage failsafe to make sure that totally empty calls,
# i.e. request == None and no flattened fields passed, work.
def test_get_model_monitoring_job_empty_call_grpc():
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport="grpc",
    )

    # Mock the actual call, and fake the request.
    with mock.patch.object(
            type(client.transport.get_model_monitoring_job),
            '__call__') as call:
        call.return_value = model_monitoring_job.ModelMonitoringJob()
        client.get_model_monitoring_job(request=None)

        # Establish that the underlying stub method was called.
        call.assert_called()
        _, args, _ = call.mock_calls[0]
        request_msg = model_monitoring_service.GetModelMonitoringJobRequest()

        assert args[0] == request_msg


# This test is a coverage failsafe to make sure that totally empty calls,
# i.e. request == None and no flattened fields passed, work.
def test_list_model_monitoring_jobs_empty_call_grpc():
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport="grpc",
    )

    # Mock the actual call, and fake the request.
    with mock.patch.object(
            type(client.transport.list_model_monitoring_jobs),
            '__call__') as call:
        call.return_value = model_monitoring_service.ListModelMonitoringJobsResponse()
        client.list_model_monitoring_jobs(request=None)

        # Establish that the underlying stub method was called.
        call.assert_called()
        _, args, _ = call.mock_calls[0]
        request_msg = model_monitoring_service.ListModelMonitoringJobsRequest()

        assert args[0] == request_msg


# This test is a coverage failsafe to make sure that totally empty calls,
# i.e. request == None and no flattened fields passed, work.
def test_delete_model_monitoring_job_empty_call_grpc():
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport="grpc",
    )

    # Mock the actual call, and fake the request.
    with mock.patch.object(
            type(client.transport.delete_model_monitoring_job),
            '__call__') as call:
        call.return_value = operations_pb2.Operation(name='operations/op')
        client.delete_model_monitoring_job(request=None)

        # Establish that the underlying stub method was called.
        call.assert_called()
        _, args, _ = call.mock_calls[0]
        request_msg = model_monitoring_service.DeleteModelMonitoringJobRequest()

        assert args[0] == request_msg


# This test is a coverage failsafe to make sure that totally empty calls,
# i.e. request == None and no flattened fields passed, work.
def test_search_model_monitoring_stats_empty_call_grpc():
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport="grpc",
    )

    # Mock the actual call, and fake the request.
    with mock.patch.object(
            type(client.transport.search_model_monitoring_stats),
            '__call__') as call:
        call.return_value = model_monitoring_service.SearchModelMonitoringStatsResponse()
        client.search_model_monitoring_stats(request=None)

        # Establish that the underlying stub method was called.
        call.assert_called()
        _, args, _ = call.mock_calls[0]
        request_msg = model_monitoring_service.SearchModelMonitoringStatsRequest()

        assert args[0] == request_msg


# This test is a coverage failsafe to make sure that totally empty calls,
# i.e. request == None and no flattened fields passed, work.
def test_search_model_monitoring_alerts_empty_call_grpc():
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport="grpc",
    )

    # Mock the actual call, and fake the request.
    with mock.patch.object(
            type(client.transport.search_model_monitoring_alerts),
            '__call__') as call:
        call.return_value = model_monitoring_service.SearchModelMonitoringAlertsResponse()
        client.search_model_monitoring_alerts(request=None)

        # Establish that the underlying stub method was called.
        call.assert_called()
        _, args, _ = call.mock_calls[0]
        request_msg = model_monitoring_service.SearchModelMonitoringAlertsRequest()

        assert args[0] == request_msg


def test_transport_kind_grpc_asyncio():
    transport = ModelMonitoringServiceAsyncClient.get_transport_class("grpc_asyncio")(
        credentials=async_anonymous_credentials()
    )
    assert transport.kind == "grpc_asyncio"


def test_initialize_client_w_grpc_asyncio():
    client = ModelMonitoringServiceAsyncClient(
        credentials=async_anonymous_credentials(),
        transport="grpc_asyncio"
    )
    assert client is not None


# This test is a coverage failsafe to make sure that totally empty calls,
# i.e. request == None and no flattened fields passed, work.
@pytest.mark.asyncio
async def test_create_model_monitor_empty_call_grpc_asyncio():
    client = ModelMonitoringServiceAsyncClient(
        credentials=async_anonymous_credentials(),
        transport="grpc_asyncio",
    )

    # Mock the actual call, and fake the request.
    with mock.patch.object(
            type(client.transport.create_model_monitor),
            '__call__') as call:
        # Designate an appropriate return value for the call.
        call.return_value = grpc_helpers_async.FakeUnaryUnaryCall(
            operations_pb2.Operation(name='operations/spam')
        )
        await client.create_model_monitor(request=None)

        # Establish that the underlying stub method was called.
        call.assert_called()
        _, args, _ = call.mock_calls[0]
        request_msg = model_monitoring_service.CreateModelMonitorRequest()

        assert args[0] == request_msg


# This test is a coverage failsafe to make sure that totally empty calls,
# i.e. request == None and no flattened fields passed, work.
@pytest.mark.asyncio
async def test_update_model_monitor_empty_call_grpc_asyncio():
    client = ModelMonitoringServiceAsyncClient(
        credentials=async_anonymous_credentials(),
        transport="grpc_asyncio",
    )

    # Mock the actual call, and fake the request.
    with mock.patch.object(
            type(client.transport.update_model_monitor),
            '__call__') as call:
        # Designate an appropriate return value for the call.
        call.return_value = grpc_helpers_async.FakeUnaryUnaryCall(
            operations_pb2.Operation(name='operations/spam')
        )
        await client.update_model_monitor(request=None)

        # Establish that the underlying stub method was called.
        call.assert_called()
        _, args, _ = call.mock_calls[0]
        request_msg = model_monitoring_service.UpdateModelMonitorRequest()

        assert args[0] == request_msg


# This test is a coverage failsafe to make sure that totally empty calls,
# i.e. request == None and no flattened fields passed, work.
@pytest.mark.asyncio
async def test_get_model_monitor_empty_call_grpc_asyncio():
    client = ModelMonitoringServiceAsyncClient(
        credentials=async_anonymous_credentials(),
        transport="grpc_asyncio",
    )

    # Mock the actual call, and fake the request.
    with mock.patch.object(
            type(client.transport.get_model_monitor),
            '__call__') as call:
        # Designate an appropriate return value for the call.
        call.return_value = grpc_helpers_async.FakeUnaryUnaryCall(model_monitor.ModelMonitor(
            name='name_value',
            display_name='display_name_value',
            satisfies_pzs=True,
            satisfies_pzi=True,
        ))
        await client.get_model_monitor(request=None)

        # Establish that the underlying stub method was called.
        call.assert_called()
        _, args, _ = call.mock_calls[0]
        request_msg = model_monitoring_service.GetModelMonitorRequest()

        assert args[0] == request_msg


# This test is a coverage failsafe to make sure that totally empty calls,
# i.e. request == None and no flattened fields passed, work.
@pytest.mark.asyncio
async def test_list_model_monitors_empty_call_grpc_asyncio():
    client = ModelMonitoringServiceAsyncClient(
        credentials=async_anonymous_credentials(),
        transport="grpc_asyncio",
    )

    # Mock the actual call, and fake the request.
    with mock.patch.object(
            type(client.transport.list_model_monitors),
            '__call__') as call:
        # Designate an appropriate return value for the call.
        call.return_value = grpc_helpers_async.FakeUnaryUnaryCall(model_monitoring_service.ListModelMonitorsResponse(
            next_page_token='next_page_token_value',
        ))
        await client.list_model_monitors(request=None)

        # Establish that the underlying stub method was called.
        call.assert_called()
        _, args, _ = call.mock_calls[0]
        request_msg = model_monitoring_service.ListModelMonitorsRequest()

        assert args[0] == request_msg


# This test is a coverage failsafe to make sure that totally empty calls,
# i.e. request == None and no flattened fields passed, work.
@pytest.mark.asyncio
async def test_delete_model_monitor_empty_call_grpc_asyncio():
    client = ModelMonitoringServiceAsyncClient(
        credentials=async_anonymous_credentials(),
        transport="grpc_asyncio",
    )

    # Mock the actual call, and fake the request.
    with mock.patch.object(
            type(client.transport.delete_model_monitor),
            '__call__') as call:
        # Designate an appropriate return value for the call.
        call.return_value = grpc_helpers_async.FakeUnaryUnaryCall(
            operations_pb2.Operation(name='operations/spam')
        )
        await client.delete_model_monitor(request=None)

        # Establish that the underlying stub method was called.
        call.assert_called()
        _, args, _ = call.mock_calls[0]
        request_msg = model_monitoring_service.DeleteModelMonitorRequest()

        assert args[0] == request_msg


# This test is a coverage failsafe to make sure that totally empty calls,
# i.e. request == None and no flattened fields passed, work.
@pytest.mark.asyncio
async def test_create_model_monitoring_job_empty_call_grpc_asyncio():
    client = ModelMonitoringServiceAsyncClient(
        credentials=async_anonymous_credentials(),
        transport="grpc_asyncio",
    )

    # Mock the actual call, and fake the request.
    with mock.patch.object(
            type(client.transport.create_model_monitoring_job),
            '__call__') as call:
        # Designate an appropriate return value for the call.
        call.return_value = grpc_helpers_async.FakeUnaryUnaryCall(gca_model_monitoring_job.ModelMonitoringJob(
            name='name_value',
            display_name='display_name_value',
            state=job_state.JobState.JOB_STATE_QUEUED,
            schedule='schedule_value',
        ))
        await client.create_model_monitoring_job(request=None)

        # Establish that the underlying stub method was called.
        call.assert_called()
        _, args, _ = call.mock_calls[0]
        request_msg = model_monitoring_service.CreateModelMonitoringJobRequest()

        assert args[0] == request_msg


# This test is a coverage failsafe to make sure that totally empty calls,
# i.e. request == None and no flattened fields passed, work.
@pytest.mark.asyncio
async def test_get_model_monitoring_job_empty_call_grpc_asyncio():
    client = ModelMonitoringServiceAsyncClient(
        credentials=async_anonymous_credentials(),
        transport="grpc_asyncio",
    )

    # Mock the actual call, and fake the request.
    with mock.patch.object(
            type(client.transport.get_model_monitoring_job),
            '__call__') as call:
        # Designate an appropriate return value for the call.
        call.return_value = grpc_helpers_async.FakeUnaryUnaryCall(model_monitoring_job.ModelMonitoringJob(
            name='name_value',
            display_name='display_name_value',
            state=job_state.JobState.JOB_STATE_QUEUED,
            schedule='schedule_value',
        ))
        await client.get_model_monitoring_job(request=None)

        # Establish that the underlying stub method was called.
        call.assert_called()
        _, args, _ = call.mock_calls[0]
        request_msg = model_monitoring_service.GetModelMonitoringJobRequest()

        assert args[0] == request_msg


# This test is a coverage failsafe to make sure that totally empty calls,
# i.e. request == None and no flattened fields passed, work.
@pytest.mark.asyncio
async def test_list_model_monitoring_jobs_empty_call_grpc_asyncio():
    client = ModelMonitoringServiceAsyncClient(
        credentials=async_anonymous_credentials(),
        transport="grpc_asyncio",
    )

    # Mock the actual call, and fake the request.
    with mock.patch.object(
            type(client.transport.list_model_monitoring_jobs),
            '__call__') as call:
        # Designate an appropriate return value for the call.
        call.return_value = grpc_helpers_async.FakeUnaryUnaryCall(model_monitoring_service.ListModelMonitoringJobsResponse(
            next_page_token='next_page_token_value',
        ))
        await client.list_model_monitoring_jobs(request=None)

        # Establish that the underlying stub method was called.
        call.assert_called()
        _, args, _ = call.mock_calls[0]
        request_msg = model_monitoring_service.ListModelMonitoringJobsRequest()

        assert args[0] == request_msg


# This test is a coverage failsafe to make sure that totally empty calls,
# i.e. request == None and no flattened fields passed, work.
@pytest.mark.asyncio
async def test_delete_model_monitoring_job_empty_call_grpc_asyncio():
    client = ModelMonitoringServiceAsyncClient(
        credentials=async_anonymous_credentials(),
        transport="grpc_asyncio",
    )

    # Mock the actual call, and fake the request.
    with mock.patch.object(
            type(client.transport.delete_model_monitoring_job),
            '__call__') as call:
        # Designate an appropriate return value for the call.
        call.return_value = grpc_helpers_async.FakeUnaryUnaryCall(
            operations_pb2.Operation(name='operations/spam')
        )
        await client.delete_model_monitoring_job(request=None)

        # Establish that the underlying stub method was called.
        call.assert_called()
        _, args, _ = call.mock_calls[0]
        request_msg = model_monitoring_service.DeleteModelMonitoringJobRequest()

        assert args[0] == request_msg


# This test is a coverage failsafe to make sure that totally empty calls,
# i.e. request == None and no flattened fields passed, work.
@pytest.mark.asyncio
async def test_search_model_monitoring_stats_empty_call_grpc_asyncio():
    client = ModelMonitoringServiceAsyncClient(
        credentials=async_anonymous_credentials(),
        transport="grpc_asyncio",
    )

    # Mock the actual call, and fake the request.
    with mock.patch.object(
            type(client.transport.search_model_monitoring_stats),
            '__call__') as call:
        # Designate an appropriate return value for the call.
        call.return_value = grpc_helpers_async.FakeUnaryUnaryCall(model_monitoring_service.SearchModelMonitoringStatsResponse(
            next_page_token='next_page_token_value',
        ))
        await client.search_model_monitoring_stats(request=None)

        # Establish that the underlying stub method was called.
        call.assert_called()
        _, args, _ = call.mock_calls[0]
        request_msg = model_monitoring_service.SearchModelMonitoringStatsRequest()

        assert args[0] == request_msg


# This test is a coverage failsafe to make sure that totally empty calls,
# i.e. request == None and no flattened fields passed, work.
@pytest.mark.asyncio
async def test_search_model_monitoring_alerts_empty_call_grpc_asyncio():
    client = ModelMonitoringServiceAsyncClient(
        credentials=async_anonymous_credentials(),
        transport="grpc_asyncio",
    )

    # Mock the actual call, and fake the request.
    with mock.patch.object(
            type(client.transport.search_model_monitoring_alerts),
            '__call__') as call:
        # Designate an appropriate return value for the call.
        call.return_value = grpc_helpers_async.FakeUnaryUnaryCall(model_monitoring_service.SearchModelMonitoringAlertsResponse(
            total_number_alerts=2038,
            next_page_token='next_page_token_value',
        ))
        await client.search_model_monitoring_alerts(request=None)

        # Establish that the underlying stub method was called.
        call.assert_called()
        _, args, _ = call.mock_calls[0]
        request_msg = model_monitoring_service.SearchModelMonitoringAlertsRequest()

        assert args[0] == request_msg


def test_transport_kind_rest():
    transport = ModelMonitoringServiceClient.get_transport_class("rest")(
        credentials=ga_credentials.AnonymousCredentials()
    )
    assert transport.kind == "rest"


def test_create_model_monitor_rest_bad_request(request_type=model_monitoring_service.CreateModelMonitorRequest):
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport="rest"
    )
    # send a request that will satisfy transcoding
    request_init = {'parent': 'projects/sample1/locations/sample2'}
    request = request_type(**request_init)

    # Mock the http request call within the method and fake a BadRequest error.
    with mock.patch.object(Session, 'request') as req, pytest.raises(core_exceptions.BadRequest):
        # Wrap the value into a proper Response obj
        response_value = mock.Mock()
        json_return_value = ''
        response_value.json = mock.Mock(return_value={})
        response_value.status_code = 400
        response_value.request = mock.Mock()
        req.return_value = response_value
        client.create_model_monitor(request)


@pytest.mark.parametrize("request_type", [
  model_monitoring_service.CreateModelMonitorRequest,
  dict,
])
def test_create_model_monitor_rest_call_success(request_type):
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport="rest"
    )

    # send a request that will satisfy transcoding
    request_init = {'parent': 'projects/sample1/locations/sample2'}
    request_init["model_monitor"] = {'tabular_objective': {'feature_drift_spec': {'features': ['features_value1', 'features_value2'], 'categorical_metric_type': 'categorical_metric_type_value', 'numeric_metric_type': 'numeric_metric_type_value', 'default_categorical_alert_condition': {'threshold': 0.973}, 'default_numeric_alert_condition': {}, 'feature_alert_conditions': {}}, 'prediction_output_drift_spec': {}, 'feature_attribution_spec': {'features': ['features_value1', 'features_value2'], 'default_alert_condition': {}, 'feature_alert_conditions': {}, 'batch_explanation_dedicated_resources': {'machine_spec': {'machine_type': 'machine_type_value', 'accelerator_type': 1, 'accelerator_count': 1805, 'tpu_topology': 'tpu_topology_value', 'reservation_affinity': {'reservation_affinity_type': 1, 'key': 'key_value', 'values': ['values_value1', 'values_value2']}}, 'starting_replica_count': 2355, 'max_replica_count': 1805}}}, 'name': 'name_value', 'display_name': 'display_name_value', 'model_monitoring_target': {'vertex_model': {'model': 'model_value', 'model_version_id': 'model_version_id_value'}}, 'training_dataset': {'columnized_dataset': {'vertex_dataset': 'vertex_dataset_value', 'gcs_source': {'gcs_uri': 'gcs_uri_value', 'format_': 1}, 'bigquery_source': {'table_uri': 'table_uri_value', 'query': 'query_value'}, 'timestamp_field': 'timestamp_field_value'}, 'batch_prediction_output': {'batch_prediction_job': 'batch_prediction_job_value'}, 'vertex_endpoint_logs': {'endpoints': ['endpoints_value1', 'endpoints_value2']}, 'time_interval': {'start_time': {'seconds': 751, 'nanos': 543}, 'end_time': {}}, 'time_offset': {'offset': 'offset_value', 'window': 'window_value'}}, 'notification_spec': {'email_config': {'user_emails': ['user_emails_value1', 'user_emails_value2']}, 'enable_cloud_logging': True, 'notification_channel_configs': [{'notification_channel': 'notification_channel_value'}]}, 'output_spec': {'gcs_base_directory': {'output_uri_prefix': 'output_uri_prefix_value'}}, 'explanation_spec': {'parameters': {'sampled_shapley_attribution': {'path_count': 1077}, 'integrated_gradients_attribution': {'step_count': 1092, 'smooth_grad_config': {'noise_sigma': 0.11660000000000001, 'feature_noise_sigma': {'noise_sigma': [{'name': 'name_value', 'sigma': 0.529}]}, 'noisy_sample_count': 1947}, 'blur_baseline_config': {'max_blur_sigma': 0.1482}}, 'xrai_attribution': {'step_count': 1092, 'smooth_grad_config': {}, 'blur_baseline_config': {}}, 'examples': {'example_gcs_source': {'data_format': 1, 'gcs_source': {'uris': ['uris_value1', 'uris_value2']}}, 'nearest_neighbor_search_config': {'null_value': 0, 'number_value': 0.1285, 'string_value': 'string_value_value', 'bool_value': True, 'struct_value': {'fields': {}}, 'list_value': {'values': {}}}, 'presets': {'query': 1, 'modality': 1}, 'gcs_source': {}, 'neighbor_count': 1494}, 'top_k': 541, 'output_indices': {}}, 'metadata': {'inputs': {}, 'outputs': {}, 'feature_attributions_schema_uri': 'feature_attributions_schema_uri_value', 'latent_space_source': 'latent_space_source_value'}}, 'model_monitoring_schema': {'feature_fields': [{'name': 'name_value', 'data_type': 'data_type_value', 'repeated': True}], 'prediction_fields': {}, 'ground_truth_fields': {}}, 'create_time': {}, 'update_time': {}, 'satisfies_pzs': True, 'satisfies_pzi': True}
    # The version of a generated dependency at test runtime may differ from the version used during generation.
    # Delete any fields which are not present in the current runtime dependency
    # See https://github.com/googleapis/gapic-generator-python/issues/1748

    # Determine if the message type is proto-plus or protobuf
    test_field = model_monitoring_service.CreateModelMonitorRequest.meta.fields["model_monitor"]

    def get_message_fields(field):
        # Given a field which is a message (composite type), return a list with
        # all the fields of the message.
        # If the field is not a composite type, return an empty list.
        message_fields = []

        if hasattr(field, "message") and field.message:
            is_field_type_proto_plus_type = not hasattr(field.message, "DESCRIPTOR")

            if is_field_type_proto_plus_type:
                message_fields = field.message.meta.fields.values()
            # Add `# pragma: NO COVER` because there may not be any `*_pb2` field types
            else: # pragma: NO COVER
                message_fields = field.message.DESCRIPTOR.fields
        return message_fields

    runtime_nested_fields = [
        (field.name, nested_field.name)
        for field in get_message_fields(test_field)
        for nested_field in get_message_fields(field)
    ]

    subfields_not_in_runtime = []

    # For each item in the sample request, create a list of sub fields which are not present at runtime
    # Add `# pragma: NO COVER` because this test code will not run if all subfields are present at runtime
    for field, value in request_init["model_monitor"].items(): # pragma: NO COVER
        result = None
        is_repeated = False
        # For repeated fields
        if isinstance(value, list) and len(value):
            is_repeated = True
            result = value[0]
        # For fields where the type is another message
        if isinstance(value, dict):
            result = value

        if result and hasattr(result, "keys"):
            for subfield in result.keys():
                if (field, subfield) not in runtime_nested_fields:
                    subfields_not_in_runtime.append(
                        {"field": field, "subfield": subfield, "is_repeated": is_repeated}
                    )

    # Remove fields from the sample request which are not present in the runtime version of the dependency
    # Add `# pragma: NO COVER` because this test code will not run if all subfields are present at runtime
    for subfield_to_delete in subfields_not_in_runtime: # pragma: NO COVER
        field = subfield_to_delete.get("field")
        field_repeated = subfield_to_delete.get("is_repeated")
        subfield = subfield_to_delete.get("subfield")
        if subfield:
            if field_repeated:
                for i in range(0, len(request_init["model_monitor"][field])):
                    del request_init["model_monitor"][field][i][subfield]
            else:
                del request_init["model_monitor"][field][subfield]
    request = request_type(**request_init)

    # Mock the http request call within the method and fake a response.
    with mock.patch.object(type(client.transport._session), 'request') as req:
        # Designate an appropriate value for the returned response.
        return_value = operations_pb2.Operation(name='operations/spam')

        # Wrap the value into a proper Response obj
        response_value = mock.Mock()
        response_value.status_code = 200
        json_return_value = json_format.MessageToJson(return_value)
        response_value.content = json_return_value.encode('UTF-8')
        req.return_value = response_value
        response = client.create_model_monitor(request)

    # Establish that the response is the type that we expect.
    json_return_value = json_format.MessageToJson(return_value)


@pytest.mark.parametrize("null_interceptor", [True, False])
def test_create_model_monitor_rest_interceptors(null_interceptor):
    transport = transports.ModelMonitoringServiceRestTransport(
        credentials=ga_credentials.AnonymousCredentials(),
        interceptor=None if null_interceptor else transports.ModelMonitoringServiceRestInterceptor(),
        )
    client = ModelMonitoringServiceClient(transport=transport)

    with mock.patch.object(type(client.transport._session), "request") as req, \
        mock.patch.object(path_template, "transcode")  as transcode, \
        mock.patch.object(operation.Operation, "_set_result_from_operation"), \
        mock.patch.object(transports.ModelMonitoringServiceRestInterceptor, "post_create_model_monitor") as post, \
        mock.patch.object(transports.ModelMonitoringServiceRestInterceptor, "pre_create_model_monitor") as pre:
        pre.assert_not_called()
        post.assert_not_called()
        pb_message = model_monitoring_service.CreateModelMonitorRequest.pb(model_monitoring_service.CreateModelMonitorRequest())
        transcode.return_value = {
            "method": "post",
            "uri": "my_uri",
            "body": pb_message,
            "query_params": pb_message,
        }

        req.return_value = mock.Mock()
        req.return_value.status_code = 200
        return_value = json_format.MessageToJson(operations_pb2.Operation())
        req.return_value.content = return_value

        request = model_monitoring_service.CreateModelMonitorRequest()
        metadata =[
            ("key", "val"),
            ("cephalopod", "squid"),
        ]
        pre.return_value = request, metadata
        post.return_value = operations_pb2.Operation()

        client.create_model_monitor(request, metadata=[("key", "val"), ("cephalopod", "squid"),])

        pre.assert_called_once()
        post.assert_called_once()


def test_update_model_monitor_rest_bad_request(request_type=model_monitoring_service.UpdateModelMonitorRequest):
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport="rest"
    )
    # send a request that will satisfy transcoding
    request_init = {'model_monitor': {'name': 'projects/sample1/locations/sample2/modelMonitors/sample3'}}
    request = request_type(**request_init)

    # Mock the http request call within the method and fake a BadRequest error.
    with mock.patch.object(Session, 'request') as req, pytest.raises(core_exceptions.BadRequest):
        # Wrap the value into a proper Response obj
        response_value = mock.Mock()
        json_return_value = ''
        response_value.json = mock.Mock(return_value={})
        response_value.status_code = 400
        response_value.request = mock.Mock()
        req.return_value = response_value
        client.update_model_monitor(request)


@pytest.mark.parametrize("request_type", [
  model_monitoring_service.UpdateModelMonitorRequest,
  dict,
])
def test_update_model_monitor_rest_call_success(request_type):
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport="rest"
    )

    # send a request that will satisfy transcoding
    request_init = {'model_monitor': {'name': 'projects/sample1/locations/sample2/modelMonitors/sample3'}}
    request_init["model_monitor"] = {'tabular_objective': {'feature_drift_spec': {'features': ['features_value1', 'features_value2'], 'categorical_metric_type': 'categorical_metric_type_value', 'numeric_metric_type': 'numeric_metric_type_value', 'default_categorical_alert_condition': {'threshold': 0.973}, 'default_numeric_alert_condition': {}, 'feature_alert_conditions': {}}, 'prediction_output_drift_spec': {}, 'feature_attribution_spec': {'features': ['features_value1', 'features_value2'], 'default_alert_condition': {}, 'feature_alert_conditions': {}, 'batch_explanation_dedicated_resources': {'machine_spec': {'machine_type': 'machine_type_value', 'accelerator_type': 1, 'accelerator_count': 1805, 'tpu_topology': 'tpu_topology_value', 'reservation_affinity': {'reservation_affinity_type': 1, 'key': 'key_value', 'values': ['values_value1', 'values_value2']}}, 'starting_replica_count': 2355, 'max_replica_count': 1805}}}, 'name': 'projects/sample1/locations/sample2/modelMonitors/sample3', 'display_name': 'display_name_value', 'model_monitoring_target': {'vertex_model': {'model': 'model_value', 'model_version_id': 'model_version_id_value'}}, 'training_dataset': {'columnized_dataset': {'vertex_dataset': 'vertex_dataset_value', 'gcs_source': {'gcs_uri': 'gcs_uri_value', 'format_': 1}, 'bigquery_source': {'table_uri': 'table_uri_value', 'query': 'query_value'}, 'timestamp_field': 'timestamp_field_value'}, 'batch_prediction_output': {'batch_prediction_job': 'batch_prediction_job_value'}, 'vertex_endpoint_logs': {'endpoints': ['endpoints_value1', 'endpoints_value2']}, 'time_interval': {'start_time': {'seconds': 751, 'nanos': 543}, 'end_time': {}}, 'time_offset': {'offset': 'offset_value', 'window': 'window_value'}}, 'notification_spec': {'email_config': {'user_emails': ['user_emails_value1', 'user_emails_value2']}, 'enable_cloud_logging': True, 'notification_channel_configs': [{'notification_channel': 'notification_channel_value'}]}, 'output_spec': {'gcs_base_directory': {'output_uri_prefix': 'output_uri_prefix_value'}}, 'explanation_spec': {'parameters': {'sampled_shapley_attribution': {'path_count': 1077}, 'integrated_gradients_attribution': {'step_count': 1092, 'smooth_grad_config': {'noise_sigma': 0.11660000000000001, 'feature_noise_sigma': {'noise_sigma': [{'name': 'name_value', 'sigma': 0.529}]}, 'noisy_sample_count': 1947}, 'blur_baseline_config': {'max_blur_sigma': 0.1482}}, 'xrai_attribution': {'step_count': 1092, 'smooth_grad_config': {}, 'blur_baseline_config': {}}, 'examples': {'example_gcs_source': {'data_format': 1, 'gcs_source': {'uris': ['uris_value1', 'uris_value2']}}, 'nearest_neighbor_search_config': {'null_value': 0, 'number_value': 0.1285, 'string_value': 'string_value_value', 'bool_value': True, 'struct_value': {'fields': {}}, 'list_value': {'values': {}}}, 'presets': {'query': 1, 'modality': 1}, 'gcs_source': {}, 'neighbor_count': 1494}, 'top_k': 541, 'output_indices': {}}, 'metadata': {'inputs': {}, 'outputs': {}, 'feature_attributions_schema_uri': 'feature_attributions_schema_uri_value', 'latent_space_source': 'latent_space_source_value'}}, 'model_monitoring_schema': {'feature_fields': [{'name': 'name_value', 'data_type': 'data_type_value', 'repeated': True}], 'prediction_fields': {}, 'ground_truth_fields': {}}, 'create_time': {}, 'update_time': {}, 'satisfies_pzs': True, 'satisfies_pzi': True}
    # The version of a generated dependency at test runtime may differ from the version used during generation.
    # Delete any fields which are not present in the current runtime dependency
    # See https://github.com/googleapis/gapic-generator-python/issues/1748

    # Determine if the message type is proto-plus or protobuf
    test_field = model_monitoring_service.UpdateModelMonitorRequest.meta.fields["model_monitor"]

    def get_message_fields(field):
        # Given a field which is a message (composite type), return a list with
        # all the fields of the message.
        # If the field is not a composite type, return an empty list.
        message_fields = []

        if hasattr(field, "message") and field.message:
            is_field_type_proto_plus_type = not hasattr(field.message, "DESCRIPTOR")

            if is_field_type_proto_plus_type:
                message_fields = field.message.meta.fields.values()
            # Add `# pragma: NO COVER` because there may not be any `*_pb2` field types
            else: # pragma: NO COVER
                message_fields = field.message.DESCRIPTOR.fields
        return message_fields

    runtime_nested_fields = [
        (field.name, nested_field.name)
        for field in get_message_fields(test_field)
        for nested_field in get_message_fields(field)
    ]

    subfields_not_in_runtime = []

    # For each item in the sample request, create a list of sub fields which are not present at runtime
    # Add `# pragma: NO COVER` because this test code will not run if all subfields are present at runtime
    for field, value in request_init["model_monitor"].items(): # pragma: NO COVER
        result = None
        is_repeated = False
        # For repeated fields
        if isinstance(value, list) and len(value):
            is_repeated = True
            result = value[0]
        # For fields where the type is another message
        if isinstance(value, dict):
            result = value

        if result and hasattr(result, "keys"):
            for subfield in result.keys():
                if (field, subfield) not in runtime_nested_fields:
                    subfields_not_in_runtime.append(
                        {"field": field, "subfield": subfield, "is_repeated": is_repeated}
                    )

    # Remove fields from the sample request which are not present in the runtime version of the dependency
    # Add `# pragma: NO COVER` because this test code will not run if all subfields are present at runtime
    for subfield_to_delete in subfields_not_in_runtime: # pragma: NO COVER
        field = subfield_to_delete.get("field")
        field_repeated = subfield_to_delete.get("is_repeated")
        subfield = subfield_to_delete.get("subfield")
        if subfield:
            if field_repeated:
                for i in range(0, len(request_init["model_monitor"][field])):
                    del request_init["model_monitor"][field][i][subfield]
            else:
                del request_init["model_monitor"][field][subfield]
    request = request_type(**request_init)

    # Mock the http request call within the method and fake a response.
    with mock.patch.object(type(client.transport._session), 'request') as req:
        # Designate an appropriate value for the returned response.
        return_value = operations_pb2.Operation(name='operations/spam')

        # Wrap the value into a proper Response obj
        response_value = mock.Mock()
        response_value.status_code = 200
        json_return_value = json_format.MessageToJson(return_value)
        response_value.content = json_return_value.encode('UTF-8')
        req.return_value = response_value
        response = client.update_model_monitor(request)

    # Establish that the response is the type that we expect.
    json_return_value = json_format.MessageToJson(return_value)


@pytest.mark.parametrize("null_interceptor", [True, False])
def test_update_model_monitor_rest_interceptors(null_interceptor):
    transport = transports.ModelMonitoringServiceRestTransport(
        credentials=ga_credentials.AnonymousCredentials(),
        interceptor=None if null_interceptor else transports.ModelMonitoringServiceRestInterceptor(),
        )
    client = ModelMonitoringServiceClient(transport=transport)

    with mock.patch.object(type(client.transport._session), "request") as req, \
        mock.patch.object(path_template, "transcode")  as transcode, \
        mock.patch.object(operation.Operation, "_set_result_from_operation"), \
        mock.patch.object(transports.ModelMonitoringServiceRestInterceptor, "post_update_model_monitor") as post, \
        mock.patch.object(transports.ModelMonitoringServiceRestInterceptor, "pre_update_model_monitor") as pre:
        pre.assert_not_called()
        post.assert_not_called()
        pb_message = model_monitoring_service.UpdateModelMonitorRequest.pb(model_monitoring_service.UpdateModelMonitorRequest())
        transcode.return_value = {
            "method": "post",
            "uri": "my_uri",
            "body": pb_message,
            "query_params": pb_message,
        }

        req.return_value = mock.Mock()
        req.return_value.status_code = 200
        return_value = json_format.MessageToJson(operations_pb2.Operation())
        req.return_value.content = return_value

        request = model_monitoring_service.UpdateModelMonitorRequest()
        metadata =[
            ("key", "val"),
            ("cephalopod", "squid"),
        ]
        pre.return_value = request, metadata
        post.return_value = operations_pb2.Operation()

        client.update_model_monitor(request, metadata=[("key", "val"), ("cephalopod", "squid"),])

        pre.assert_called_once()
        post.assert_called_once()


def test_get_model_monitor_rest_bad_request(request_type=model_monitoring_service.GetModelMonitorRequest):
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport="rest"
    )
    # send a request that will satisfy transcoding
    request_init = {'name': 'projects/sample1/locations/sample2/modelMonitors/sample3'}
    request = request_type(**request_init)

    # Mock the http request call within the method and fake a BadRequest error.
    with mock.patch.object(Session, 'request') as req, pytest.raises(core_exceptions.BadRequest):
        # Wrap the value into a proper Response obj
        response_value = mock.Mock()
        json_return_value = ''
        response_value.json = mock.Mock(return_value={})
        response_value.status_code = 400
        response_value.request = mock.Mock()
        req.return_value = response_value
        client.get_model_monitor(request)


@pytest.mark.parametrize("request_type", [
  model_monitoring_service.GetModelMonitorRequest,
  dict,
])
def test_get_model_monitor_rest_call_success(request_type):
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport="rest"
    )

    # send a request that will satisfy transcoding
    request_init = {'name': 'projects/sample1/locations/sample2/modelMonitors/sample3'}
    request = request_type(**request_init)

    # Mock the http request call within the method and fake a response.
    with mock.patch.object(type(client.transport._session), 'request') as req:
        # Designate an appropriate value for the returned response.
        return_value = model_monitor.ModelMonitor(
              name='name_value',
              display_name='display_name_value',
              satisfies_pzs=True,
              satisfies_pzi=True,
        )

        # Wrap the value into a proper Response obj
        response_value = mock.Mock()
        response_value.status_code = 200

        # Convert return value to protobuf type
        return_value = model_monitor.ModelMonitor.pb(return_value)
        json_return_value = json_format.MessageToJson(return_value)
        response_value.content = json_return_value.encode('UTF-8')
        req.return_value = response_value
        response = client.get_model_monitor(request)

    # Establish that the response is the type that we expect.
    assert isinstance(response, model_monitor.ModelMonitor)
    assert response.name == 'name_value'
    assert response.display_name == 'display_name_value'
    assert response.satisfies_pzs is True
    assert response.satisfies_pzi is True


@pytest.mark.parametrize("null_interceptor", [True, False])
def test_get_model_monitor_rest_interceptors(null_interceptor):
    transport = transports.ModelMonitoringServiceRestTransport(
        credentials=ga_credentials.AnonymousCredentials(),
        interceptor=None if null_interceptor else transports.ModelMonitoringServiceRestInterceptor(),
        )
    client = ModelMonitoringServiceClient(transport=transport)

    with mock.patch.object(type(client.transport._session), "request") as req, \
        mock.patch.object(path_template, "transcode")  as transcode, \
        mock.patch.object(transports.ModelMonitoringServiceRestInterceptor, "post_get_model_monitor") as post, \
        mock.patch.object(transports.ModelMonitoringServiceRestInterceptor, "pre_get_model_monitor") as pre:
        pre.assert_not_called()
        post.assert_not_called()
        pb_message = model_monitoring_service.GetModelMonitorRequest.pb(model_monitoring_service.GetModelMonitorRequest())
        transcode.return_value = {
            "method": "post",
            "uri": "my_uri",
            "body": pb_message,
            "query_params": pb_message,
        }

        req.return_value = mock.Mock()
        req.return_value.status_code = 200
        return_value = model_monitor.ModelMonitor.to_json(model_monitor.ModelMonitor())
        req.return_value.content = return_value

        request = model_monitoring_service.GetModelMonitorRequest()
        metadata =[
            ("key", "val"),
            ("cephalopod", "squid"),
        ]
        pre.return_value = request, metadata
        post.return_value = model_monitor.ModelMonitor()

        client.get_model_monitor(request, metadata=[("key", "val"), ("cephalopod", "squid"),])

        pre.assert_called_once()
        post.assert_called_once()


def test_list_model_monitors_rest_bad_request(request_type=model_monitoring_service.ListModelMonitorsRequest):
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport="rest"
    )
    # send a request that will satisfy transcoding
    request_init = {'parent': 'projects/sample1/locations/sample2'}
    request = request_type(**request_init)

    # Mock the http request call within the method and fake a BadRequest error.
    with mock.patch.object(Session, 'request') as req, pytest.raises(core_exceptions.BadRequest):
        # Wrap the value into a proper Response obj
        response_value = mock.Mock()
        json_return_value = ''
        response_value.json = mock.Mock(return_value={})
        response_value.status_code = 400
        response_value.request = mock.Mock()
        req.return_value = response_value
        client.list_model_monitors(request)


@pytest.mark.parametrize("request_type", [
  model_monitoring_service.ListModelMonitorsRequest,
  dict,
])
def test_list_model_monitors_rest_call_success(request_type):
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport="rest"
    )

    # send a request that will satisfy transcoding
    request_init = {'parent': 'projects/sample1/locations/sample2'}
    request = request_type(**request_init)

    # Mock the http request call within the method and fake a response.
    with mock.patch.object(type(client.transport._session), 'request') as req:
        # Designate an appropriate value for the returned response.
        return_value = model_monitoring_service.ListModelMonitorsResponse(
              next_page_token='next_page_token_value',
        )

        # Wrap the value into a proper Response obj
        response_value = mock.Mock()
        response_value.status_code = 200

        # Convert return value to protobuf type
        return_value = model_monitoring_service.ListModelMonitorsResponse.pb(return_value)
        json_return_value = json_format.MessageToJson(return_value)
        response_value.content = json_return_value.encode('UTF-8')
        req.return_value = response_value
        response = client.list_model_monitors(request)

    # Establish that the response is the type that we expect.
    assert isinstance(response, pagers.ListModelMonitorsPager)
    assert response.next_page_token == 'next_page_token_value'


@pytest.mark.parametrize("null_interceptor", [True, False])
def test_list_model_monitors_rest_interceptors(null_interceptor):
    transport = transports.ModelMonitoringServiceRestTransport(
        credentials=ga_credentials.AnonymousCredentials(),
        interceptor=None if null_interceptor else transports.ModelMonitoringServiceRestInterceptor(),
        )
    client = ModelMonitoringServiceClient(transport=transport)

    with mock.patch.object(type(client.transport._session), "request") as req, \
        mock.patch.object(path_template, "transcode")  as transcode, \
        mock.patch.object(transports.ModelMonitoringServiceRestInterceptor, "post_list_model_monitors") as post, \
        mock.patch.object(transports.ModelMonitoringServiceRestInterceptor, "pre_list_model_monitors") as pre:
        pre.assert_not_called()
        post.assert_not_called()
        pb_message = model_monitoring_service.ListModelMonitorsRequest.pb(model_monitoring_service.ListModelMonitorsRequest())
        transcode.return_value = {
            "method": "post",
            "uri": "my_uri",
            "body": pb_message,
            "query_params": pb_message,
        }

        req.return_value = mock.Mock()
        req.return_value.status_code = 200
        return_value = model_monitoring_service.ListModelMonitorsResponse.to_json(model_monitoring_service.ListModelMonitorsResponse())
        req.return_value.content = return_value

        request = model_monitoring_service.ListModelMonitorsRequest()
        metadata =[
            ("key", "val"),
            ("cephalopod", "squid"),
        ]
        pre.return_value = request, metadata
        post.return_value = model_monitoring_service.ListModelMonitorsResponse()

        client.list_model_monitors(request, metadata=[("key", "val"), ("cephalopod", "squid"),])

        pre.assert_called_once()
        post.assert_called_once()


def test_delete_model_monitor_rest_bad_request(request_type=model_monitoring_service.DeleteModelMonitorRequest):
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport="rest"
    )
    # send a request that will satisfy transcoding
    request_init = {'name': 'projects/sample1/locations/sample2/modelMonitors/sample3'}
    request = request_type(**request_init)

    # Mock the http request call within the method and fake a BadRequest error.
    with mock.patch.object(Session, 'request') as req, pytest.raises(core_exceptions.BadRequest):
        # Wrap the value into a proper Response obj
        response_value = mock.Mock()
        json_return_value = ''
        response_value.json = mock.Mock(return_value={})
        response_value.status_code = 400
        response_value.request = mock.Mock()
        req.return_value = response_value
        client.delete_model_monitor(request)


@pytest.mark.parametrize("request_type", [
  model_monitoring_service.DeleteModelMonitorRequest,
  dict,
])
def test_delete_model_monitor_rest_call_success(request_type):
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport="rest"
    )

    # send a request that will satisfy transcoding
    request_init = {'name': 'projects/sample1/locations/sample2/modelMonitors/sample3'}
    request = request_type(**request_init)

    # Mock the http request call within the method and fake a response.
    with mock.patch.object(type(client.transport._session), 'request') as req:
        # Designate an appropriate value for the returned response.
        return_value = operations_pb2.Operation(name='operations/spam')

        # Wrap the value into a proper Response obj
        response_value = mock.Mock()
        response_value.status_code = 200
        json_return_value = json_format.MessageToJson(return_value)
        response_value.content = json_return_value.encode('UTF-8')
        req.return_value = response_value
        response = client.delete_model_monitor(request)

    # Establish that the response is the type that we expect.
    json_return_value = json_format.MessageToJson(return_value)


@pytest.mark.parametrize("null_interceptor", [True, False])
def test_delete_model_monitor_rest_interceptors(null_interceptor):
    transport = transports.ModelMonitoringServiceRestTransport(
        credentials=ga_credentials.AnonymousCredentials(),
        interceptor=None if null_interceptor else transports.ModelMonitoringServiceRestInterceptor(),
        )
    client = ModelMonitoringServiceClient(transport=transport)

    with mock.patch.object(type(client.transport._session), "request") as req, \
        mock.patch.object(path_template, "transcode")  as transcode, \
        mock.patch.object(operation.Operation, "_set_result_from_operation"), \
        mock.patch.object(transports.ModelMonitoringServiceRestInterceptor, "post_delete_model_monitor") as post, \
        mock.patch.object(transports.ModelMonitoringServiceRestInterceptor, "pre_delete_model_monitor") as pre:
        pre.assert_not_called()
        post.assert_not_called()
        pb_message = model_monitoring_service.DeleteModelMonitorRequest.pb(model_monitoring_service.DeleteModelMonitorRequest())
        transcode.return_value = {
            "method": "post",
            "uri": "my_uri",
            "body": pb_message,
            "query_params": pb_message,
        }

        req.return_value = mock.Mock()
        req.return_value.status_code = 200
        return_value = json_format.MessageToJson(operations_pb2.Operation())
        req.return_value.content = return_value

        request = model_monitoring_service.DeleteModelMonitorRequest()
        metadata =[
            ("key", "val"),
            ("cephalopod", "squid"),
        ]
        pre.return_value = request, metadata
        post.return_value = operations_pb2.Operation()

        client.delete_model_monitor(request, metadata=[("key", "val"), ("cephalopod", "squid"),])

        pre.assert_called_once()
        post.assert_called_once()


def test_create_model_monitoring_job_rest_bad_request(request_type=model_monitoring_service.CreateModelMonitoringJobRequest):
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport="rest"
    )
    # send a request that will satisfy transcoding
    request_init = {'parent': 'projects/sample1/locations/sample2/modelMonitors/sample3'}
    request = request_type(**request_init)

    # Mock the http request call within the method and fake a BadRequest error.
    with mock.patch.object(Session, 'request') as req, pytest.raises(core_exceptions.BadRequest):
        # Wrap the value into a proper Response obj
        response_value = mock.Mock()
        json_return_value = ''
        response_value.json = mock.Mock(return_value={})
        response_value.status_code = 400
        response_value.request = mock.Mock()
        req.return_value = response_value
        client.create_model_monitoring_job(request)


@pytest.mark.parametrize("request_type", [
  model_monitoring_service.CreateModelMonitoringJobRequest,
  dict,
])
def test_create_model_monitoring_job_rest_call_success(request_type):
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport="rest"
    )

    # send a request that will satisfy transcoding
    request_init = {'parent': 'projects/sample1/locations/sample2/modelMonitors/sample3'}
    request_init["model_monitoring_job"] = {'name': 'name_value', 'display_name': 'display_name_value', 'model_monitoring_spec': {'objective_spec': {'tabular_objective': {'feature_drift_spec': {'features': ['features_value1', 'features_value2'], 'categorical_metric_type': 'categorical_metric_type_value', 'numeric_metric_type': 'numeric_metric_type_value', 'default_categorical_alert_condition': {'threshold': 0.973}, 'default_numeric_alert_condition': {}, 'feature_alert_conditions': {}}, 'prediction_output_drift_spec': {}, 'feature_attribution_spec': {'features': ['features_value1', 'features_value2'], 'default_alert_condition': {}, 'feature_alert_conditions': {}, 'batch_explanation_dedicated_resources': {'machine_spec': {'machine_type': 'machine_type_value', 'accelerator_type': 1, 'accelerator_count': 1805, 'tpu_topology': 'tpu_topology_value', 'reservation_affinity': {'reservation_affinity_type': 1, 'key': 'key_value', 'values': ['values_value1', 'values_value2']}}, 'starting_replica_count': 2355, 'max_replica_count': 1805}}}, 'explanation_spec': {'parameters': {'sampled_shapley_attribution': {'path_count': 1077}, 'integrated_gradients_attribution': {'step_count': 1092, 'smooth_grad_config': {'noise_sigma': 0.11660000000000001, 'feature_noise_sigma': {'noise_sigma': [{'name': 'name_value', 'sigma': 0.529}]}, 'noisy_sample_count': 1947}, 'blur_baseline_config': {'max_blur_sigma': 0.1482}}, 'xrai_attribution': {'step_count': 1092, 'smooth_grad_config': {}, 'blur_baseline_config': {}}, 'examples': {'example_gcs_source': {'data_format': 1, 'gcs_source': {'uris': ['uris_value1', 'uris_value2']}}, 'nearest_neighbor_search_config': {'null_value': 0, 'number_value': 0.1285, 'string_value': 'string_value_value', 'bool_value': True, 'struct_value': {'fields': {}}, 'list_value': {'values': {}}}, 'presets': {'query': 1, 'modality': 1}, 'gcs_source': {}, 'neighbor_count': 1494}, 'top_k': 541, 'output_indices': {}}, 'metadata': {'inputs': {}, 'outputs': {}, 'feature_attributions_schema_uri': 'feature_attributions_schema_uri_value', 'latent_space_source': 'latent_space_source_value'}}, 'baseline_dataset': {'columnized_dataset': {'vertex_dataset': 'vertex_dataset_value', 'gcs_source': {'gcs_uri': 'gcs_uri_value', 'format_': 1}, 'bigquery_source': {'table_uri': 'table_uri_value', 'query': 'query_value'}, 'timestamp_field': 'timestamp_field_value'}, 'batch_prediction_output': {'batch_prediction_job': 'batch_prediction_job_value'}, 'vertex_endpoint_logs': {'endpoints': ['endpoints_value1', 'endpoints_value2']}, 'time_interval': {'start_time': {'seconds': 751, 'nanos': 543}, 'end_time': {}}, 'time_offset': {'offset': 'offset_value', 'window': 'window_value'}}, 'target_dataset': {}}, 'notification_spec': {'email_config': {'user_emails': ['user_emails_value1', 'user_emails_value2']}, 'enable_cloud_logging': True, 'notification_channel_configs': [{'notification_channel': 'notification_channel_value'}]}, 'output_spec': {'gcs_base_directory': {'output_uri_prefix': 'output_uri_prefix_value'}}}, 'create_time': {}, 'update_time': {}, 'state': 1, 'schedule': 'schedule_value', 'job_execution_detail': {'baseline_datasets': [{'location': 'location_value', 'time_range': {}}], 'target_datasets': {}, 'objective_status': {}, 'error': {'code': 411, 'message': 'message_value', 'details': [{'type_url': 'type.googleapis.com/google.protobuf.Duration', 'value': b'\x08\x0c\x10\xdb\x07'}]}}, 'schedule_time': {}}
    # The version of a generated dependency at test runtime may differ from the version used during generation.
    # Delete any fields which are not present in the current runtime dependency
    # See https://github.com/googleapis/gapic-generator-python/issues/1748

    # Determine if the message type is proto-plus or protobuf
    test_field = model_monitoring_service.CreateModelMonitoringJobRequest.meta.fields["model_monitoring_job"]

    def get_message_fields(field):
        # Given a field which is a message (composite type), return a list with
        # all the fields of the message.
        # If the field is not a composite type, return an empty list.
        message_fields = []

        if hasattr(field, "message") and field.message:
            is_field_type_proto_plus_type = not hasattr(field.message, "DESCRIPTOR")

            if is_field_type_proto_plus_type:
                message_fields = field.message.meta.fields.values()
            # Add `# pragma: NO COVER` because there may not be any `*_pb2` field types
            else: # pragma: NO COVER
                message_fields = field.message.DESCRIPTOR.fields
        return message_fields

    runtime_nested_fields = [
        (field.name, nested_field.name)
        for field in get_message_fields(test_field)
        for nested_field in get_message_fields(field)
    ]

    subfields_not_in_runtime = []

    # For each item in the sample request, create a list of sub fields which are not present at runtime
    # Add `# pragma: NO COVER` because this test code will not run if all subfields are present at runtime
    for field, value in request_init["model_monitoring_job"].items(): # pragma: NO COVER
        result = None
        is_repeated = False
        # For repeated fields
        if isinstance(value, list) and len(value):
            is_repeated = True
            result = value[0]
        # For fields where the type is another message
        if isinstance(value, dict):
            result = value

        if result and hasattr(result, "keys"):
            for subfield in result.keys():
                if (field, subfield) not in runtime_nested_fields:
                    subfields_not_in_runtime.append(
                        {"field": field, "subfield": subfield, "is_repeated": is_repeated}
                    )

    # Remove fields from the sample request which are not present in the runtime version of the dependency
    # Add `# pragma: NO COVER` because this test code will not run if all subfields are present at runtime
    for subfield_to_delete in subfields_not_in_runtime: # pragma: NO COVER
        field = subfield_to_delete.get("field")
        field_repeated = subfield_to_delete.get("is_repeated")
        subfield = subfield_to_delete.get("subfield")
        if subfield:
            if field_repeated:
                for i in range(0, len(request_init["model_monitoring_job"][field])):
                    del request_init["model_monitoring_job"][field][i][subfield]
            else:
                del request_init["model_monitoring_job"][field][subfield]
    request = request_type(**request_init)

    # Mock the http request call within the method and fake a response.
    with mock.patch.object(type(client.transport._session), 'request') as req:
        # Designate an appropriate value for the returned response.
        return_value = gca_model_monitoring_job.ModelMonitoringJob(
              name='name_value',
              display_name='display_name_value',
              state=job_state.JobState.JOB_STATE_QUEUED,
              schedule='schedule_value',
        )

        # Wrap the value into a proper Response obj
        response_value = mock.Mock()
        response_value.status_code = 200

        # Convert return value to protobuf type
        return_value = gca_model_monitoring_job.ModelMonitoringJob.pb(return_value)
        json_return_value = json_format.MessageToJson(return_value)
        response_value.content = json_return_value.encode('UTF-8')
        req.return_value = response_value
        response = client.create_model_monitoring_job(request)

    # Establish that the response is the type that we expect.
    assert isinstance(response, gca_model_monitoring_job.ModelMonitoringJob)
    assert response.name == 'name_value'
    assert response.display_name == 'display_name_value'
    assert response.state == job_state.JobState.JOB_STATE_QUEUED
    assert response.schedule == 'schedule_value'


@pytest.mark.parametrize("null_interceptor", [True, False])
def test_create_model_monitoring_job_rest_interceptors(null_interceptor):
    transport = transports.ModelMonitoringServiceRestTransport(
        credentials=ga_credentials.AnonymousCredentials(),
        interceptor=None if null_interceptor else transports.ModelMonitoringServiceRestInterceptor(),
        )
    client = ModelMonitoringServiceClient(transport=transport)

    with mock.patch.object(type(client.transport._session), "request") as req, \
        mock.patch.object(path_template, "transcode")  as transcode, \
        mock.patch.object(transports.ModelMonitoringServiceRestInterceptor, "post_create_model_monitoring_job") as post, \
        mock.patch.object(transports.ModelMonitoringServiceRestInterceptor, "pre_create_model_monitoring_job") as pre:
        pre.assert_not_called()
        post.assert_not_called()
        pb_message = model_monitoring_service.CreateModelMonitoringJobRequest.pb(model_monitoring_service.CreateModelMonitoringJobRequest())
        transcode.return_value = {
            "method": "post",
            "uri": "my_uri",
            "body": pb_message,
            "query_params": pb_message,
        }

        req.return_value = mock.Mock()
        req.return_value.status_code = 200
        return_value = gca_model_monitoring_job.ModelMonitoringJob.to_json(gca_model_monitoring_job.ModelMonitoringJob())
        req.return_value.content = return_value

        request = model_monitoring_service.CreateModelMonitoringJobRequest()
        metadata =[
            ("key", "val"),
            ("cephalopod", "squid"),
        ]
        pre.return_value = request, metadata
        post.return_value = gca_model_monitoring_job.ModelMonitoringJob()

        client.create_model_monitoring_job(request, metadata=[("key", "val"), ("cephalopod", "squid"),])

        pre.assert_called_once()
        post.assert_called_once()


def test_get_model_monitoring_job_rest_bad_request(request_type=model_monitoring_service.GetModelMonitoringJobRequest):
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport="rest"
    )
    # send a request that will satisfy transcoding
    request_init = {'name': 'projects/sample1/locations/sample2/modelMonitors/sample3/modelMonitoringJobs/sample4'}
    request = request_type(**request_init)

    # Mock the http request call within the method and fake a BadRequest error.
    with mock.patch.object(Session, 'request') as req, pytest.raises(core_exceptions.BadRequest):
        # Wrap the value into a proper Response obj
        response_value = mock.Mock()
        json_return_value = ''
        response_value.json = mock.Mock(return_value={})
        response_value.status_code = 400
        response_value.request = mock.Mock()
        req.return_value = response_value
        client.get_model_monitoring_job(request)


@pytest.mark.parametrize("request_type", [
  model_monitoring_service.GetModelMonitoringJobRequest,
  dict,
])
def test_get_model_monitoring_job_rest_call_success(request_type):
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport="rest"
    )

    # send a request that will satisfy transcoding
    request_init = {'name': 'projects/sample1/locations/sample2/modelMonitors/sample3/modelMonitoringJobs/sample4'}
    request = request_type(**request_init)

    # Mock the http request call within the method and fake a response.
    with mock.patch.object(type(client.transport._session), 'request') as req:
        # Designate an appropriate value for the returned response.
        return_value = model_monitoring_job.ModelMonitoringJob(
              name='name_value',
              display_name='display_name_value',
              state=job_state.JobState.JOB_STATE_QUEUED,
              schedule='schedule_value',
        )

        # Wrap the value into a proper Response obj
        response_value = mock.Mock()
        response_value.status_code = 200

        # Convert return value to protobuf type
        return_value = model_monitoring_job.ModelMonitoringJob.pb(return_value)
        json_return_value = json_format.MessageToJson(return_value)
        response_value.content = json_return_value.encode('UTF-8')
        req.return_value = response_value
        response = client.get_model_monitoring_job(request)

    # Establish that the response is the type that we expect.
    assert isinstance(response, model_monitoring_job.ModelMonitoringJob)
    assert response.name == 'name_value'
    assert response.display_name == 'display_name_value'
    assert response.state == job_state.JobState.JOB_STATE_QUEUED
    assert response.schedule == 'schedule_value'


@pytest.mark.parametrize("null_interceptor", [True, False])
def test_get_model_monitoring_job_rest_interceptors(null_interceptor):
    transport = transports.ModelMonitoringServiceRestTransport(
        credentials=ga_credentials.AnonymousCredentials(),
        interceptor=None if null_interceptor else transports.ModelMonitoringServiceRestInterceptor(),
        )
    client = ModelMonitoringServiceClient(transport=transport)

    with mock.patch.object(type(client.transport._session), "request") as req, \
        mock.patch.object(path_template, "transcode")  as transcode, \
        mock.patch.object(transports.ModelMonitoringServiceRestInterceptor, "post_get_model_monitoring_job") as post, \
        mock.patch.object(transports.ModelMonitoringServiceRestInterceptor, "pre_get_model_monitoring_job") as pre:
        pre.assert_not_called()
        post.assert_not_called()
        pb_message = model_monitoring_service.GetModelMonitoringJobRequest.pb(model_monitoring_service.GetModelMonitoringJobRequest())
        transcode.return_value = {
            "method": "post",
            "uri": "my_uri",
            "body": pb_message,
            "query_params": pb_message,
        }

        req.return_value = mock.Mock()
        req.return_value.status_code = 200
        return_value = model_monitoring_job.ModelMonitoringJob.to_json(model_monitoring_job.ModelMonitoringJob())
        req.return_value.content = return_value

        request = model_monitoring_service.GetModelMonitoringJobRequest()
        metadata =[
            ("key", "val"),
            ("cephalopod", "squid"),
        ]
        pre.return_value = request, metadata
        post.return_value = model_monitoring_job.ModelMonitoringJob()

        client.get_model_monitoring_job(request, metadata=[("key", "val"), ("cephalopod", "squid"),])

        pre.assert_called_once()
        post.assert_called_once()


def test_list_model_monitoring_jobs_rest_bad_request(request_type=model_monitoring_service.ListModelMonitoringJobsRequest):
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport="rest"
    )
    # send a request that will satisfy transcoding
    request_init = {'parent': 'projects/sample1/locations/sample2/modelMonitors/sample3'}
    request = request_type(**request_init)

    # Mock the http request call within the method and fake a BadRequest error.
    with mock.patch.object(Session, 'request') as req, pytest.raises(core_exceptions.BadRequest):
        # Wrap the value into a proper Response obj
        response_value = mock.Mock()
        json_return_value = ''
        response_value.json = mock.Mock(return_value={})
        response_value.status_code = 400
        response_value.request = mock.Mock()
        req.return_value = response_value
        client.list_model_monitoring_jobs(request)


@pytest.mark.parametrize("request_type", [
  model_monitoring_service.ListModelMonitoringJobsRequest,
  dict,
])
def test_list_model_monitoring_jobs_rest_call_success(request_type):
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport="rest"
    )

    # send a request that will satisfy transcoding
    request_init = {'parent': 'projects/sample1/locations/sample2/modelMonitors/sample3'}
    request = request_type(**request_init)

    # Mock the http request call within the method and fake a response.
    with mock.patch.object(type(client.transport._session), 'request') as req:
        # Designate an appropriate value for the returned response.
        return_value = model_monitoring_service.ListModelMonitoringJobsResponse(
              next_page_token='next_page_token_value',
        )

        # Wrap the value into a proper Response obj
        response_value = mock.Mock()
        response_value.status_code = 200

        # Convert return value to protobuf type
        return_value = model_monitoring_service.ListModelMonitoringJobsResponse.pb(return_value)
        json_return_value = json_format.MessageToJson(return_value)
        response_value.content = json_return_value.encode('UTF-8')
        req.return_value = response_value
        response = client.list_model_monitoring_jobs(request)

    # Establish that the response is the type that we expect.
    assert isinstance(response, pagers.ListModelMonitoringJobsPager)
    assert response.next_page_token == 'next_page_token_value'


@pytest.mark.parametrize("null_interceptor", [True, False])
def test_list_model_monitoring_jobs_rest_interceptors(null_interceptor):
    transport = transports.ModelMonitoringServiceRestTransport(
        credentials=ga_credentials.AnonymousCredentials(),
        interceptor=None if null_interceptor else transports.ModelMonitoringServiceRestInterceptor(),
        )
    client = ModelMonitoringServiceClient(transport=transport)

    with mock.patch.object(type(client.transport._session), "request") as req, \
        mock.patch.object(path_template, "transcode")  as transcode, \
        mock.patch.object(transports.ModelMonitoringServiceRestInterceptor, "post_list_model_monitoring_jobs") as post, \
        mock.patch.object(transports.ModelMonitoringServiceRestInterceptor, "pre_list_model_monitoring_jobs") as pre:
        pre.assert_not_called()
        post.assert_not_called()
        pb_message = model_monitoring_service.ListModelMonitoringJobsRequest.pb(model_monitoring_service.ListModelMonitoringJobsRequest())
        transcode.return_value = {
            "method": "post",
            "uri": "my_uri",
            "body": pb_message,
            "query_params": pb_message,
        }

        req.return_value = mock.Mock()
        req.return_value.status_code = 200
        return_value = model_monitoring_service.ListModelMonitoringJobsResponse.to_json(model_monitoring_service.ListModelMonitoringJobsResponse())
        req.return_value.content = return_value

        request = model_monitoring_service.ListModelMonitoringJobsRequest()
        metadata =[
            ("key", "val"),
            ("cephalopod", "squid"),
        ]
        pre.return_value = request, metadata
        post.return_value = model_monitoring_service.ListModelMonitoringJobsResponse()

        client.list_model_monitoring_jobs(request, metadata=[("key", "val"), ("cephalopod", "squid"),])

        pre.assert_called_once()
        post.assert_called_once()


def test_delete_model_monitoring_job_rest_bad_request(request_type=model_monitoring_service.DeleteModelMonitoringJobRequest):
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport="rest"
    )
    # send a request that will satisfy transcoding
    request_init = {'name': 'projects/sample1/locations/sample2/modelMonitors/sample3/modelMonitoringJobs/sample4'}
    request = request_type(**request_init)

    # Mock the http request call within the method and fake a BadRequest error.
    with mock.patch.object(Session, 'request') as req, pytest.raises(core_exceptions.BadRequest):
        # Wrap the value into a proper Response obj
        response_value = mock.Mock()
        json_return_value = ''
        response_value.json = mock.Mock(return_value={})
        response_value.status_code = 400
        response_value.request = mock.Mock()
        req.return_value = response_value
        client.delete_model_monitoring_job(request)


@pytest.mark.parametrize("request_type", [
  model_monitoring_service.DeleteModelMonitoringJobRequest,
  dict,
])
def test_delete_model_monitoring_job_rest_call_success(request_type):
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport="rest"
    )

    # send a request that will satisfy transcoding
    request_init = {'name': 'projects/sample1/locations/sample2/modelMonitors/sample3/modelMonitoringJobs/sample4'}
    request = request_type(**request_init)

    # Mock the http request call within the method and fake a response.
    with mock.patch.object(type(client.transport._session), 'request') as req:
        # Designate an appropriate value for the returned response.
        return_value = operations_pb2.Operation(name='operations/spam')

        # Wrap the value into a proper Response obj
        response_value = mock.Mock()
        response_value.status_code = 200
        json_return_value = json_format.MessageToJson(return_value)
        response_value.content = json_return_value.encode('UTF-8')
        req.return_value = response_value
        response = client.delete_model_monitoring_job(request)

    # Establish that the response is the type that we expect.
    json_return_value = json_format.MessageToJson(return_value)


@pytest.mark.parametrize("null_interceptor", [True, False])
def test_delete_model_monitoring_job_rest_interceptors(null_interceptor):
    transport = transports.ModelMonitoringServiceRestTransport(
        credentials=ga_credentials.AnonymousCredentials(),
        interceptor=None if null_interceptor else transports.ModelMonitoringServiceRestInterceptor(),
        )
    client = ModelMonitoringServiceClient(transport=transport)

    with mock.patch.object(type(client.transport._session), "request") as req, \
        mock.patch.object(path_template, "transcode")  as transcode, \
        mock.patch.object(operation.Operation, "_set_result_from_operation"), \
        mock.patch.object(transports.ModelMonitoringServiceRestInterceptor, "post_delete_model_monitoring_job") as post, \
        mock.patch.object(transports.ModelMonitoringServiceRestInterceptor, "pre_delete_model_monitoring_job") as pre:
        pre.assert_not_called()
        post.assert_not_called()
        pb_message = model_monitoring_service.DeleteModelMonitoringJobRequest.pb(model_monitoring_service.DeleteModelMonitoringJobRequest())
        transcode.return_value = {
            "method": "post",
            "uri": "my_uri",
            "body": pb_message,
            "query_params": pb_message,
        }

        req.return_value = mock.Mock()
        req.return_value.status_code = 200
        return_value = json_format.MessageToJson(operations_pb2.Operation())
        req.return_value.content = return_value

        request = model_monitoring_service.DeleteModelMonitoringJobRequest()
        metadata =[
            ("key", "val"),
            ("cephalopod", "squid"),
        ]
        pre.return_value = request, metadata
        post.return_value = operations_pb2.Operation()

        client.delete_model_monitoring_job(request, metadata=[("key", "val"), ("cephalopod", "squid"),])

        pre.assert_called_once()
        post.assert_called_once()


def test_search_model_monitoring_stats_rest_bad_request(request_type=model_monitoring_service.SearchModelMonitoringStatsRequest):
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport="rest"
    )
    # send a request that will satisfy transcoding
    request_init = {'model_monitor': 'projects/sample1/locations/sample2/modelMonitors/sample3'}
    request = request_type(**request_init)

    # Mock the http request call within the method and fake a BadRequest error.
    with mock.patch.object(Session, 'request') as req, pytest.raises(core_exceptions.BadRequest):
        # Wrap the value into a proper Response obj
        response_value = mock.Mock()
        json_return_value = ''
        response_value.json = mock.Mock(return_value={})
        response_value.status_code = 400
        response_value.request = mock.Mock()
        req.return_value = response_value
        client.search_model_monitoring_stats(request)


@pytest.mark.parametrize("request_type", [
  model_monitoring_service.SearchModelMonitoringStatsRequest,
  dict,
])
def test_search_model_monitoring_stats_rest_call_success(request_type):
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport="rest"
    )

    # send a request that will satisfy transcoding
    request_init = {'model_monitor': 'projects/sample1/locations/sample2/modelMonitors/sample3'}
    request = request_type(**request_init)

    # Mock the http request call within the method and fake a response.
    with mock.patch.object(type(client.transport._session), 'request') as req:
        # Designate an appropriate value for the returned response.
        return_value = model_monitoring_service.SearchModelMonitoringStatsResponse(
              next_page_token='next_page_token_value',
        )

        # Wrap the value into a proper Response obj
        response_value = mock.Mock()
        response_value.status_code = 200

        # Convert return value to protobuf type
        return_value = model_monitoring_service.SearchModelMonitoringStatsResponse.pb(return_value)
        json_return_value = json_format.MessageToJson(return_value)
        response_value.content = json_return_value.encode('UTF-8')
        req.return_value = response_value
        response = client.search_model_monitoring_stats(request)

    # Establish that the response is the type that we expect.
    assert isinstance(response, pagers.SearchModelMonitoringStatsPager)
    assert response.next_page_token == 'next_page_token_value'


@pytest.mark.parametrize("null_interceptor", [True, False])
def test_search_model_monitoring_stats_rest_interceptors(null_interceptor):
    transport = transports.ModelMonitoringServiceRestTransport(
        credentials=ga_credentials.AnonymousCredentials(),
        interceptor=None if null_interceptor else transports.ModelMonitoringServiceRestInterceptor(),
        )
    client = ModelMonitoringServiceClient(transport=transport)

    with mock.patch.object(type(client.transport._session), "request") as req, \
        mock.patch.object(path_template, "transcode")  as transcode, \
        mock.patch.object(transports.ModelMonitoringServiceRestInterceptor, "post_search_model_monitoring_stats") as post, \
        mock.patch.object(transports.ModelMonitoringServiceRestInterceptor, "pre_search_model_monitoring_stats") as pre:
        pre.assert_not_called()
        post.assert_not_called()
        pb_message = model_monitoring_service.SearchModelMonitoringStatsRequest.pb(model_monitoring_service.SearchModelMonitoringStatsRequest())
        transcode.return_value = {
            "method": "post",
            "uri": "my_uri",
            "body": pb_message,
            "query_params": pb_message,
        }

        req.return_value = mock.Mock()
        req.return_value.status_code = 200
        return_value = model_monitoring_service.SearchModelMonitoringStatsResponse.to_json(model_monitoring_service.SearchModelMonitoringStatsResponse())
        req.return_value.content = return_value

        request = model_monitoring_service.SearchModelMonitoringStatsRequest()
        metadata =[
            ("key", "val"),
            ("cephalopod", "squid"),
        ]
        pre.return_value = request, metadata
        post.return_value = model_monitoring_service.SearchModelMonitoringStatsResponse()

        client.search_model_monitoring_stats(request, metadata=[("key", "val"), ("cephalopod", "squid"),])

        pre.assert_called_once()
        post.assert_called_once()


def test_search_model_monitoring_alerts_rest_bad_request(request_type=model_monitoring_service.SearchModelMonitoringAlertsRequest):
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport="rest"
    )
    # send a request that will satisfy transcoding
    request_init = {'model_monitor': 'projects/sample1/locations/sample2/modelMonitors/sample3'}
    request = request_type(**request_init)

    # Mock the http request call within the method and fake a BadRequest error.
    with mock.patch.object(Session, 'request') as req, pytest.raises(core_exceptions.BadRequest):
        # Wrap the value into a proper Response obj
        response_value = mock.Mock()
        json_return_value = ''
        response_value.json = mock.Mock(return_value={})
        response_value.status_code = 400
        response_value.request = mock.Mock()
        req.return_value = response_value
        client.search_model_monitoring_alerts(request)


@pytest.mark.parametrize("request_type", [
  model_monitoring_service.SearchModelMonitoringAlertsRequest,
  dict,
])
def test_search_model_monitoring_alerts_rest_call_success(request_type):
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport="rest"
    )

    # send a request that will satisfy transcoding
    request_init = {'model_monitor': 'projects/sample1/locations/sample2/modelMonitors/sample3'}
    request = request_type(**request_init)

    # Mock the http request call within the method and fake a response.
    with mock.patch.object(type(client.transport._session), 'request') as req:
        # Designate an appropriate value for the returned response.
        return_value = model_monitoring_service.SearchModelMonitoringAlertsResponse(
              total_number_alerts=2038,
              next_page_token='next_page_token_value',
        )

        # Wrap the value into a proper Response obj
        response_value = mock.Mock()
        response_value.status_code = 200

        # Convert return value to protobuf type
        return_value = model_monitoring_service.SearchModelMonitoringAlertsResponse.pb(return_value)
        json_return_value = json_format.MessageToJson(return_value)
        response_value.content = json_return_value.encode('UTF-8')
        req.return_value = response_value
        response = client.search_model_monitoring_alerts(request)

    # Establish that the response is the type that we expect.
    assert isinstance(response, pagers.SearchModelMonitoringAlertsPager)
    assert response.total_number_alerts == 2038
    assert response.next_page_token == 'next_page_token_value'


@pytest.mark.parametrize("null_interceptor", [True, False])
def test_search_model_monitoring_alerts_rest_interceptors(null_interceptor):
    transport = transports.ModelMonitoringServiceRestTransport(
        credentials=ga_credentials.AnonymousCredentials(),
        interceptor=None if null_interceptor else transports.ModelMonitoringServiceRestInterceptor(),
        )
    client = ModelMonitoringServiceClient(transport=transport)

    with mock.patch.object(type(client.transport._session), "request") as req, \
        mock.patch.object(path_template, "transcode")  as transcode, \
        mock.patch.object(transports.ModelMonitoringServiceRestInterceptor, "post_search_model_monitoring_alerts") as post, \
        mock.patch.object(transports.ModelMonitoringServiceRestInterceptor, "pre_search_model_monitoring_alerts") as pre:
        pre.assert_not_called()
        post.assert_not_called()
        pb_message = model_monitoring_service.SearchModelMonitoringAlertsRequest.pb(model_monitoring_service.SearchModelMonitoringAlertsRequest())
        transcode.return_value = {
            "method": "post",
            "uri": "my_uri",
            "body": pb_message,
            "query_params": pb_message,
        }

        req.return_value = mock.Mock()
        req.return_value.status_code = 200
        return_value = model_monitoring_service.SearchModelMonitoringAlertsResponse.to_json(model_monitoring_service.SearchModelMonitoringAlertsResponse())
        req.return_value.content = return_value

        request = model_monitoring_service.SearchModelMonitoringAlertsRequest()
        metadata =[
            ("key", "val"),
            ("cephalopod", "squid"),
        ]
        pre.return_value = request, metadata
        post.return_value = model_monitoring_service.SearchModelMonitoringAlertsResponse()

        client.search_model_monitoring_alerts(request, metadata=[("key", "val"), ("cephalopod", "squid"),])

        pre.assert_called_once()
        post.assert_called_once()


def test_get_location_rest_bad_request(request_type=locations_pb2.GetLocationRequest):
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport="rest",
    )
    request = request_type()
    request = json_format.ParseDict({'name': 'projects/sample1/locations/sample2'}, request)

    # Mock the http request call within the method and fake a BadRequest error.
    with mock.patch.object(Session, 'request') as req, pytest.raises(core_exceptions.BadRequest):
        # Wrap the value into a proper Response obj
        response_value = Response()
        json_return_value = ''
        response_value.json = mock.Mock(return_value={})
        response_value.status_code = 400
        response_value.request = Request()
        req.return_value = response_value
        client.get_location(request)


@pytest.mark.parametrize("request_type", [
    locations_pb2.GetLocationRequest,
    dict,
])
def test_get_location_rest(request_type):
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport="rest",
    )

    request_init = {'name': 'projects/sample1/locations/sample2'}
    request = request_type(**request_init)
    # Mock the http request call within the method and fake a response.
    with mock.patch.object(Session, 'request') as req:
        # Designate an appropriate value for the returned response.
        return_value = locations_pb2.Location()

        # Wrap the value into a proper Response obj
        response_value = mock.Mock()
        response_value.status_code = 200
        json_return_value = json_format.MessageToJson(return_value)
        response_value.content = json_return_value.encode('UTF-8')

        req.return_value = response_value

        response = client.get_location(request)

    # Establish that the response is the type that we expect.
    assert isinstance(response, locations_pb2.Location)


def test_list_locations_rest_bad_request(request_type=locations_pb2.ListLocationsRequest):
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport="rest",
    )
    request = request_type()
    request = json_format.ParseDict({'name': 'projects/sample1'}, request)

    # Mock the http request call within the method and fake a BadRequest error.
    with mock.patch.object(Session, 'request') as req, pytest.raises(core_exceptions.BadRequest):
        # Wrap the value into a proper Response obj
        response_value = Response()
        json_return_value = ''
        response_value.json = mock.Mock(return_value={})
        response_value.status_code = 400
        response_value.request = Request()
        req.return_value = response_value
        client.list_locations(request)


@pytest.mark.parametrize("request_type", [
    locations_pb2.ListLocationsRequest,
    dict,
])
def test_list_locations_rest(request_type):
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport="rest",
    )

    request_init = {'name': 'projects/sample1'}
    request = request_type(**request_init)
    # Mock the http request call within the method and fake a response.
    with mock.patch.object(Session, 'request') as req:
        # Designate an appropriate value for the returned response.
        return_value = locations_pb2.ListLocationsResponse()

        # Wrap the value into a proper Response obj
        response_value = mock.Mock()
        response_value.status_code = 200
        json_return_value = json_format.MessageToJson(return_value)
        response_value.content = json_return_value.encode('UTF-8')

        req.return_value = response_value

        response = client.list_locations(request)

    # Establish that the response is the type that we expect.
    assert isinstance(response, locations_pb2.ListLocationsResponse)


def test_get_iam_policy_rest_bad_request(request_type=iam_policy_pb2.GetIamPolicyRequest):
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport="rest",
    )
    request = request_type()
    request = json_format.ParseDict({'resource': 'projects/sample1/locations/sample2/featurestores/sample3'}, request)

    # Mock the http request call within the method and fake a BadRequest error.
    with mock.patch.object(Session, 'request') as req, pytest.raises(core_exceptions.BadRequest):
        # Wrap the value into a proper Response obj
        response_value = Response()
        json_return_value = ''
        response_value.json = mock.Mock(return_value={})
        response_value.status_code = 400
        response_value.request = Request()
        req.return_value = response_value
        client.get_iam_policy(request)


@pytest.mark.parametrize("request_type", [
    iam_policy_pb2.GetIamPolicyRequest,
    dict,
])
def test_get_iam_policy_rest(request_type):
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport="rest",
    )

    request_init = {'resource': 'projects/sample1/locations/sample2/featurestores/sample3'}
    request = request_type(**request_init)
    # Mock the http request call within the method and fake a response.
    with mock.patch.object(Session, 'request') as req:
        # Designate an appropriate value for the returned response.
        return_value = policy_pb2.Policy()

        # Wrap the value into a proper Response obj
        response_value = mock.Mock()
        response_value.status_code = 200
        json_return_value = json_format.MessageToJson(return_value)
        response_value.content = json_return_value.encode('UTF-8')

        req.return_value = response_value

        response = client.get_iam_policy(request)

    # Establish that the response is the type that we expect.
    assert isinstance(response, policy_pb2.Policy)


def test_set_iam_policy_rest_bad_request(request_type=iam_policy_pb2.SetIamPolicyRequest):
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport="rest",
    )
    request = request_type()
    request = json_format.ParseDict({'resource': 'projects/sample1/locations/sample2/featurestores/sample3'}, request)

    # Mock the http request call within the method and fake a BadRequest error.
    with mock.patch.object(Session, 'request') as req, pytest.raises(core_exceptions.BadRequest):
        # Wrap the value into a proper Response obj
        response_value = Response()
        json_return_value = ''
        response_value.json = mock.Mock(return_value={})
        response_value.status_code = 400
        response_value.request = Request()
        req.return_value = response_value
        client.set_iam_policy(request)


@pytest.mark.parametrize("request_type", [
    iam_policy_pb2.SetIamPolicyRequest,
    dict,
])
def test_set_iam_policy_rest(request_type):
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport="rest",
    )

    request_init = {'resource': 'projects/sample1/locations/sample2/featurestores/sample3'}
    request = request_type(**request_init)
    # Mock the http request call within the method and fake a response.
    with mock.patch.object(Session, 'request') as req:
        # Designate an appropriate value for the returned response.
        return_value = policy_pb2.Policy()

        # Wrap the value into a proper Response obj
        response_value = mock.Mock()
        response_value.status_code = 200
        json_return_value = json_format.MessageToJson(return_value)
        response_value.content = json_return_value.encode('UTF-8')

        req.return_value = response_value

        response = client.set_iam_policy(request)

    # Establish that the response is the type that we expect.
    assert isinstance(response, policy_pb2.Policy)


def test_test_iam_permissions_rest_bad_request(request_type=iam_policy_pb2.TestIamPermissionsRequest):
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport="rest",
    )
    request = request_type()
    request = json_format.ParseDict({'resource': 'projects/sample1/locations/sample2/featurestores/sample3'}, request)

    # Mock the http request call within the method and fake a BadRequest error.
    with mock.patch.object(Session, 'request') as req, pytest.raises(core_exceptions.BadRequest):
        # Wrap the value into a proper Response obj
        response_value = Response()
        json_return_value = ''
        response_value.json = mock.Mock(return_value={})
        response_value.status_code = 400
        response_value.request = Request()
        req.return_value = response_value
        client.test_iam_permissions(request)


@pytest.mark.parametrize("request_type", [
    iam_policy_pb2.TestIamPermissionsRequest,
    dict,
])
def test_test_iam_permissions_rest(request_type):
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport="rest",
    )

    request_init = {'resource': 'projects/sample1/locations/sample2/featurestores/sample3'}
    request = request_type(**request_init)
    # Mock the http request call within the method and fake a response.
    with mock.patch.object(Session, 'request') as req:
        # Designate an appropriate value for the returned response.
        return_value = iam_policy_pb2.TestIamPermissionsResponse()

        # Wrap the value into a proper Response obj
        response_value = mock.Mock()
        response_value.status_code = 200
        json_return_value = json_format.MessageToJson(return_value)
        response_value.content = json_return_value.encode('UTF-8')

        req.return_value = response_value

        response = client.test_iam_permissions(request)

    # Establish that the response is the type that we expect.
    assert isinstance(response, iam_policy_pb2.TestIamPermissionsResponse)


def test_cancel_operation_rest_bad_request(request_type=operations_pb2.CancelOperationRequest):
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport="rest",
    )
    request = request_type()
    request = json_format.ParseDict({'name': 'projects/sample1/locations/sample2/operations/sample3'}, request)

    # Mock the http request call within the method and fake a BadRequest error.
    with mock.patch.object(Session, 'request') as req, pytest.raises(core_exceptions.BadRequest):
        # Wrap the value into a proper Response obj
        response_value = Response()
        json_return_value = ''
        response_value.json = mock.Mock(return_value={})
        response_value.status_code = 400
        response_value.request = Request()
        req.return_value = response_value
        client.cancel_operation(request)


@pytest.mark.parametrize("request_type", [
    operations_pb2.CancelOperationRequest,
    dict,
])
def test_cancel_operation_rest(request_type):
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport="rest",
    )

    request_init = {'name': 'projects/sample1/locations/sample2/operations/sample3'}
    request = request_type(**request_init)
    # Mock the http request call within the method and fake a response.
    with mock.patch.object(Session, 'request') as req:
        # Designate an appropriate value for the returned response.
        return_value = None

        # Wrap the value into a proper Response obj
        response_value = mock.Mock()
        response_value.status_code = 200
        json_return_value = '{}'
        response_value.content = json_return_value.encode('UTF-8')

        req.return_value = response_value

        response = client.cancel_operation(request)

    # Establish that the response is the type that we expect.
    assert response is None


def test_delete_operation_rest_bad_request(request_type=operations_pb2.DeleteOperationRequest):
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport="rest",
    )
    request = request_type()
    request = json_format.ParseDict({'name': 'projects/sample1/locations/sample2/operations/sample3'}, request)

    # Mock the http request call within the method and fake a BadRequest error.
    with mock.patch.object(Session, 'request') as req, pytest.raises(core_exceptions.BadRequest):
        # Wrap the value into a proper Response obj
        response_value = Response()
        json_return_value = ''
        response_value.json = mock.Mock(return_value={})
        response_value.status_code = 400
        response_value.request = Request()
        req.return_value = response_value
        client.delete_operation(request)


@pytest.mark.parametrize("request_type", [
    operations_pb2.DeleteOperationRequest,
    dict,
])
def test_delete_operation_rest(request_type):
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport="rest",
    )

    request_init = {'name': 'projects/sample1/locations/sample2/operations/sample3'}
    request = request_type(**request_init)
    # Mock the http request call within the method and fake a response.
    with mock.patch.object(Session, 'request') as req:
        # Designate an appropriate value for the returned response.
        return_value = None

        # Wrap the value into a proper Response obj
        response_value = mock.Mock()
        response_value.status_code = 200
        json_return_value = '{}'
        response_value.content = json_return_value.encode('UTF-8')

        req.return_value = response_value

        response = client.delete_operation(request)

    # Establish that the response is the type that we expect.
    assert response is None


def test_get_operation_rest_bad_request(request_type=operations_pb2.GetOperationRequest):
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport="rest",
    )
    request = request_type()
    request = json_format.ParseDict({'name': 'projects/sample1/locations/sample2/operations/sample3'}, request)

    # Mock the http request call within the method and fake a BadRequest error.
    with mock.patch.object(Session, 'request') as req, pytest.raises(core_exceptions.BadRequest):
        # Wrap the value into a proper Response obj
        response_value = Response()
        json_return_value = ''
        response_value.json = mock.Mock(return_value={})
        response_value.status_code = 400
        response_value.request = Request()
        req.return_value = response_value
        client.get_operation(request)


@pytest.mark.parametrize("request_type", [
    operations_pb2.GetOperationRequest,
    dict,
])
def test_get_operation_rest(request_type):
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport="rest",
    )

    request_init = {'name': 'projects/sample1/locations/sample2/operations/sample3'}
    request = request_type(**request_init)
    # Mock the http request call within the method and fake a response.
    with mock.patch.object(Session, 'request') as req:
        # Designate an appropriate value for the returned response.
        return_value = operations_pb2.Operation()

        # Wrap the value into a proper Response obj
        response_value = mock.Mock()
        response_value.status_code = 200
        json_return_value = json_format.MessageToJson(return_value)
        response_value.content = json_return_value.encode('UTF-8')

        req.return_value = response_value

        response = client.get_operation(request)

    # Establish that the response is the type that we expect.
    assert isinstance(response, operations_pb2.Operation)


def test_list_operations_rest_bad_request(request_type=operations_pb2.ListOperationsRequest):
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport="rest",
    )
    request = request_type()
    request = json_format.ParseDict({'name': 'projects/sample1/locations/sample2'}, request)

    # Mock the http request call within the method and fake a BadRequest error.
    with mock.patch.object(Session, 'request') as req, pytest.raises(core_exceptions.BadRequest):
        # Wrap the value into a proper Response obj
        response_value = Response()
        json_return_value = ''
        response_value.json = mock.Mock(return_value={})
        response_value.status_code = 400
        response_value.request = Request()
        req.return_value = response_value
        client.list_operations(request)


@pytest.mark.parametrize("request_type", [
    operations_pb2.ListOperationsRequest,
    dict,
])
def test_list_operations_rest(request_type):
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport="rest",
    )

    request_init = {'name': 'projects/sample1/locations/sample2'}
    request = request_type(**request_init)
    # Mock the http request call within the method and fake a response.
    with mock.patch.object(Session, 'request') as req:
        # Designate an appropriate value for the returned response.
        return_value = operations_pb2.ListOperationsResponse()

        # Wrap the value into a proper Response obj
        response_value = mock.Mock()
        response_value.status_code = 200
        json_return_value = json_format.MessageToJson(return_value)
        response_value.content = json_return_value.encode('UTF-8')

        req.return_value = response_value

        response = client.list_operations(request)

    # Establish that the response is the type that we expect.
    assert isinstance(response, operations_pb2.ListOperationsResponse)


def test_wait_operation_rest_bad_request(request_type=operations_pb2.WaitOperationRequest):
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport="rest",
    )
    request = request_type()
    request = json_format.ParseDict({'name': 'projects/sample1/locations/sample2/operations/sample3'}, request)

    # Mock the http request call within the method and fake a BadRequest error.
    with mock.patch.object(Session, 'request') as req, pytest.raises(core_exceptions.BadRequest):
        # Wrap the value into a proper Response obj
        response_value = Response()
        json_return_value = ''
        response_value.json = mock.Mock(return_value={})
        response_value.status_code = 400
        response_value.request = Request()
        req.return_value = response_value
        client.wait_operation(request)


@pytest.mark.parametrize("request_type", [
    operations_pb2.WaitOperationRequest,
    dict,
])
def test_wait_operation_rest(request_type):
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport="rest",
    )

    request_init = {'name': 'projects/sample1/locations/sample2/operations/sample3'}
    request = request_type(**request_init)
    # Mock the http request call within the method and fake a response.
    with mock.patch.object(Session, 'request') as req:
        # Designate an appropriate value for the returned response.
        return_value = operations_pb2.Operation()

        # Wrap the value into a proper Response obj
        response_value = mock.Mock()
        response_value.status_code = 200
        json_return_value = json_format.MessageToJson(return_value)
        response_value.content = json_return_value.encode('UTF-8')

        req.return_value = response_value

        response = client.wait_operation(request)

    # Establish that the response is the type that we expect.
    assert isinstance(response, operations_pb2.Operation)

def test_initialize_client_w_rest():
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport="rest"
    )
    assert client is not None


# This test is a coverage failsafe to make sure that totally empty calls,
# i.e. request == None and no flattened fields passed, work.
def test_create_model_monitor_empty_call_rest():
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport="rest",
    )

    # Mock the actual call, and fake the request.
    with mock.patch.object(
            type(client.transport.create_model_monitor),
            '__call__') as call:
        client.create_model_monitor(request=None)

        # Establish that the underlying stub method was called.
        call.assert_called()
        _, args, _ = call.mock_calls[0]
        request_msg = model_monitoring_service.CreateModelMonitorRequest()

        assert args[0] == request_msg


# This test is a coverage failsafe to make sure that totally empty calls,
# i.e. request == None and no flattened fields passed, work.
def test_update_model_monitor_empty_call_rest():
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport="rest",
    )

    # Mock the actual call, and fake the request.
    with mock.patch.object(
            type(client.transport.update_model_monitor),
            '__call__') as call:
        client.update_model_monitor(request=None)

        # Establish that the underlying stub method was called.
        call.assert_called()
        _, args, _ = call.mock_calls[0]
        request_msg = model_monitoring_service.UpdateModelMonitorRequest()

        assert args[0] == request_msg


# This test is a coverage failsafe to make sure that totally empty calls,
# i.e. request == None and no flattened fields passed, work.
def test_get_model_monitor_empty_call_rest():
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport="rest",
    )

    # Mock the actual call, and fake the request.
    with mock.patch.object(
            type(client.transport.get_model_monitor),
            '__call__') as call:
        client.get_model_monitor(request=None)

        # Establish that the underlying stub method was called.
        call.assert_called()
        _, args, _ = call.mock_calls[0]
        request_msg = model_monitoring_service.GetModelMonitorRequest()

        assert args[0] == request_msg


# This test is a coverage failsafe to make sure that totally empty calls,
# i.e. request == None and no flattened fields passed, work.
def test_list_model_monitors_empty_call_rest():
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport="rest",
    )

    # Mock the actual call, and fake the request.
    with mock.patch.object(
            type(client.transport.list_model_monitors),
            '__call__') as call:
        client.list_model_monitors(request=None)

        # Establish that the underlying stub method was called.
        call.assert_called()
        _, args, _ = call.mock_calls[0]
        request_msg = model_monitoring_service.ListModelMonitorsRequest()

        assert args[0] == request_msg


# This test is a coverage failsafe to make sure that totally empty calls,
# i.e. request == None and no flattened fields passed, work.
def test_delete_model_monitor_empty_call_rest():
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport="rest",
    )

    # Mock the actual call, and fake the request.
    with mock.patch.object(
            type(client.transport.delete_model_monitor),
            '__call__') as call:
        client.delete_model_monitor(request=None)

        # Establish that the underlying stub method was called.
        call.assert_called()
        _, args, _ = call.mock_calls[0]
        request_msg = model_monitoring_service.DeleteModelMonitorRequest()

        assert args[0] == request_msg


# This test is a coverage failsafe to make sure that totally empty calls,
# i.e. request == None and no flattened fields passed, work.
def test_create_model_monitoring_job_empty_call_rest():
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport="rest",
    )

    # Mock the actual call, and fake the request.
    with mock.patch.object(
            type(client.transport.create_model_monitoring_job),
            '__call__') as call:
        client.create_model_monitoring_job(request=None)

        # Establish that the underlying stub method was called.
        call.assert_called()
        _, args, _ = call.mock_calls[0]
        request_msg = model_monitoring_service.CreateModelMonitoringJobRequest()

        assert args[0] == request_msg


# This test is a coverage failsafe to make sure that totally empty calls,
# i.e. request == None and no flattened fields passed, work.
def test_get_model_monitoring_job_empty_call_rest():
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport="rest",
    )

    # Mock the actual call, and fake the request.
    with mock.patch.object(
            type(client.transport.get_model_monitoring_job),
            '__call__') as call:
        client.get_model_monitoring_job(request=None)

        # Establish that the underlying stub method was called.
        call.assert_called()
        _, args, _ = call.mock_calls[0]
        request_msg = model_monitoring_service.GetModelMonitoringJobRequest()

        assert args[0] == request_msg


# This test is a coverage failsafe to make sure that totally empty calls,
# i.e. request == None and no flattened fields passed, work.
def test_list_model_monitoring_jobs_empty_call_rest():
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport="rest",
    )

    # Mock the actual call, and fake the request.
    with mock.patch.object(
            type(client.transport.list_model_monitoring_jobs),
            '__call__') as call:
        client.list_model_monitoring_jobs(request=None)

        # Establish that the underlying stub method was called.
        call.assert_called()
        _, args, _ = call.mock_calls[0]
        request_msg = model_monitoring_service.ListModelMonitoringJobsRequest()

        assert args[0] == request_msg


# This test is a coverage failsafe to make sure that totally empty calls,
# i.e. request == None and no flattened fields passed, work.
def test_delete_model_monitoring_job_empty_call_rest():
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport="rest",
    )

    # Mock the actual call, and fake the request.
    with mock.patch.object(
            type(client.transport.delete_model_monitoring_job),
            '__call__') as call:
        client.delete_model_monitoring_job(request=None)

        # Establish that the underlying stub method was called.
        call.assert_called()
        _, args, _ = call.mock_calls[0]
        request_msg = model_monitoring_service.DeleteModelMonitoringJobRequest()

        assert args[0] == request_msg


# This test is a coverage failsafe to make sure that totally empty calls,
# i.e. request == None and no flattened fields passed, work.
def test_search_model_monitoring_stats_empty_call_rest():
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport="rest",
    )

    # Mock the actual call, and fake the request.
    with mock.patch.object(
            type(client.transport.search_model_monitoring_stats),
            '__call__') as call:
        client.search_model_monitoring_stats(request=None)

        # Establish that the underlying stub method was called.
        call.assert_called()
        _, args, _ = call.mock_calls[0]
        request_msg = model_monitoring_service.SearchModelMonitoringStatsRequest()

        assert args[0] == request_msg


# This test is a coverage failsafe to make sure that totally empty calls,
# i.e. request == None and no flattened fields passed, work.
def test_search_model_monitoring_alerts_empty_call_rest():
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport="rest",
    )

    # Mock the actual call, and fake the request.
    with mock.patch.object(
            type(client.transport.search_model_monitoring_alerts),
            '__call__') as call:
        client.search_model_monitoring_alerts(request=None)

        # Establish that the underlying stub method was called.
        call.assert_called()
        _, args, _ = call.mock_calls[0]
        request_msg = model_monitoring_service.SearchModelMonitoringAlertsRequest()

        assert args[0] == request_msg


def test_model_monitoring_service_rest_lro_client():
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport="rest",
    )
    transport = client.transport

    # Ensure that we have an api-core operations client.
    assert isinstance(
        transport.operations_client,
operations_v1.AbstractOperationsClient,
    )

    # Ensure that subsequent calls to the property send the exact same object.
    assert transport.operations_client is transport.operations_client

def test_transport_kind_rest_asyncio():
    if not HAS_ASYNC_REST_EXTRA:
        pytest.skip("the library must be installed with the `async_rest` extra to test this feature.")
    transport = ModelMonitoringServiceAsyncClient.get_transport_class("rest_asyncio")(
        credentials=async_anonymous_credentials()
    )
    assert transport.kind == "rest_asyncio"


@pytest.mark.asyncio
async def test_create_model_monitor_rest_asyncio_bad_request(request_type=model_monitoring_service.CreateModelMonitorRequest):
    if not HAS_ASYNC_REST_EXTRA:
        pytest.skip("the library must be installed with the `async_rest` extra to test this feature.")
    client = ModelMonitoringServiceAsyncClient(
        credentials=async_anonymous_credentials(),
        transport="rest_asyncio"
    )
    # send a request that will satisfy transcoding
    request_init = {'parent': 'projects/sample1/locations/sample2'}
    request = request_type(**request_init)

    # Mock the http request call within the method and fake a BadRequest error.
    with mock.patch.object(AsyncAuthorizedSession, 'request') as req, pytest.raises(core_exceptions.BadRequest):
        # Wrap the value into a proper Response obj
        response_value = mock.Mock()
        response_value.read = mock.AsyncMock(return_value=b'{}')
        response_value.status_code = 400
        response_value.request = mock.Mock()
        req.return_value = response_value
        await client.create_model_monitor(request)


@pytest.mark.asyncio
@pytest.mark.parametrize("request_type", [
  model_monitoring_service.CreateModelMonitorRequest,
  dict,
])
async def test_create_model_monitor_rest_asyncio_call_success(request_type):
    if not HAS_ASYNC_REST_EXTRA:
        pytest.skip("the library must be installed with the `async_rest` extra to test this feature.")
    client = ModelMonitoringServiceAsyncClient(
        credentials=async_anonymous_credentials(),
        transport="rest_asyncio"
    )

    # send a request that will satisfy transcoding
    request_init = {'parent': 'projects/sample1/locations/sample2'}
    request_init["model_monitor"] = {'tabular_objective': {'feature_drift_spec': {'features': ['features_value1', 'features_value2'], 'categorical_metric_type': 'categorical_metric_type_value', 'numeric_metric_type': 'numeric_metric_type_value', 'default_categorical_alert_condition': {'threshold': 0.973}, 'default_numeric_alert_condition': {}, 'feature_alert_conditions': {}}, 'prediction_output_drift_spec': {}, 'feature_attribution_spec': {'features': ['features_value1', 'features_value2'], 'default_alert_condition': {}, 'feature_alert_conditions': {}, 'batch_explanation_dedicated_resources': {'machine_spec': {'machine_type': 'machine_type_value', 'accelerator_type': 1, 'accelerator_count': 1805, 'tpu_topology': 'tpu_topology_value', 'reservation_affinity': {'reservation_affinity_type': 1, 'key': 'key_value', 'values': ['values_value1', 'values_value2']}}, 'starting_replica_count': 2355, 'max_replica_count': 1805}}}, 'name': 'name_value', 'display_name': 'display_name_value', 'model_monitoring_target': {'vertex_model': {'model': 'model_value', 'model_version_id': 'model_version_id_value'}}, 'training_dataset': {'columnized_dataset': {'vertex_dataset': 'vertex_dataset_value', 'gcs_source': {'gcs_uri': 'gcs_uri_value', 'format_': 1}, 'bigquery_source': {'table_uri': 'table_uri_value', 'query': 'query_value'}, 'timestamp_field': 'timestamp_field_value'}, 'batch_prediction_output': {'batch_prediction_job': 'batch_prediction_job_value'}, 'vertex_endpoint_logs': {'endpoints': ['endpoints_value1', 'endpoints_value2']}, 'time_interval': {'start_time': {'seconds': 751, 'nanos': 543}, 'end_time': {}}, 'time_offset': {'offset': 'offset_value', 'window': 'window_value'}}, 'notification_spec': {'email_config': {'user_emails': ['user_emails_value1', 'user_emails_value2']}, 'enable_cloud_logging': True, 'notification_channel_configs': [{'notification_channel': 'notification_channel_value'}]}, 'output_spec': {'gcs_base_directory': {'output_uri_prefix': 'output_uri_prefix_value'}}, 'explanation_spec': {'parameters': {'sampled_shapley_attribution': {'path_count': 1077}, 'integrated_gradients_attribution': {'step_count': 1092, 'smooth_grad_config': {'noise_sigma': 0.11660000000000001, 'feature_noise_sigma': {'noise_sigma': [{'name': 'name_value', 'sigma': 0.529}]}, 'noisy_sample_count': 1947}, 'blur_baseline_config': {'max_blur_sigma': 0.1482}}, 'xrai_attribution': {'step_count': 1092, 'smooth_grad_config': {}, 'blur_baseline_config': {}}, 'examples': {'example_gcs_source': {'data_format': 1, 'gcs_source': {'uris': ['uris_value1', 'uris_value2']}}, 'nearest_neighbor_search_config': {'null_value': 0, 'number_value': 0.1285, 'string_value': 'string_value_value', 'bool_value': True, 'struct_value': {'fields': {}}, 'list_value': {'values': {}}}, 'presets': {'query': 1, 'modality': 1}, 'gcs_source': {}, 'neighbor_count': 1494}, 'top_k': 541, 'output_indices': {}}, 'metadata': {'inputs': {}, 'outputs': {}, 'feature_attributions_schema_uri': 'feature_attributions_schema_uri_value', 'latent_space_source': 'latent_space_source_value'}}, 'model_monitoring_schema': {'feature_fields': [{'name': 'name_value', 'data_type': 'data_type_value', 'repeated': True}], 'prediction_fields': {}, 'ground_truth_fields': {}}, 'create_time': {}, 'update_time': {}, 'satisfies_pzs': True, 'satisfies_pzi': True}
    # The version of a generated dependency at test runtime may differ from the version used during generation.
    # Delete any fields which are not present in the current runtime dependency
    # See https://github.com/googleapis/gapic-generator-python/issues/1748

    # Determine if the message type is proto-plus or protobuf
    test_field = model_monitoring_service.CreateModelMonitorRequest.meta.fields["model_monitor"]

    def get_message_fields(field):
        # Given a field which is a message (composite type), return a list with
        # all the fields of the message.
        # If the field is not a composite type, return an empty list.
        message_fields = []

        if hasattr(field, "message") and field.message:
            is_field_type_proto_plus_type = not hasattr(field.message, "DESCRIPTOR")

            if is_field_type_proto_plus_type:
                message_fields = field.message.meta.fields.values()
            # Add `# pragma: NO COVER` because there may not be any `*_pb2` field types
            else: # pragma: NO COVER
                message_fields = field.message.DESCRIPTOR.fields
        return message_fields

    runtime_nested_fields = [
        (field.name, nested_field.name)
        for field in get_message_fields(test_field)
        for nested_field in get_message_fields(field)
    ]

    subfields_not_in_runtime = []

    # For each item in the sample request, create a list of sub fields which are not present at runtime
    # Add `# pragma: NO COVER` because this test code will not run if all subfields are present at runtime
    for field, value in request_init["model_monitor"].items(): # pragma: NO COVER
        result = None
        is_repeated = False
        # For repeated fields
        if isinstance(value, list) and len(value):
            is_repeated = True
            result = value[0]
        # For fields where the type is another message
        if isinstance(value, dict):
            result = value

        if result and hasattr(result, "keys"):
            for subfield in result.keys():
                if (field, subfield) not in runtime_nested_fields:
                    subfields_not_in_runtime.append(
                        {"field": field, "subfield": subfield, "is_repeated": is_repeated}
                    )

    # Remove fields from the sample request which are not present in the runtime version of the dependency
    # Add `# pragma: NO COVER` because this test code will not run if all subfields are present at runtime
    for subfield_to_delete in subfields_not_in_runtime: # pragma: NO COVER
        field = subfield_to_delete.get("field")
        field_repeated = subfield_to_delete.get("is_repeated")
        subfield = subfield_to_delete.get("subfield")
        if subfield:
            if field_repeated:
                for i in range(0, len(request_init["model_monitor"][field])):
                    del request_init["model_monitor"][field][i][subfield]
            else:
                del request_init["model_monitor"][field][subfield]
    request = request_type(**request_init)

    # Mock the http request call within the method and fake a response.
    with mock.patch.object(type(client.transport._session), 'request') as req:
        # Designate an appropriate value for the returned response.
        return_value = operations_pb2.Operation(name='operations/spam')

        # Wrap the value into a proper Response obj
        response_value = mock.Mock()
        response_value.status_code = 200
        json_return_value = json_format.MessageToJson(return_value)
        response_value.read = mock.AsyncMock(return_value=json_return_value.encode('UTF-8'))
        req.return_value = response_value
        response = await client.create_model_monitor(request)

    # Establish that the response is the type that we expect.
    json_return_value = json_format.MessageToJson(return_value)


@pytest.mark.asyncio
@pytest.mark.parametrize("null_interceptor", [True, False])
async def test_create_model_monitor_rest_asyncio_interceptors(null_interceptor):
    if not HAS_ASYNC_REST_EXTRA:
        pytest.skip("the library must be installed with the `async_rest` extra to test this feature.")
    transport = transports.AsyncModelMonitoringServiceRestTransport(
        credentials=async_anonymous_credentials(),
        interceptor=None if null_interceptor else transports.AsyncModelMonitoringServiceRestInterceptor(),
        )
    client = ModelMonitoringServiceAsyncClient(transport=transport)

    with mock.patch.object(type(client.transport._session), "request") as req, \
        mock.patch.object(path_template, "transcode")  as transcode, \
        mock.patch.object(operation.Operation, "_set_result_from_operation"), \
        mock.patch.object(transports.AsyncModelMonitoringServiceRestInterceptor, "post_create_model_monitor") as post, \
        mock.patch.object(transports.AsyncModelMonitoringServiceRestInterceptor, "pre_create_model_monitor") as pre:
        pre.assert_not_called()
        post.assert_not_called()
        pb_message = model_monitoring_service.CreateModelMonitorRequest.pb(model_monitoring_service.CreateModelMonitorRequest())
        transcode.return_value = {
            "method": "post",
            "uri": "my_uri",
            "body": pb_message,
            "query_params": pb_message,
        }

        req.return_value = mock.Mock()
        req.return_value.status_code = 200
        return_value = json_format.MessageToJson(operations_pb2.Operation())
        req.return_value.read = mock.AsyncMock(return_value=return_value)

        request = model_monitoring_service.CreateModelMonitorRequest()
        metadata =[
            ("key", "val"),
            ("cephalopod", "squid"),
        ]
        pre.return_value = request, metadata
        post.return_value = operations_pb2.Operation()

        await client.create_model_monitor(request, metadata=[("key", "val"), ("cephalopod", "squid"),])

        pre.assert_called_once()
        post.assert_called_once()

@pytest.mark.asyncio
async def test_update_model_monitor_rest_asyncio_bad_request(request_type=model_monitoring_service.UpdateModelMonitorRequest):
    if not HAS_ASYNC_REST_EXTRA:
        pytest.skip("the library must be installed with the `async_rest` extra to test this feature.")
    client = ModelMonitoringServiceAsyncClient(
        credentials=async_anonymous_credentials(),
        transport="rest_asyncio"
    )
    # send a request that will satisfy transcoding
    request_init = {'model_monitor': {'name': 'projects/sample1/locations/sample2/modelMonitors/sample3'}}
    request = request_type(**request_init)

    # Mock the http request call within the method and fake a BadRequest error.
    with mock.patch.object(AsyncAuthorizedSession, 'request') as req, pytest.raises(core_exceptions.BadRequest):
        # Wrap the value into a proper Response obj
        response_value = mock.Mock()
        response_value.read = mock.AsyncMock(return_value=b'{}')
        response_value.status_code = 400
        response_value.request = mock.Mock()
        req.return_value = response_value
        await client.update_model_monitor(request)


@pytest.mark.asyncio
@pytest.mark.parametrize("request_type", [
  model_monitoring_service.UpdateModelMonitorRequest,
  dict,
])
async def test_update_model_monitor_rest_asyncio_call_success(request_type):
    if not HAS_ASYNC_REST_EXTRA:
        pytest.skip("the library must be installed with the `async_rest` extra to test this feature.")
    client = ModelMonitoringServiceAsyncClient(
        credentials=async_anonymous_credentials(),
        transport="rest_asyncio"
    )

    # send a request that will satisfy transcoding
    request_init = {'model_monitor': {'name': 'projects/sample1/locations/sample2/modelMonitors/sample3'}}
    request_init["model_monitor"] = {'tabular_objective': {'feature_drift_spec': {'features': ['features_value1', 'features_value2'], 'categorical_metric_type': 'categorical_metric_type_value', 'numeric_metric_type': 'numeric_metric_type_value', 'default_categorical_alert_condition': {'threshold': 0.973}, 'default_numeric_alert_condition': {}, 'feature_alert_conditions': {}}, 'prediction_output_drift_spec': {}, 'feature_attribution_spec': {'features': ['features_value1', 'features_value2'], 'default_alert_condition': {}, 'feature_alert_conditions': {}, 'batch_explanation_dedicated_resources': {'machine_spec': {'machine_type': 'machine_type_value', 'accelerator_type': 1, 'accelerator_count': 1805, 'tpu_topology': 'tpu_topology_value', 'reservation_affinity': {'reservation_affinity_type': 1, 'key': 'key_value', 'values': ['values_value1', 'values_value2']}}, 'starting_replica_count': 2355, 'max_replica_count': 1805}}}, 'name': 'projects/sample1/locations/sample2/modelMonitors/sample3', 'display_name': 'display_name_value', 'model_monitoring_target': {'vertex_model': {'model': 'model_value', 'model_version_id': 'model_version_id_value'}}, 'training_dataset': {'columnized_dataset': {'vertex_dataset': 'vertex_dataset_value', 'gcs_source': {'gcs_uri': 'gcs_uri_value', 'format_': 1}, 'bigquery_source': {'table_uri': 'table_uri_value', 'query': 'query_value'}, 'timestamp_field': 'timestamp_field_value'}, 'batch_prediction_output': {'batch_prediction_job': 'batch_prediction_job_value'}, 'vertex_endpoint_logs': {'endpoints': ['endpoints_value1', 'endpoints_value2']}, 'time_interval': {'start_time': {'seconds': 751, 'nanos': 543}, 'end_time': {}}, 'time_offset': {'offset': 'offset_value', 'window': 'window_value'}}, 'notification_spec': {'email_config': {'user_emails': ['user_emails_value1', 'user_emails_value2']}, 'enable_cloud_logging': True, 'notification_channel_configs': [{'notification_channel': 'notification_channel_value'}]}, 'output_spec': {'gcs_base_directory': {'output_uri_prefix': 'output_uri_prefix_value'}}, 'explanation_spec': {'parameters': {'sampled_shapley_attribution': {'path_count': 1077}, 'integrated_gradients_attribution': {'step_count': 1092, 'smooth_grad_config': {'noise_sigma': 0.11660000000000001, 'feature_noise_sigma': {'noise_sigma': [{'name': 'name_value', 'sigma': 0.529}]}, 'noisy_sample_count': 1947}, 'blur_baseline_config': {'max_blur_sigma': 0.1482}}, 'xrai_attribution': {'step_count': 1092, 'smooth_grad_config': {}, 'blur_baseline_config': {}}, 'examples': {'example_gcs_source': {'data_format': 1, 'gcs_source': {'uris': ['uris_value1', 'uris_value2']}}, 'nearest_neighbor_search_config': {'null_value': 0, 'number_value': 0.1285, 'string_value': 'string_value_value', 'bool_value': True, 'struct_value': {'fields': {}}, 'list_value': {'values': {}}}, 'presets': {'query': 1, 'modality': 1}, 'gcs_source': {}, 'neighbor_count': 1494}, 'top_k': 541, 'output_indices': {}}, 'metadata': {'inputs': {}, 'outputs': {}, 'feature_attributions_schema_uri': 'feature_attributions_schema_uri_value', 'latent_space_source': 'latent_space_source_value'}}, 'model_monitoring_schema': {'feature_fields': [{'name': 'name_value', 'data_type': 'data_type_value', 'repeated': True}], 'prediction_fields': {}, 'ground_truth_fields': {}}, 'create_time': {}, 'update_time': {}, 'satisfies_pzs': True, 'satisfies_pzi': True}
    # The version of a generated dependency at test runtime may differ from the version used during generation.
    # Delete any fields which are not present in the current runtime dependency
    # See https://github.com/googleapis/gapic-generator-python/issues/1748

    # Determine if the message type is proto-plus or protobuf
    test_field = model_monitoring_service.UpdateModelMonitorRequest.meta.fields["model_monitor"]

    def get_message_fields(field):
        # Given a field which is a message (composite type), return a list with
        # all the fields of the message.
        # If the field is not a composite type, return an empty list.
        message_fields = []

        if hasattr(field, "message") and field.message:
            is_field_type_proto_plus_type = not hasattr(field.message, "DESCRIPTOR")

            if is_field_type_proto_plus_type:
                message_fields = field.message.meta.fields.values()
            # Add `# pragma: NO COVER` because there may not be any `*_pb2` field types
            else: # pragma: NO COVER
                message_fields = field.message.DESCRIPTOR.fields
        return message_fields

    runtime_nested_fields = [
        (field.name, nested_field.name)
        for field in get_message_fields(test_field)
        for nested_field in get_message_fields(field)
    ]

    subfields_not_in_runtime = []

    # For each item in the sample request, create a list of sub fields which are not present at runtime
    # Add `# pragma: NO COVER` because this test code will not run if all subfields are present at runtime
    for field, value in request_init["model_monitor"].items(): # pragma: NO COVER
        result = None
        is_repeated = False
        # For repeated fields
        if isinstance(value, list) and len(value):
            is_repeated = True
            result = value[0]
        # For fields where the type is another message
        if isinstance(value, dict):
            result = value

        if result and hasattr(result, "keys"):
            for subfield in result.keys():
                if (field, subfield) not in runtime_nested_fields:
                    subfields_not_in_runtime.append(
                        {"field": field, "subfield": subfield, "is_repeated": is_repeated}
                    )

    # Remove fields from the sample request which are not present in the runtime version of the dependency
    # Add `# pragma: NO COVER` because this test code will not run if all subfields are present at runtime
    for subfield_to_delete in subfields_not_in_runtime: # pragma: NO COVER
        field = subfield_to_delete.get("field")
        field_repeated = subfield_to_delete.get("is_repeated")
        subfield = subfield_to_delete.get("subfield")
        if subfield:
            if field_repeated:
                for i in range(0, len(request_init["model_monitor"][field])):
                    del request_init["model_monitor"][field][i][subfield]
            else:
                del request_init["model_monitor"][field][subfield]
    request = request_type(**request_init)

    # Mock the http request call within the method and fake a response.
    with mock.patch.object(type(client.transport._session), 'request') as req:
        # Designate an appropriate value for the returned response.
        return_value = operations_pb2.Operation(name='operations/spam')

        # Wrap the value into a proper Response obj
        response_value = mock.Mock()
        response_value.status_code = 200
        json_return_value = json_format.MessageToJson(return_value)
        response_value.read = mock.AsyncMock(return_value=json_return_value.encode('UTF-8'))
        req.return_value = response_value
        response = await client.update_model_monitor(request)

    # Establish that the response is the type that we expect.
    json_return_value = json_format.MessageToJson(return_value)


@pytest.mark.asyncio
@pytest.mark.parametrize("null_interceptor", [True, False])
async def test_update_model_monitor_rest_asyncio_interceptors(null_interceptor):
    if not HAS_ASYNC_REST_EXTRA:
        pytest.skip("the library must be installed with the `async_rest` extra to test this feature.")
    transport = transports.AsyncModelMonitoringServiceRestTransport(
        credentials=async_anonymous_credentials(),
        interceptor=None if null_interceptor else transports.AsyncModelMonitoringServiceRestInterceptor(),
        )
    client = ModelMonitoringServiceAsyncClient(transport=transport)

    with mock.patch.object(type(client.transport._session), "request") as req, \
        mock.patch.object(path_template, "transcode")  as transcode, \
        mock.patch.object(operation.Operation, "_set_result_from_operation"), \
        mock.patch.object(transports.AsyncModelMonitoringServiceRestInterceptor, "post_update_model_monitor") as post, \
        mock.patch.object(transports.AsyncModelMonitoringServiceRestInterceptor, "pre_update_model_monitor") as pre:
        pre.assert_not_called()
        post.assert_not_called()
        pb_message = model_monitoring_service.UpdateModelMonitorRequest.pb(model_monitoring_service.UpdateModelMonitorRequest())
        transcode.return_value = {
            "method": "post",
            "uri": "my_uri",
            "body": pb_message,
            "query_params": pb_message,
        }

        req.return_value = mock.Mock()
        req.return_value.status_code = 200
        return_value = json_format.MessageToJson(operations_pb2.Operation())
        req.return_value.read = mock.AsyncMock(return_value=return_value)

        request = model_monitoring_service.UpdateModelMonitorRequest()
        metadata =[
            ("key", "val"),
            ("cephalopod", "squid"),
        ]
        pre.return_value = request, metadata
        post.return_value = operations_pb2.Operation()

        await client.update_model_monitor(request, metadata=[("key", "val"), ("cephalopod", "squid"),])

        pre.assert_called_once()
        post.assert_called_once()

@pytest.mark.asyncio
async def test_get_model_monitor_rest_asyncio_bad_request(request_type=model_monitoring_service.GetModelMonitorRequest):
    if not HAS_ASYNC_REST_EXTRA:
        pytest.skip("the library must be installed with the `async_rest` extra to test this feature.")
    client = ModelMonitoringServiceAsyncClient(
        credentials=async_anonymous_credentials(),
        transport="rest_asyncio"
    )
    # send a request that will satisfy transcoding
    request_init = {'name': 'projects/sample1/locations/sample2/modelMonitors/sample3'}
    request = request_type(**request_init)

    # Mock the http request call within the method and fake a BadRequest error.
    with mock.patch.object(AsyncAuthorizedSession, 'request') as req, pytest.raises(core_exceptions.BadRequest):
        # Wrap the value into a proper Response obj
        response_value = mock.Mock()
        response_value.read = mock.AsyncMock(return_value=b'{}')
        response_value.status_code = 400
        response_value.request = mock.Mock()
        req.return_value = response_value
        await client.get_model_monitor(request)


@pytest.mark.asyncio
@pytest.mark.parametrize("request_type", [
  model_monitoring_service.GetModelMonitorRequest,
  dict,
])
async def test_get_model_monitor_rest_asyncio_call_success(request_type):
    if not HAS_ASYNC_REST_EXTRA:
        pytest.skip("the library must be installed with the `async_rest` extra to test this feature.")
    client = ModelMonitoringServiceAsyncClient(
        credentials=async_anonymous_credentials(),
        transport="rest_asyncio"
    )

    # send a request that will satisfy transcoding
    request_init = {'name': 'projects/sample1/locations/sample2/modelMonitors/sample3'}
    request = request_type(**request_init)

    # Mock the http request call within the method and fake a response.
    with mock.patch.object(type(client.transport._session), 'request') as req:
        # Designate an appropriate value for the returned response.
        return_value = model_monitor.ModelMonitor(
              name='name_value',
              display_name='display_name_value',
              satisfies_pzs=True,
              satisfies_pzi=True,
        )

        # Wrap the value into a proper Response obj
        response_value = mock.Mock()
        response_value.status_code = 200

        # Convert return value to protobuf type
        return_value = model_monitor.ModelMonitor.pb(return_value)
        json_return_value = json_format.MessageToJson(return_value)
        response_value.read = mock.AsyncMock(return_value=json_return_value.encode('UTF-8'))
        req.return_value = response_value
        response = await client.get_model_monitor(request)

    # Establish that the response is the type that we expect.
    assert isinstance(response, model_monitor.ModelMonitor)
    assert response.name == 'name_value'
    assert response.display_name == 'display_name_value'
    assert response.satisfies_pzs is True
    assert response.satisfies_pzi is True


@pytest.mark.asyncio
@pytest.mark.parametrize("null_interceptor", [True, False])
async def test_get_model_monitor_rest_asyncio_interceptors(null_interceptor):
    if not HAS_ASYNC_REST_EXTRA:
        pytest.skip("the library must be installed with the `async_rest` extra to test this feature.")
    transport = transports.AsyncModelMonitoringServiceRestTransport(
        credentials=async_anonymous_credentials(),
        interceptor=None if null_interceptor else transports.AsyncModelMonitoringServiceRestInterceptor(),
        )
    client = ModelMonitoringServiceAsyncClient(transport=transport)

    with mock.patch.object(type(client.transport._session), "request") as req, \
        mock.patch.object(path_template, "transcode")  as transcode, \
        mock.patch.object(transports.AsyncModelMonitoringServiceRestInterceptor, "post_get_model_monitor") as post, \
        mock.patch.object(transports.AsyncModelMonitoringServiceRestInterceptor, "pre_get_model_monitor") as pre:
        pre.assert_not_called()
        post.assert_not_called()
        pb_message = model_monitoring_service.GetModelMonitorRequest.pb(model_monitoring_service.GetModelMonitorRequest())
        transcode.return_value = {
            "method": "post",
            "uri": "my_uri",
            "body": pb_message,
            "query_params": pb_message,
        }

        req.return_value = mock.Mock()
        req.return_value.status_code = 200
        return_value = model_monitor.ModelMonitor.to_json(model_monitor.ModelMonitor())
        req.return_value.read = mock.AsyncMock(return_value=return_value)

        request = model_monitoring_service.GetModelMonitorRequest()
        metadata =[
            ("key", "val"),
            ("cephalopod", "squid"),
        ]
        pre.return_value = request, metadata
        post.return_value = model_monitor.ModelMonitor()

        await client.get_model_monitor(request, metadata=[("key", "val"), ("cephalopod", "squid"),])

        pre.assert_called_once()
        post.assert_called_once()

@pytest.mark.asyncio
async def test_list_model_monitors_rest_asyncio_bad_request(request_type=model_monitoring_service.ListModelMonitorsRequest):
    if not HAS_ASYNC_REST_EXTRA:
        pytest.skip("the library must be installed with the `async_rest` extra to test this feature.")
    client = ModelMonitoringServiceAsyncClient(
        credentials=async_anonymous_credentials(),
        transport="rest_asyncio"
    )
    # send a request that will satisfy transcoding
    request_init = {'parent': 'projects/sample1/locations/sample2'}
    request = request_type(**request_init)

    # Mock the http request call within the method and fake a BadRequest error.
    with mock.patch.object(AsyncAuthorizedSession, 'request') as req, pytest.raises(core_exceptions.BadRequest):
        # Wrap the value into a proper Response obj
        response_value = mock.Mock()
        response_value.read = mock.AsyncMock(return_value=b'{}')
        response_value.status_code = 400
        response_value.request = mock.Mock()
        req.return_value = response_value
        await client.list_model_monitors(request)


@pytest.mark.asyncio
@pytest.mark.parametrize("request_type", [
  model_monitoring_service.ListModelMonitorsRequest,
  dict,
])
async def test_list_model_monitors_rest_asyncio_call_success(request_type):
    if not HAS_ASYNC_REST_EXTRA:
        pytest.skip("the library must be installed with the `async_rest` extra to test this feature.")
    client = ModelMonitoringServiceAsyncClient(
        credentials=async_anonymous_credentials(),
        transport="rest_asyncio"
    )

    # send a request that will satisfy transcoding
    request_init = {'parent': 'projects/sample1/locations/sample2'}
    request = request_type(**request_init)

    # Mock the http request call within the method and fake a response.
    with mock.patch.object(type(client.transport._session), 'request') as req:
        # Designate an appropriate value for the returned response.
        return_value = model_monitoring_service.ListModelMonitorsResponse(
              next_page_token='next_page_token_value',
        )

        # Wrap the value into a proper Response obj
        response_value = mock.Mock()
        response_value.status_code = 200

        # Convert return value to protobuf type
        return_value = model_monitoring_service.ListModelMonitorsResponse.pb(return_value)
        json_return_value = json_format.MessageToJson(return_value)
        response_value.read = mock.AsyncMock(return_value=json_return_value.encode('UTF-8'))
        req.return_value = response_value
        response = await client.list_model_monitors(request)

    # Establish that the response is the type that we expect.
    assert isinstance(response, pagers.ListModelMonitorsAsyncPager)
    assert response.next_page_token == 'next_page_token_value'


@pytest.mark.asyncio
@pytest.mark.parametrize("null_interceptor", [True, False])
async def test_list_model_monitors_rest_asyncio_interceptors(null_interceptor):
    if not HAS_ASYNC_REST_EXTRA:
        pytest.skip("the library must be installed with the `async_rest` extra to test this feature.")
    transport = transports.AsyncModelMonitoringServiceRestTransport(
        credentials=async_anonymous_credentials(),
        interceptor=None if null_interceptor else transports.AsyncModelMonitoringServiceRestInterceptor(),
        )
    client = ModelMonitoringServiceAsyncClient(transport=transport)

    with mock.patch.object(type(client.transport._session), "request") as req, \
        mock.patch.object(path_template, "transcode")  as transcode, \
        mock.patch.object(transports.AsyncModelMonitoringServiceRestInterceptor, "post_list_model_monitors") as post, \
        mock.patch.object(transports.AsyncModelMonitoringServiceRestInterceptor, "pre_list_model_monitors") as pre:
        pre.assert_not_called()
        post.assert_not_called()
        pb_message = model_monitoring_service.ListModelMonitorsRequest.pb(model_monitoring_service.ListModelMonitorsRequest())
        transcode.return_value = {
            "method": "post",
            "uri": "my_uri",
            "body": pb_message,
            "query_params": pb_message,
        }

        req.return_value = mock.Mock()
        req.return_value.status_code = 200
        return_value = model_monitoring_service.ListModelMonitorsResponse.to_json(model_monitoring_service.ListModelMonitorsResponse())
        req.return_value.read = mock.AsyncMock(return_value=return_value)

        request = model_monitoring_service.ListModelMonitorsRequest()
        metadata =[
            ("key", "val"),
            ("cephalopod", "squid"),
        ]
        pre.return_value = request, metadata
        post.return_value = model_monitoring_service.ListModelMonitorsResponse()

        await client.list_model_monitors(request, metadata=[("key", "val"), ("cephalopod", "squid"),])

        pre.assert_called_once()
        post.assert_called_once()

@pytest.mark.asyncio
async def test_delete_model_monitor_rest_asyncio_bad_request(request_type=model_monitoring_service.DeleteModelMonitorRequest):
    if not HAS_ASYNC_REST_EXTRA:
        pytest.skip("the library must be installed with the `async_rest` extra to test this feature.")
    client = ModelMonitoringServiceAsyncClient(
        credentials=async_anonymous_credentials(),
        transport="rest_asyncio"
    )
    # send a request that will satisfy transcoding
    request_init = {'name': 'projects/sample1/locations/sample2/modelMonitors/sample3'}
    request = request_type(**request_init)

    # Mock the http request call within the method and fake a BadRequest error.
    with mock.patch.object(AsyncAuthorizedSession, 'request') as req, pytest.raises(core_exceptions.BadRequest):
        # Wrap the value into a proper Response obj
        response_value = mock.Mock()
        response_value.read = mock.AsyncMock(return_value=b'{}')
        response_value.status_code = 400
        response_value.request = mock.Mock()
        req.return_value = response_value
        await client.delete_model_monitor(request)


@pytest.mark.asyncio
@pytest.mark.parametrize("request_type", [
  model_monitoring_service.DeleteModelMonitorRequest,
  dict,
])
async def test_delete_model_monitor_rest_asyncio_call_success(request_type):
    if not HAS_ASYNC_REST_EXTRA:
        pytest.skip("the library must be installed with the `async_rest` extra to test this feature.")
    client = ModelMonitoringServiceAsyncClient(
        credentials=async_anonymous_credentials(),
        transport="rest_asyncio"
    )

    # send a request that will satisfy transcoding
    request_init = {'name': 'projects/sample1/locations/sample2/modelMonitors/sample3'}
    request = request_type(**request_init)

    # Mock the http request call within the method and fake a response.
    with mock.patch.object(type(client.transport._session), 'request') as req:
        # Designate an appropriate value for the returned response.
        return_value = operations_pb2.Operation(name='operations/spam')

        # Wrap the value into a proper Response obj
        response_value = mock.Mock()
        response_value.status_code = 200
        json_return_value = json_format.MessageToJson(return_value)
        response_value.read = mock.AsyncMock(return_value=json_return_value.encode('UTF-8'))
        req.return_value = response_value
        response = await client.delete_model_monitor(request)

    # Establish that the response is the type that we expect.
    json_return_value = json_format.MessageToJson(return_value)


@pytest.mark.asyncio
@pytest.mark.parametrize("null_interceptor", [True, False])
async def test_delete_model_monitor_rest_asyncio_interceptors(null_interceptor):
    if not HAS_ASYNC_REST_EXTRA:
        pytest.skip("the library must be installed with the `async_rest` extra to test this feature.")
    transport = transports.AsyncModelMonitoringServiceRestTransport(
        credentials=async_anonymous_credentials(),
        interceptor=None if null_interceptor else transports.AsyncModelMonitoringServiceRestInterceptor(),
        )
    client = ModelMonitoringServiceAsyncClient(transport=transport)

    with mock.patch.object(type(client.transport._session), "request") as req, \
        mock.patch.object(path_template, "transcode")  as transcode, \
        mock.patch.object(operation.Operation, "_set_result_from_operation"), \
        mock.patch.object(transports.AsyncModelMonitoringServiceRestInterceptor, "post_delete_model_monitor") as post, \
        mock.patch.object(transports.AsyncModelMonitoringServiceRestInterceptor, "pre_delete_model_monitor") as pre:
        pre.assert_not_called()
        post.assert_not_called()
        pb_message = model_monitoring_service.DeleteModelMonitorRequest.pb(model_monitoring_service.DeleteModelMonitorRequest())
        transcode.return_value = {
            "method": "post",
            "uri": "my_uri",
            "body": pb_message,
            "query_params": pb_message,
        }

        req.return_value = mock.Mock()
        req.return_value.status_code = 200
        return_value = json_format.MessageToJson(operations_pb2.Operation())
        req.return_value.read = mock.AsyncMock(return_value=return_value)

        request = model_monitoring_service.DeleteModelMonitorRequest()
        metadata =[
            ("key", "val"),
            ("cephalopod", "squid"),
        ]
        pre.return_value = request, metadata
        post.return_value = operations_pb2.Operation()

        await client.delete_model_monitor(request, metadata=[("key", "val"), ("cephalopod", "squid"),])

        pre.assert_called_once()
        post.assert_called_once()

@pytest.mark.asyncio
async def test_create_model_monitoring_job_rest_asyncio_bad_request(request_type=model_monitoring_service.CreateModelMonitoringJobRequest):
    if not HAS_ASYNC_REST_EXTRA:
        pytest.skip("the library must be installed with the `async_rest` extra to test this feature.")
    client = ModelMonitoringServiceAsyncClient(
        credentials=async_anonymous_credentials(),
        transport="rest_asyncio"
    )
    # send a request that will satisfy transcoding
    request_init = {'parent': 'projects/sample1/locations/sample2/modelMonitors/sample3'}
    request = request_type(**request_init)

    # Mock the http request call within the method and fake a BadRequest error.
    with mock.patch.object(AsyncAuthorizedSession, 'request') as req, pytest.raises(core_exceptions.BadRequest):
        # Wrap the value into a proper Response obj
        response_value = mock.Mock()
        response_value.read = mock.AsyncMock(return_value=b'{}')
        response_value.status_code = 400
        response_value.request = mock.Mock()
        req.return_value = response_value
        await client.create_model_monitoring_job(request)


@pytest.mark.asyncio
@pytest.mark.parametrize("request_type", [
  model_monitoring_service.CreateModelMonitoringJobRequest,
  dict,
])
async def test_create_model_monitoring_job_rest_asyncio_call_success(request_type):
    if not HAS_ASYNC_REST_EXTRA:
        pytest.skip("the library must be installed with the `async_rest` extra to test this feature.")
    client = ModelMonitoringServiceAsyncClient(
        credentials=async_anonymous_credentials(),
        transport="rest_asyncio"
    )

    # send a request that will satisfy transcoding
    request_init = {'parent': 'projects/sample1/locations/sample2/modelMonitors/sample3'}
    request_init["model_monitoring_job"] = {'name': 'name_value', 'display_name': 'display_name_value', 'model_monitoring_spec': {'objective_spec': {'tabular_objective': {'feature_drift_spec': {'features': ['features_value1', 'features_value2'], 'categorical_metric_type': 'categorical_metric_type_value', 'numeric_metric_type': 'numeric_metric_type_value', 'default_categorical_alert_condition': {'threshold': 0.973}, 'default_numeric_alert_condition': {}, 'feature_alert_conditions': {}}, 'prediction_output_drift_spec': {}, 'feature_attribution_spec': {'features': ['features_value1', 'features_value2'], 'default_alert_condition': {}, 'feature_alert_conditions': {}, 'batch_explanation_dedicated_resources': {'machine_spec': {'machine_type': 'machine_type_value', 'accelerator_type': 1, 'accelerator_count': 1805, 'tpu_topology': 'tpu_topology_value', 'reservation_affinity': {'reservation_affinity_type': 1, 'key': 'key_value', 'values': ['values_value1', 'values_value2']}}, 'starting_replica_count': 2355, 'max_replica_count': 1805}}}, 'explanation_spec': {'parameters': {'sampled_shapley_attribution': {'path_count': 1077}, 'integrated_gradients_attribution': {'step_count': 1092, 'smooth_grad_config': {'noise_sigma': 0.11660000000000001, 'feature_noise_sigma': {'noise_sigma': [{'name': 'name_value', 'sigma': 0.529}]}, 'noisy_sample_count': 1947}, 'blur_baseline_config': {'max_blur_sigma': 0.1482}}, 'xrai_attribution': {'step_count': 1092, 'smooth_grad_config': {}, 'blur_baseline_config': {}}, 'examples': {'example_gcs_source': {'data_format': 1, 'gcs_source': {'uris': ['uris_value1', 'uris_value2']}}, 'nearest_neighbor_search_config': {'null_value': 0, 'number_value': 0.1285, 'string_value': 'string_value_value', 'bool_value': True, 'struct_value': {'fields': {}}, 'list_value': {'values': {}}}, 'presets': {'query': 1, 'modality': 1}, 'gcs_source': {}, 'neighbor_count': 1494}, 'top_k': 541, 'output_indices': {}}, 'metadata': {'inputs': {}, 'outputs': {}, 'feature_attributions_schema_uri': 'feature_attributions_schema_uri_value', 'latent_space_source': 'latent_space_source_value'}}, 'baseline_dataset': {'columnized_dataset': {'vertex_dataset': 'vertex_dataset_value', 'gcs_source': {'gcs_uri': 'gcs_uri_value', 'format_': 1}, 'bigquery_source': {'table_uri': 'table_uri_value', 'query': 'query_value'}, 'timestamp_field': 'timestamp_field_value'}, 'batch_prediction_output': {'batch_prediction_job': 'batch_prediction_job_value'}, 'vertex_endpoint_logs': {'endpoints': ['endpoints_value1', 'endpoints_value2']}, 'time_interval': {'start_time': {'seconds': 751, 'nanos': 543}, 'end_time': {}}, 'time_offset': {'offset': 'offset_value', 'window': 'window_value'}}, 'target_dataset': {}}, 'notification_spec': {'email_config': {'user_emails': ['user_emails_value1', 'user_emails_value2']}, 'enable_cloud_logging': True, 'notification_channel_configs': [{'notification_channel': 'notification_channel_value'}]}, 'output_spec': {'gcs_base_directory': {'output_uri_prefix': 'output_uri_prefix_value'}}}, 'create_time': {}, 'update_time': {}, 'state': 1, 'schedule': 'schedule_value', 'job_execution_detail': {'baseline_datasets': [{'location': 'location_value', 'time_range': {}}], 'target_datasets': {}, 'objective_status': {}, 'error': {'code': 411, 'message': 'message_value', 'details': [{'type_url': 'type.googleapis.com/google.protobuf.Duration', 'value': b'\x08\x0c\x10\xdb\x07'}]}}, 'schedule_time': {}}
    # The version of a generated dependency at test runtime may differ from the version used during generation.
    # Delete any fields which are not present in the current runtime dependency
    # See https://github.com/googleapis/gapic-generator-python/issues/1748

    # Determine if the message type is proto-plus or protobuf
    test_field = model_monitoring_service.CreateModelMonitoringJobRequest.meta.fields["model_monitoring_job"]

    def get_message_fields(field):
        # Given a field which is a message (composite type), return a list with
        # all the fields of the message.
        # If the field is not a composite type, return an empty list.
        message_fields = []

        if hasattr(field, "message") and field.message:
            is_field_type_proto_plus_type = not hasattr(field.message, "DESCRIPTOR")

            if is_field_type_proto_plus_type:
                message_fields = field.message.meta.fields.values()
            # Add `# pragma: NO COVER` because there may not be any `*_pb2` field types
            else: # pragma: NO COVER
                message_fields = field.message.DESCRIPTOR.fields
        return message_fields

    runtime_nested_fields = [
        (field.name, nested_field.name)
        for field in get_message_fields(test_field)
        for nested_field in get_message_fields(field)
    ]

    subfields_not_in_runtime = []

    # For each item in the sample request, create a list of sub fields which are not present at runtime
    # Add `# pragma: NO COVER` because this test code will not run if all subfields are present at runtime
    for field, value in request_init["model_monitoring_job"].items(): # pragma: NO COVER
        result = None
        is_repeated = False
        # For repeated fields
        if isinstance(value, list) and len(value):
            is_repeated = True
            result = value[0]
        # For fields where the type is another message
        if isinstance(value, dict):
            result = value

        if result and hasattr(result, "keys"):
            for subfield in result.keys():
                if (field, subfield) not in runtime_nested_fields:
                    subfields_not_in_runtime.append(
                        {"field": field, "subfield": subfield, "is_repeated": is_repeated}
                    )

    # Remove fields from the sample request which are not present in the runtime version of the dependency
    # Add `# pragma: NO COVER` because this test code will not run if all subfields are present at runtime
    for subfield_to_delete in subfields_not_in_runtime: # pragma: NO COVER
        field = subfield_to_delete.get("field")
        field_repeated = subfield_to_delete.get("is_repeated")
        subfield = subfield_to_delete.get("subfield")
        if subfield:
            if field_repeated:
                for i in range(0, len(request_init["model_monitoring_job"][field])):
                    del request_init["model_monitoring_job"][field][i][subfield]
            else:
                del request_init["model_monitoring_job"][field][subfield]
    request = request_type(**request_init)

    # Mock the http request call within the method and fake a response.
    with mock.patch.object(type(client.transport._session), 'request') as req:
        # Designate an appropriate value for the returned response.
        return_value = gca_model_monitoring_job.ModelMonitoringJob(
              name='name_value',
              display_name='display_name_value',
              state=job_state.JobState.JOB_STATE_QUEUED,
              schedule='schedule_value',
        )

        # Wrap the value into a proper Response obj
        response_value = mock.Mock()
        response_value.status_code = 200

        # Convert return value to protobuf type
        return_value = gca_model_monitoring_job.ModelMonitoringJob.pb(return_value)
        json_return_value = json_format.MessageToJson(return_value)
        response_value.read = mock.AsyncMock(return_value=json_return_value.encode('UTF-8'))
        req.return_value = response_value
        response = await client.create_model_monitoring_job(request)

    # Establish that the response is the type that we expect.
    assert isinstance(response, gca_model_monitoring_job.ModelMonitoringJob)
    assert response.name == 'name_value'
    assert response.display_name == 'display_name_value'
    assert response.state == job_state.JobState.JOB_STATE_QUEUED
    assert response.schedule == 'schedule_value'


@pytest.mark.asyncio
@pytest.mark.parametrize("null_interceptor", [True, False])
async def test_create_model_monitoring_job_rest_asyncio_interceptors(null_interceptor):
    if not HAS_ASYNC_REST_EXTRA:
        pytest.skip("the library must be installed with the `async_rest` extra to test this feature.")
    transport = transports.AsyncModelMonitoringServiceRestTransport(
        credentials=async_anonymous_credentials(),
        interceptor=None if null_interceptor else transports.AsyncModelMonitoringServiceRestInterceptor(),
        )
    client = ModelMonitoringServiceAsyncClient(transport=transport)

    with mock.patch.object(type(client.transport._session), "request") as req, \
        mock.patch.object(path_template, "transcode")  as transcode, \
        mock.patch.object(transports.AsyncModelMonitoringServiceRestInterceptor, "post_create_model_monitoring_job") as post, \
        mock.patch.object(transports.AsyncModelMonitoringServiceRestInterceptor, "pre_create_model_monitoring_job") as pre:
        pre.assert_not_called()
        post.assert_not_called()
        pb_message = model_monitoring_service.CreateModelMonitoringJobRequest.pb(model_monitoring_service.CreateModelMonitoringJobRequest())
        transcode.return_value = {
            "method": "post",
            "uri": "my_uri",
            "body": pb_message,
            "query_params": pb_message,
        }

        req.return_value = mock.Mock()
        req.return_value.status_code = 200
        return_value = gca_model_monitoring_job.ModelMonitoringJob.to_json(gca_model_monitoring_job.ModelMonitoringJob())
        req.return_value.read = mock.AsyncMock(return_value=return_value)

        request = model_monitoring_service.CreateModelMonitoringJobRequest()
        metadata =[
            ("key", "val"),
            ("cephalopod", "squid"),
        ]
        pre.return_value = request, metadata
        post.return_value = gca_model_monitoring_job.ModelMonitoringJob()

        await client.create_model_monitoring_job(request, metadata=[("key", "val"), ("cephalopod", "squid"),])

        pre.assert_called_once()
        post.assert_called_once()

@pytest.mark.asyncio
async def test_get_model_monitoring_job_rest_asyncio_bad_request(request_type=model_monitoring_service.GetModelMonitoringJobRequest):
    if not HAS_ASYNC_REST_EXTRA:
        pytest.skip("the library must be installed with the `async_rest` extra to test this feature.")
    client = ModelMonitoringServiceAsyncClient(
        credentials=async_anonymous_credentials(),
        transport="rest_asyncio"
    )
    # send a request that will satisfy transcoding
    request_init = {'name': 'projects/sample1/locations/sample2/modelMonitors/sample3/modelMonitoringJobs/sample4'}
    request = request_type(**request_init)

    # Mock the http request call within the method and fake a BadRequest error.
    with mock.patch.object(AsyncAuthorizedSession, 'request') as req, pytest.raises(core_exceptions.BadRequest):
        # Wrap the value into a proper Response obj
        response_value = mock.Mock()
        response_value.read = mock.AsyncMock(return_value=b'{}')
        response_value.status_code = 400
        response_value.request = mock.Mock()
        req.return_value = response_value
        await client.get_model_monitoring_job(request)


@pytest.mark.asyncio
@pytest.mark.parametrize("request_type", [
  model_monitoring_service.GetModelMonitoringJobRequest,
  dict,
])
async def test_get_model_monitoring_job_rest_asyncio_call_success(request_type):
    if not HAS_ASYNC_REST_EXTRA:
        pytest.skip("the library must be installed with the `async_rest` extra to test this feature.")
    client = ModelMonitoringServiceAsyncClient(
        credentials=async_anonymous_credentials(),
        transport="rest_asyncio"
    )

    # send a request that will satisfy transcoding
    request_init = {'name': 'projects/sample1/locations/sample2/modelMonitors/sample3/modelMonitoringJobs/sample4'}
    request = request_type(**request_init)

    # Mock the http request call within the method and fake a response.
    with mock.patch.object(type(client.transport._session), 'request') as req:
        # Designate an appropriate value for the returned response.
        return_value = model_monitoring_job.ModelMonitoringJob(
              name='name_value',
              display_name='display_name_value',
              state=job_state.JobState.JOB_STATE_QUEUED,
              schedule='schedule_value',
        )

        # Wrap the value into a proper Response obj
        response_value = mock.Mock()
        response_value.status_code = 200

        # Convert return value to protobuf type
        return_value = model_monitoring_job.ModelMonitoringJob.pb(return_value)
        json_return_value = json_format.MessageToJson(return_value)
        response_value.read = mock.AsyncMock(return_value=json_return_value.encode('UTF-8'))
        req.return_value = response_value
        response = await client.get_model_monitoring_job(request)

    # Establish that the response is the type that we expect.
    assert isinstance(response, model_monitoring_job.ModelMonitoringJob)
    assert response.name == 'name_value'
    assert response.display_name == 'display_name_value'
    assert response.state == job_state.JobState.JOB_STATE_QUEUED
    assert response.schedule == 'schedule_value'


@pytest.mark.asyncio
@pytest.mark.parametrize("null_interceptor", [True, False])
async def test_get_model_monitoring_job_rest_asyncio_interceptors(null_interceptor):
    if not HAS_ASYNC_REST_EXTRA:
        pytest.skip("the library must be installed with the `async_rest` extra to test this feature.")
    transport = transports.AsyncModelMonitoringServiceRestTransport(
        credentials=async_anonymous_credentials(),
        interceptor=None if null_interceptor else transports.AsyncModelMonitoringServiceRestInterceptor(),
        )
    client = ModelMonitoringServiceAsyncClient(transport=transport)

    with mock.patch.object(type(client.transport._session), "request") as req, \
        mock.patch.object(path_template, "transcode")  as transcode, \
        mock.patch.object(transports.AsyncModelMonitoringServiceRestInterceptor, "post_get_model_monitoring_job") as post, \
        mock.patch.object(transports.AsyncModelMonitoringServiceRestInterceptor, "pre_get_model_monitoring_job") as pre:
        pre.assert_not_called()
        post.assert_not_called()
        pb_message = model_monitoring_service.GetModelMonitoringJobRequest.pb(model_monitoring_service.GetModelMonitoringJobRequest())
        transcode.return_value = {
            "method": "post",
            "uri": "my_uri",
            "body": pb_message,
            "query_params": pb_message,
        }

        req.return_value = mock.Mock()
        req.return_value.status_code = 200
        return_value = model_monitoring_job.ModelMonitoringJob.to_json(model_monitoring_job.ModelMonitoringJob())
        req.return_value.read = mock.AsyncMock(return_value=return_value)

        request = model_monitoring_service.GetModelMonitoringJobRequest()
        metadata =[
            ("key", "val"),
            ("cephalopod", "squid"),
        ]
        pre.return_value = request, metadata
        post.return_value = model_monitoring_job.ModelMonitoringJob()

        await client.get_model_monitoring_job(request, metadata=[("key", "val"), ("cephalopod", "squid"),])

        pre.assert_called_once()
        post.assert_called_once()

@pytest.mark.asyncio
async def test_list_model_monitoring_jobs_rest_asyncio_bad_request(request_type=model_monitoring_service.ListModelMonitoringJobsRequest):
    if not HAS_ASYNC_REST_EXTRA:
        pytest.skip("the library must be installed with the `async_rest` extra to test this feature.")
    client = ModelMonitoringServiceAsyncClient(
        credentials=async_anonymous_credentials(),
        transport="rest_asyncio"
    )
    # send a request that will satisfy transcoding
    request_init = {'parent': 'projects/sample1/locations/sample2/modelMonitors/sample3'}
    request = request_type(**request_init)

    # Mock the http request call within the method and fake a BadRequest error.
    with mock.patch.object(AsyncAuthorizedSession, 'request') as req, pytest.raises(core_exceptions.BadRequest):
        # Wrap the value into a proper Response obj
        response_value = mock.Mock()
        response_value.read = mock.AsyncMock(return_value=b'{}')
        response_value.status_code = 400
        response_value.request = mock.Mock()
        req.return_value = response_value
        await client.list_model_monitoring_jobs(request)


@pytest.mark.asyncio
@pytest.mark.parametrize("request_type", [
  model_monitoring_service.ListModelMonitoringJobsRequest,
  dict,
])
async def test_list_model_monitoring_jobs_rest_asyncio_call_success(request_type):
    if not HAS_ASYNC_REST_EXTRA:
        pytest.skip("the library must be installed with the `async_rest` extra to test this feature.")
    client = ModelMonitoringServiceAsyncClient(
        credentials=async_anonymous_credentials(),
        transport="rest_asyncio"
    )

    # send a request that will satisfy transcoding
    request_init = {'parent': 'projects/sample1/locations/sample2/modelMonitors/sample3'}
    request = request_type(**request_init)

    # Mock the http request call within the method and fake a response.
    with mock.patch.object(type(client.transport._session), 'request') as req:
        # Designate an appropriate value for the returned response.
        return_value = model_monitoring_service.ListModelMonitoringJobsResponse(
              next_page_token='next_page_token_value',
        )

        # Wrap the value into a proper Response obj
        response_value = mock.Mock()
        response_value.status_code = 200

        # Convert return value to protobuf type
        return_value = model_monitoring_service.ListModelMonitoringJobsResponse.pb(return_value)
        json_return_value = json_format.MessageToJson(return_value)
        response_value.read = mock.AsyncMock(return_value=json_return_value.encode('UTF-8'))
        req.return_value = response_value
        response = await client.list_model_monitoring_jobs(request)

    # Establish that the response is the type that we expect.
    assert isinstance(response, pagers.ListModelMonitoringJobsAsyncPager)
    assert response.next_page_token == 'next_page_token_value'


@pytest.mark.asyncio
@pytest.mark.parametrize("null_interceptor", [True, False])
async def test_list_model_monitoring_jobs_rest_asyncio_interceptors(null_interceptor):
    if not HAS_ASYNC_REST_EXTRA:
        pytest.skip("the library must be installed with the `async_rest` extra to test this feature.")
    transport = transports.AsyncModelMonitoringServiceRestTransport(
        credentials=async_anonymous_credentials(),
        interceptor=None if null_interceptor else transports.AsyncModelMonitoringServiceRestInterceptor(),
        )
    client = ModelMonitoringServiceAsyncClient(transport=transport)

    with mock.patch.object(type(client.transport._session), "request") as req, \
        mock.patch.object(path_template, "transcode")  as transcode, \
        mock.patch.object(transports.AsyncModelMonitoringServiceRestInterceptor, "post_list_model_monitoring_jobs") as post, \
        mock.patch.object(transports.AsyncModelMonitoringServiceRestInterceptor, "pre_list_model_monitoring_jobs") as pre:
        pre.assert_not_called()
        post.assert_not_called()
        pb_message = model_monitoring_service.ListModelMonitoringJobsRequest.pb(model_monitoring_service.ListModelMonitoringJobsRequest())
        transcode.return_value = {
            "method": "post",
            "uri": "my_uri",
            "body": pb_message,
            "query_params": pb_message,
        }

        req.return_value = mock.Mock()
        req.return_value.status_code = 200
        return_value = model_monitoring_service.ListModelMonitoringJobsResponse.to_json(model_monitoring_service.ListModelMonitoringJobsResponse())
        req.return_value.read = mock.AsyncMock(return_value=return_value)

        request = model_monitoring_service.ListModelMonitoringJobsRequest()
        metadata =[
            ("key", "val"),
            ("cephalopod", "squid"),
        ]
        pre.return_value = request, metadata
        post.return_value = model_monitoring_service.ListModelMonitoringJobsResponse()

        await client.list_model_monitoring_jobs(request, metadata=[("key", "val"), ("cephalopod", "squid"),])

        pre.assert_called_once()
        post.assert_called_once()

@pytest.mark.asyncio
async def test_delete_model_monitoring_job_rest_asyncio_bad_request(request_type=model_monitoring_service.DeleteModelMonitoringJobRequest):
    if not HAS_ASYNC_REST_EXTRA:
        pytest.skip("the library must be installed with the `async_rest` extra to test this feature.")
    client = ModelMonitoringServiceAsyncClient(
        credentials=async_anonymous_credentials(),
        transport="rest_asyncio"
    )
    # send a request that will satisfy transcoding
    request_init = {'name': 'projects/sample1/locations/sample2/modelMonitors/sample3/modelMonitoringJobs/sample4'}
    request = request_type(**request_init)

    # Mock the http request call within the method and fake a BadRequest error.
    with mock.patch.object(AsyncAuthorizedSession, 'request') as req, pytest.raises(core_exceptions.BadRequest):
        # Wrap the value into a proper Response obj
        response_value = mock.Mock()
        response_value.read = mock.AsyncMock(return_value=b'{}')
        response_value.status_code = 400
        response_value.request = mock.Mock()
        req.return_value = response_value
        await client.delete_model_monitoring_job(request)


@pytest.mark.asyncio
@pytest.mark.parametrize("request_type", [
  model_monitoring_service.DeleteModelMonitoringJobRequest,
  dict,
])
async def test_delete_model_monitoring_job_rest_asyncio_call_success(request_type):
    if not HAS_ASYNC_REST_EXTRA:
        pytest.skip("the library must be installed with the `async_rest` extra to test this feature.")
    client = ModelMonitoringServiceAsyncClient(
        credentials=async_anonymous_credentials(),
        transport="rest_asyncio"
    )

    # send a request that will satisfy transcoding
    request_init = {'name': 'projects/sample1/locations/sample2/modelMonitors/sample3/modelMonitoringJobs/sample4'}
    request = request_type(**request_init)

    # Mock the http request call within the method and fake a response.
    with mock.patch.object(type(client.transport._session), 'request') as req:
        # Designate an appropriate value for the returned response.
        return_value = operations_pb2.Operation(name='operations/spam')

        # Wrap the value into a proper Response obj
        response_value = mock.Mock()
        response_value.status_code = 200
        json_return_value = json_format.MessageToJson(return_value)
        response_value.read = mock.AsyncMock(return_value=json_return_value.encode('UTF-8'))
        req.return_value = response_value
        response = await client.delete_model_monitoring_job(request)

    # Establish that the response is the type that we expect.
    json_return_value = json_format.MessageToJson(return_value)


@pytest.mark.asyncio
@pytest.mark.parametrize("null_interceptor", [True, False])
async def test_delete_model_monitoring_job_rest_asyncio_interceptors(null_interceptor):
    if not HAS_ASYNC_REST_EXTRA:
        pytest.skip("the library must be installed with the `async_rest` extra to test this feature.")
    transport = transports.AsyncModelMonitoringServiceRestTransport(
        credentials=async_anonymous_credentials(),
        interceptor=None if null_interceptor else transports.AsyncModelMonitoringServiceRestInterceptor(),
        )
    client = ModelMonitoringServiceAsyncClient(transport=transport)

    with mock.patch.object(type(client.transport._session), "request") as req, \
        mock.patch.object(path_template, "transcode")  as transcode, \
        mock.patch.object(operation.Operation, "_set_result_from_operation"), \
        mock.patch.object(transports.AsyncModelMonitoringServiceRestInterceptor, "post_delete_model_monitoring_job") as post, \
        mock.patch.object(transports.AsyncModelMonitoringServiceRestInterceptor, "pre_delete_model_monitoring_job") as pre:
        pre.assert_not_called()
        post.assert_not_called()
        pb_message = model_monitoring_service.DeleteModelMonitoringJobRequest.pb(model_monitoring_service.DeleteModelMonitoringJobRequest())
        transcode.return_value = {
            "method": "post",
            "uri": "my_uri",
            "body": pb_message,
            "query_params": pb_message,
        }

        req.return_value = mock.Mock()
        req.return_value.status_code = 200
        return_value = json_format.MessageToJson(operations_pb2.Operation())
        req.return_value.read = mock.AsyncMock(return_value=return_value)

        request = model_monitoring_service.DeleteModelMonitoringJobRequest()
        metadata =[
            ("key", "val"),
            ("cephalopod", "squid"),
        ]
        pre.return_value = request, metadata
        post.return_value = operations_pb2.Operation()

        await client.delete_model_monitoring_job(request, metadata=[("key", "val"), ("cephalopod", "squid"),])

        pre.assert_called_once()
        post.assert_called_once()

@pytest.mark.asyncio
async def test_search_model_monitoring_stats_rest_asyncio_bad_request(request_type=model_monitoring_service.SearchModelMonitoringStatsRequest):
    if not HAS_ASYNC_REST_EXTRA:
        pytest.skip("the library must be installed with the `async_rest` extra to test this feature.")
    client = ModelMonitoringServiceAsyncClient(
        credentials=async_anonymous_credentials(),
        transport="rest_asyncio"
    )
    # send a request that will satisfy transcoding
    request_init = {'model_monitor': 'projects/sample1/locations/sample2/modelMonitors/sample3'}
    request = request_type(**request_init)

    # Mock the http request call within the method and fake a BadRequest error.
    with mock.patch.object(AsyncAuthorizedSession, 'request') as req, pytest.raises(core_exceptions.BadRequest):
        # Wrap the value into a proper Response obj
        response_value = mock.Mock()
        response_value.read = mock.AsyncMock(return_value=b'{}')
        response_value.status_code = 400
        response_value.request = mock.Mock()
        req.return_value = response_value
        await client.search_model_monitoring_stats(request)


@pytest.mark.asyncio
@pytest.mark.parametrize("request_type", [
  model_monitoring_service.SearchModelMonitoringStatsRequest,
  dict,
])
async def test_search_model_monitoring_stats_rest_asyncio_call_success(request_type):
    if not HAS_ASYNC_REST_EXTRA:
        pytest.skip("the library must be installed with the `async_rest` extra to test this feature.")
    client = ModelMonitoringServiceAsyncClient(
        credentials=async_anonymous_credentials(),
        transport="rest_asyncio"
    )

    # send a request that will satisfy transcoding
    request_init = {'model_monitor': 'projects/sample1/locations/sample2/modelMonitors/sample3'}
    request = request_type(**request_init)

    # Mock the http request call within the method and fake a response.
    with mock.patch.object(type(client.transport._session), 'request') as req:
        # Designate an appropriate value for the returned response.
        return_value = model_monitoring_service.SearchModelMonitoringStatsResponse(
              next_page_token='next_page_token_value',
        )

        # Wrap the value into a proper Response obj
        response_value = mock.Mock()
        response_value.status_code = 200

        # Convert return value to protobuf type
        return_value = model_monitoring_service.SearchModelMonitoringStatsResponse.pb(return_value)
        json_return_value = json_format.MessageToJson(return_value)
        response_value.read = mock.AsyncMock(return_value=json_return_value.encode('UTF-8'))
        req.return_value = response_value
        response = await client.search_model_monitoring_stats(request)

    # Establish that the response is the type that we expect.
    assert isinstance(response, pagers.SearchModelMonitoringStatsAsyncPager)
    assert response.next_page_token == 'next_page_token_value'


@pytest.mark.asyncio
@pytest.mark.parametrize("null_interceptor", [True, False])
async def test_search_model_monitoring_stats_rest_asyncio_interceptors(null_interceptor):
    if not HAS_ASYNC_REST_EXTRA:
        pytest.skip("the library must be installed with the `async_rest` extra to test this feature.")
    transport = transports.AsyncModelMonitoringServiceRestTransport(
        credentials=async_anonymous_credentials(),
        interceptor=None if null_interceptor else transports.AsyncModelMonitoringServiceRestInterceptor(),
        )
    client = ModelMonitoringServiceAsyncClient(transport=transport)

    with mock.patch.object(type(client.transport._session), "request") as req, \
        mock.patch.object(path_template, "transcode")  as transcode, \
        mock.patch.object(transports.AsyncModelMonitoringServiceRestInterceptor, "post_search_model_monitoring_stats") as post, \
        mock.patch.object(transports.AsyncModelMonitoringServiceRestInterceptor, "pre_search_model_monitoring_stats") as pre:
        pre.assert_not_called()
        post.assert_not_called()
        pb_message = model_monitoring_service.SearchModelMonitoringStatsRequest.pb(model_monitoring_service.SearchModelMonitoringStatsRequest())
        transcode.return_value = {
            "method": "post",
            "uri": "my_uri",
            "body": pb_message,
            "query_params": pb_message,
        }

        req.return_value = mock.Mock()
        req.return_value.status_code = 200
        return_value = model_monitoring_service.SearchModelMonitoringStatsResponse.to_json(model_monitoring_service.SearchModelMonitoringStatsResponse())
        req.return_value.read = mock.AsyncMock(return_value=return_value)

        request = model_monitoring_service.SearchModelMonitoringStatsRequest()
        metadata =[
            ("key", "val"),
            ("cephalopod", "squid"),
        ]
        pre.return_value = request, metadata
        post.return_value = model_monitoring_service.SearchModelMonitoringStatsResponse()

        await client.search_model_monitoring_stats(request, metadata=[("key", "val"), ("cephalopod", "squid"),])

        pre.assert_called_once()
        post.assert_called_once()

@pytest.mark.asyncio
async def test_search_model_monitoring_alerts_rest_asyncio_bad_request(request_type=model_monitoring_service.SearchModelMonitoringAlertsRequest):
    if not HAS_ASYNC_REST_EXTRA:
        pytest.skip("the library must be installed with the `async_rest` extra to test this feature.")
    client = ModelMonitoringServiceAsyncClient(
        credentials=async_anonymous_credentials(),
        transport="rest_asyncio"
    )
    # send a request that will satisfy transcoding
    request_init = {'model_monitor': 'projects/sample1/locations/sample2/modelMonitors/sample3'}
    request = request_type(**request_init)

    # Mock the http request call within the method and fake a BadRequest error.
    with mock.patch.object(AsyncAuthorizedSession, 'request') as req, pytest.raises(core_exceptions.BadRequest):
        # Wrap the value into a proper Response obj
        response_value = mock.Mock()
        response_value.read = mock.AsyncMock(return_value=b'{}')
        response_value.status_code = 400
        response_value.request = mock.Mock()
        req.return_value = response_value
        await client.search_model_monitoring_alerts(request)


@pytest.mark.asyncio
@pytest.mark.parametrize("request_type", [
  model_monitoring_service.SearchModelMonitoringAlertsRequest,
  dict,
])
async def test_search_model_monitoring_alerts_rest_asyncio_call_success(request_type):
    if not HAS_ASYNC_REST_EXTRA:
        pytest.skip("the library must be installed with the `async_rest` extra to test this feature.")
    client = ModelMonitoringServiceAsyncClient(
        credentials=async_anonymous_credentials(),
        transport="rest_asyncio"
    )

    # send a request that will satisfy transcoding
    request_init = {'model_monitor': 'projects/sample1/locations/sample2/modelMonitors/sample3'}
    request = request_type(**request_init)

    # Mock the http request call within the method and fake a response.
    with mock.patch.object(type(client.transport._session), 'request') as req:
        # Designate an appropriate value for the returned response.
        return_value = model_monitoring_service.SearchModelMonitoringAlertsResponse(
              total_number_alerts=2038,
              next_page_token='next_page_token_value',
        )

        # Wrap the value into a proper Response obj
        response_value = mock.Mock()
        response_value.status_code = 200

        # Convert return value to protobuf type
        return_value = model_monitoring_service.SearchModelMonitoringAlertsResponse.pb(return_value)
        json_return_value = json_format.MessageToJson(return_value)
        response_value.read = mock.AsyncMock(return_value=json_return_value.encode('UTF-8'))
        req.return_value = response_value
        response = await client.search_model_monitoring_alerts(request)

    # Establish that the response is the type that we expect.
    assert isinstance(response, pagers.SearchModelMonitoringAlertsAsyncPager)
    assert response.total_number_alerts == 2038
    assert response.next_page_token == 'next_page_token_value'


@pytest.mark.asyncio
@pytest.mark.parametrize("null_interceptor", [True, False])
async def test_search_model_monitoring_alerts_rest_asyncio_interceptors(null_interceptor):
    if not HAS_ASYNC_REST_EXTRA:
        pytest.skip("the library must be installed with the `async_rest` extra to test this feature.")
    transport = transports.AsyncModelMonitoringServiceRestTransport(
        credentials=async_anonymous_credentials(),
        interceptor=None if null_interceptor else transports.AsyncModelMonitoringServiceRestInterceptor(),
        )
    client = ModelMonitoringServiceAsyncClient(transport=transport)

    with mock.patch.object(type(client.transport._session), "request") as req, \
        mock.patch.object(path_template, "transcode")  as transcode, \
        mock.patch.object(transports.AsyncModelMonitoringServiceRestInterceptor, "post_search_model_monitoring_alerts") as post, \
        mock.patch.object(transports.AsyncModelMonitoringServiceRestInterceptor, "pre_search_model_monitoring_alerts") as pre:
        pre.assert_not_called()
        post.assert_not_called()
        pb_message = model_monitoring_service.SearchModelMonitoringAlertsRequest.pb(model_monitoring_service.SearchModelMonitoringAlertsRequest())
        transcode.return_value = {
            "method": "post",
            "uri": "my_uri",
            "body": pb_message,
            "query_params": pb_message,
        }

        req.return_value = mock.Mock()
        req.return_value.status_code = 200
        return_value = model_monitoring_service.SearchModelMonitoringAlertsResponse.to_json(model_monitoring_service.SearchModelMonitoringAlertsResponse())
        req.return_value.read = mock.AsyncMock(return_value=return_value)

        request = model_monitoring_service.SearchModelMonitoringAlertsRequest()
        metadata =[
            ("key", "val"),
            ("cephalopod", "squid"),
        ]
        pre.return_value = request, metadata
        post.return_value = model_monitoring_service.SearchModelMonitoringAlertsResponse()

        await client.search_model_monitoring_alerts(request, metadata=[("key", "val"), ("cephalopod", "squid"),])

        pre.assert_called_once()
        post.assert_called_once()

@pytest.mark.asyncio
async def test_get_location_rest_asyncio_bad_request(request_type=locations_pb2.GetLocationRequest):
    if not HAS_ASYNC_REST_EXTRA:
        pytest.skip("the library must be installed with the `async_rest` extra to test this feature.")
    client = ModelMonitoringServiceAsyncClient(
        credentials=async_anonymous_credentials(),
        transport="rest_asyncio",
    )
    request = request_type()
    request = json_format.ParseDict({'name': 'projects/sample1/locations/sample2'}, request)

    # Mock the http request call within the method and fake a BadRequest error.
    with mock.patch.object(AsyncAuthorizedSession, 'request') as req, pytest.raises(core_exceptions.BadRequest):
        # Wrap the value into a proper Response obj
        response_value = mock.Mock()
        response_value.read = mock.AsyncMock(return_value=b'{}')
        response_value.status_code = 400
        response_value.request = mock.Mock()
        req.return_value = response_value
        await client.get_location(request)

@pytest.mark.asyncio
@pytest.mark.parametrize("request_type", [
    locations_pb2.GetLocationRequest,
    dict,
])
async def test_get_location_rest_asyncio(request_type):
    if not HAS_ASYNC_REST_EXTRA:
        pytest.skip("the library must be installed with the `async_rest` extra to test this feature.")
    client = ModelMonitoringServiceAsyncClient(
        credentials=async_anonymous_credentials(),
        transport="rest_asyncio",
    )

    request_init = {'name': 'projects/sample1/locations/sample2'}
    request = request_type(**request_init)
    # Mock the http request call within the method and fake a response.
    with mock.patch.object(AsyncAuthorizedSession, 'request') as req:
        # Designate an appropriate value for the returned response.
        return_value = locations_pb2.Location()

        # Wrap the value into a proper Response obj
        response_value = mock.Mock()
        response_value.status_code = 200
        json_return_value = json_format.MessageToJson(return_value)
        response_value.read = mock.AsyncMock(return_value=json_return_value.encode('UTF-8'))

        req.return_value = response_value

        response = await client.get_location(request)

    # Establish that the response is the type that we expect.
    assert isinstance(response, locations_pb2.Location)

@pytest.mark.asyncio
async def test_list_locations_rest_asyncio_bad_request(request_type=locations_pb2.ListLocationsRequest):
    if not HAS_ASYNC_REST_EXTRA:
        pytest.skip("the library must be installed with the `async_rest` extra to test this feature.")
    client = ModelMonitoringServiceAsyncClient(
        credentials=async_anonymous_credentials(),
        transport="rest_asyncio",
    )
    request = request_type()
    request = json_format.ParseDict({'name': 'projects/sample1'}, request)

    # Mock the http request call within the method and fake a BadRequest error.
    with mock.patch.object(AsyncAuthorizedSession, 'request') as req, pytest.raises(core_exceptions.BadRequest):
        # Wrap the value into a proper Response obj
        response_value = mock.Mock()
        response_value.read = mock.AsyncMock(return_value=b'{}')
        response_value.status_code = 400
        response_value.request = mock.Mock()
        req.return_value = response_value
        await client.list_locations(request)

@pytest.mark.asyncio
@pytest.mark.parametrize("request_type", [
    locations_pb2.ListLocationsRequest,
    dict,
])
async def test_list_locations_rest_asyncio(request_type):
    if not HAS_ASYNC_REST_EXTRA:
        pytest.skip("the library must be installed with the `async_rest` extra to test this feature.")
    client = ModelMonitoringServiceAsyncClient(
        credentials=async_anonymous_credentials(),
        transport="rest_asyncio",
    )

    request_init = {'name': 'projects/sample1'}
    request = request_type(**request_init)
    # Mock the http request call within the method and fake a response.
    with mock.patch.object(AsyncAuthorizedSession, 'request') as req:
        # Designate an appropriate value for the returned response.
        return_value = locations_pb2.ListLocationsResponse()

        # Wrap the value into a proper Response obj
        response_value = mock.Mock()
        response_value.status_code = 200
        json_return_value = json_format.MessageToJson(return_value)
        response_value.read = mock.AsyncMock(return_value=json_return_value.encode('UTF-8'))

        req.return_value = response_value

        response = await client.list_locations(request)

    # Establish that the response is the type that we expect.
    assert isinstance(response, locations_pb2.ListLocationsResponse)

@pytest.mark.asyncio
async def test_get_iam_policy_rest_asyncio_bad_request(request_type=iam_policy_pb2.GetIamPolicyRequest):
    if not HAS_ASYNC_REST_EXTRA:
        pytest.skip("the library must be installed with the `async_rest` extra to test this feature.")
    client = ModelMonitoringServiceAsyncClient(
        credentials=async_anonymous_credentials(),
        transport="rest_asyncio",
    )
    request = request_type()
    request = json_format.ParseDict({'resource': 'projects/sample1/locations/sample2/featurestores/sample3'}, request)

    # Mock the http request call within the method and fake a BadRequest error.
    with mock.patch.object(AsyncAuthorizedSession, 'request') as req, pytest.raises(core_exceptions.BadRequest):
        # Wrap the value into a proper Response obj
        response_value = mock.Mock()
        response_value.read = mock.AsyncMock(return_value=b'{}')
        response_value.status_code = 400
        response_value.request = mock.Mock()
        req.return_value = response_value
        await client.get_iam_policy(request)

@pytest.mark.asyncio
@pytest.mark.parametrize("request_type", [
    iam_policy_pb2.GetIamPolicyRequest,
    dict,
])
async def test_get_iam_policy_rest_asyncio(request_type):
    if not HAS_ASYNC_REST_EXTRA:
        pytest.skip("the library must be installed with the `async_rest` extra to test this feature.")
    client = ModelMonitoringServiceAsyncClient(
        credentials=async_anonymous_credentials(),
        transport="rest_asyncio",
    )

    request_init = {'resource': 'projects/sample1/locations/sample2/featurestores/sample3'}
    request = request_type(**request_init)
    # Mock the http request call within the method and fake a response.
    with mock.patch.object(AsyncAuthorizedSession, 'request') as req:
        # Designate an appropriate value for the returned response.
        return_value = policy_pb2.Policy()

        # Wrap the value into a proper Response obj
        response_value = mock.Mock()
        response_value.status_code = 200
        json_return_value = json_format.MessageToJson(return_value)
        response_value.read = mock.AsyncMock(return_value=json_return_value.encode('UTF-8'))

        req.return_value = response_value

        response = await client.get_iam_policy(request)

    # Establish that the response is the type that we expect.
    assert isinstance(response, policy_pb2.Policy)

@pytest.mark.asyncio
async def test_set_iam_policy_rest_asyncio_bad_request(request_type=iam_policy_pb2.SetIamPolicyRequest):
    if not HAS_ASYNC_REST_EXTRA:
        pytest.skip("the library must be installed with the `async_rest` extra to test this feature.")
    client = ModelMonitoringServiceAsyncClient(
        credentials=async_anonymous_credentials(),
        transport="rest_asyncio",
    )
    request = request_type()
    request = json_format.ParseDict({'resource': 'projects/sample1/locations/sample2/featurestores/sample3'}, request)

    # Mock the http request call within the method and fake a BadRequest error.
    with mock.patch.object(AsyncAuthorizedSession, 'request') as req, pytest.raises(core_exceptions.BadRequest):
        # Wrap the value into a proper Response obj
        response_value = mock.Mock()
        response_value.read = mock.AsyncMock(return_value=b'{}')
        response_value.status_code = 400
        response_value.request = mock.Mock()
        req.return_value = response_value
        await client.set_iam_policy(request)

@pytest.mark.asyncio
@pytest.mark.parametrize("request_type", [
    iam_policy_pb2.SetIamPolicyRequest,
    dict,
])
async def test_set_iam_policy_rest_asyncio(request_type):
    if not HAS_ASYNC_REST_EXTRA:
        pytest.skip("the library must be installed with the `async_rest` extra to test this feature.")
    client = ModelMonitoringServiceAsyncClient(
        credentials=async_anonymous_credentials(),
        transport="rest_asyncio",
    )

    request_init = {'resource': 'projects/sample1/locations/sample2/featurestores/sample3'}
    request = request_type(**request_init)
    # Mock the http request call within the method and fake a response.
    with mock.patch.object(AsyncAuthorizedSession, 'request') as req:
        # Designate an appropriate value for the returned response.
        return_value = policy_pb2.Policy()

        # Wrap the value into a proper Response obj
        response_value = mock.Mock()
        response_value.status_code = 200
        json_return_value = json_format.MessageToJson(return_value)
        response_value.read = mock.AsyncMock(return_value=json_return_value.encode('UTF-8'))

        req.return_value = response_value

        response = await client.set_iam_policy(request)

    # Establish that the response is the type that we expect.
    assert isinstance(response, policy_pb2.Policy)

@pytest.mark.asyncio
async def test_test_iam_permissions_rest_asyncio_bad_request(request_type=iam_policy_pb2.TestIamPermissionsRequest):
    if not HAS_ASYNC_REST_EXTRA:
        pytest.skip("the library must be installed with the `async_rest` extra to test this feature.")
    client = ModelMonitoringServiceAsyncClient(
        credentials=async_anonymous_credentials(),
        transport="rest_asyncio",
    )
    request = request_type()
    request = json_format.ParseDict({'resource': 'projects/sample1/locations/sample2/featurestores/sample3'}, request)

    # Mock the http request call within the method and fake a BadRequest error.
    with mock.patch.object(AsyncAuthorizedSession, 'request') as req, pytest.raises(core_exceptions.BadRequest):
        # Wrap the value into a proper Response obj
        response_value = mock.Mock()
        response_value.read = mock.AsyncMock(return_value=b'{}')
        response_value.status_code = 400
        response_value.request = mock.Mock()
        req.return_value = response_value
        await client.test_iam_permissions(request)

@pytest.mark.asyncio
@pytest.mark.parametrize("request_type", [
    iam_policy_pb2.TestIamPermissionsRequest,
    dict,
])
async def test_test_iam_permissions_rest_asyncio(request_type):
    if not HAS_ASYNC_REST_EXTRA:
        pytest.skip("the library must be installed with the `async_rest` extra to test this feature.")
    client = ModelMonitoringServiceAsyncClient(
        credentials=async_anonymous_credentials(),
        transport="rest_asyncio",
    )

    request_init = {'resource': 'projects/sample1/locations/sample2/featurestores/sample3'}
    request = request_type(**request_init)
    # Mock the http request call within the method and fake a response.
    with mock.patch.object(AsyncAuthorizedSession, 'request') as req:
        # Designate an appropriate value for the returned response.
        return_value = iam_policy_pb2.TestIamPermissionsResponse()

        # Wrap the value into a proper Response obj
        response_value = mock.Mock()
        response_value.status_code = 200
        json_return_value = json_format.MessageToJson(return_value)
        response_value.read = mock.AsyncMock(return_value=json_return_value.encode('UTF-8'))

        req.return_value = response_value

        response = await client.test_iam_permissions(request)

    # Establish that the response is the type that we expect.
    assert isinstance(response, iam_policy_pb2.TestIamPermissionsResponse)

@pytest.mark.asyncio
async def test_cancel_operation_rest_asyncio_bad_request(request_type=operations_pb2.CancelOperationRequest):
    if not HAS_ASYNC_REST_EXTRA:
        pytest.skip("the library must be installed with the `async_rest` extra to test this feature.")
    client = ModelMonitoringServiceAsyncClient(
        credentials=async_anonymous_credentials(),
        transport="rest_asyncio",
    )
    request = request_type()
    request = json_format.ParseDict({'name': 'projects/sample1/locations/sample2/operations/sample3'}, request)

    # Mock the http request call within the method and fake a BadRequest error.
    with mock.patch.object(AsyncAuthorizedSession, 'request') as req, pytest.raises(core_exceptions.BadRequest):
        # Wrap the value into a proper Response obj
        response_value = mock.Mock()
        response_value.read = mock.AsyncMock(return_value=b'{}')
        response_value.status_code = 400
        response_value.request = mock.Mock()
        req.return_value = response_value
        await client.cancel_operation(request)

@pytest.mark.asyncio
@pytest.mark.parametrize("request_type", [
    operations_pb2.CancelOperationRequest,
    dict,
])
async def test_cancel_operation_rest_asyncio(request_type):
    if not HAS_ASYNC_REST_EXTRA:
        pytest.skip("the library must be installed with the `async_rest` extra to test this feature.")
    client = ModelMonitoringServiceAsyncClient(
        credentials=async_anonymous_credentials(),
        transport="rest_asyncio",
    )

    request_init = {'name': 'projects/sample1/locations/sample2/operations/sample3'}
    request = request_type(**request_init)
    # Mock the http request call within the method and fake a response.
    with mock.patch.object(AsyncAuthorizedSession, 'request') as req:
        # Designate an appropriate value for the returned response.
        return_value = None

        # Wrap the value into a proper Response obj
        response_value = mock.Mock()
        response_value.status_code = 200
        json_return_value = '{}'
        response_value.read = mock.AsyncMock(return_value=json_return_value.encode('UTF-8'))

        req.return_value = response_value

        response = await client.cancel_operation(request)

    # Establish that the response is the type that we expect.
    assert response is None

@pytest.mark.asyncio
async def test_delete_operation_rest_asyncio_bad_request(request_type=operations_pb2.DeleteOperationRequest):
    if not HAS_ASYNC_REST_EXTRA:
        pytest.skip("the library must be installed with the `async_rest` extra to test this feature.")
    client = ModelMonitoringServiceAsyncClient(
        credentials=async_anonymous_credentials(),
        transport="rest_asyncio",
    )
    request = request_type()
    request = json_format.ParseDict({'name': 'projects/sample1/locations/sample2/operations/sample3'}, request)

    # Mock the http request call within the method and fake a BadRequest error.
    with mock.patch.object(AsyncAuthorizedSession, 'request') as req, pytest.raises(core_exceptions.BadRequest):
        # Wrap the value into a proper Response obj
        response_value = mock.Mock()
        response_value.read = mock.AsyncMock(return_value=b'{}')
        response_value.status_code = 400
        response_value.request = mock.Mock()
        req.return_value = response_value
        await client.delete_operation(request)

@pytest.mark.asyncio
@pytest.mark.parametrize("request_type", [
    operations_pb2.DeleteOperationRequest,
    dict,
])
async def test_delete_operation_rest_asyncio(request_type):
    if not HAS_ASYNC_REST_EXTRA:
        pytest.skip("the library must be installed with the `async_rest` extra to test this feature.")
    client = ModelMonitoringServiceAsyncClient(
        credentials=async_anonymous_credentials(),
        transport="rest_asyncio",
    )

    request_init = {'name': 'projects/sample1/locations/sample2/operations/sample3'}
    request = request_type(**request_init)
    # Mock the http request call within the method and fake a response.
    with mock.patch.object(AsyncAuthorizedSession, 'request') as req:
        # Designate an appropriate value for the returned response.
        return_value = None

        # Wrap the value into a proper Response obj
        response_value = mock.Mock()
        response_value.status_code = 200
        json_return_value = '{}'
        response_value.read = mock.AsyncMock(return_value=json_return_value.encode('UTF-8'))

        req.return_value = response_value

        response = await client.delete_operation(request)

    # Establish that the response is the type that we expect.
    assert response is None

@pytest.mark.asyncio
async def test_get_operation_rest_asyncio_bad_request(request_type=operations_pb2.GetOperationRequest):
    if not HAS_ASYNC_REST_EXTRA:
        pytest.skip("the library must be installed with the `async_rest` extra to test this feature.")
    client = ModelMonitoringServiceAsyncClient(
        credentials=async_anonymous_credentials(),
        transport="rest_asyncio",
    )
    request = request_type()
    request = json_format.ParseDict({'name': 'projects/sample1/locations/sample2/operations/sample3'}, request)

    # Mock the http request call within the method and fake a BadRequest error.
    with mock.patch.object(AsyncAuthorizedSession, 'request') as req, pytest.raises(core_exceptions.BadRequest):
        # Wrap the value into a proper Response obj
        response_value = mock.Mock()
        response_value.read = mock.AsyncMock(return_value=b'{}')
        response_value.status_code = 400
        response_value.request = mock.Mock()
        req.return_value = response_value
        await client.get_operation(request)

@pytest.mark.asyncio
@pytest.mark.parametrize("request_type", [
    operations_pb2.GetOperationRequest,
    dict,
])
async def test_get_operation_rest_asyncio(request_type):
    if not HAS_ASYNC_REST_EXTRA:
        pytest.skip("the library must be installed with the `async_rest` extra to test this feature.")
    client = ModelMonitoringServiceAsyncClient(
        credentials=async_anonymous_credentials(),
        transport="rest_asyncio",
    )

    request_init = {'name': 'projects/sample1/locations/sample2/operations/sample3'}
    request = request_type(**request_init)
    # Mock the http request call within the method and fake a response.
    with mock.patch.object(AsyncAuthorizedSession, 'request') as req:
        # Designate an appropriate value for the returned response.
        return_value = operations_pb2.Operation()

        # Wrap the value into a proper Response obj
        response_value = mock.Mock()
        response_value.status_code = 200
        json_return_value = json_format.MessageToJson(return_value)
        response_value.read = mock.AsyncMock(return_value=json_return_value.encode('UTF-8'))

        req.return_value = response_value

        response = await client.get_operation(request)

    # Establish that the response is the type that we expect.
    assert isinstance(response, operations_pb2.Operation)

@pytest.mark.asyncio
async def test_list_operations_rest_asyncio_bad_request(request_type=operations_pb2.ListOperationsRequest):
    if not HAS_ASYNC_REST_EXTRA:
        pytest.skip("the library must be installed with the `async_rest` extra to test this feature.")
    client = ModelMonitoringServiceAsyncClient(
        credentials=async_anonymous_credentials(),
        transport="rest_asyncio",
    )
    request = request_type()
    request = json_format.ParseDict({'name': 'projects/sample1/locations/sample2'}, request)

    # Mock the http request call within the method and fake a BadRequest error.
    with mock.patch.object(AsyncAuthorizedSession, 'request') as req, pytest.raises(core_exceptions.BadRequest):
        # Wrap the value into a proper Response obj
        response_value = mock.Mock()
        response_value.read = mock.AsyncMock(return_value=b'{}')
        response_value.status_code = 400
        response_value.request = mock.Mock()
        req.return_value = response_value
        await client.list_operations(request)

@pytest.mark.asyncio
@pytest.mark.parametrize("request_type", [
    operations_pb2.ListOperationsRequest,
    dict,
])
async def test_list_operations_rest_asyncio(request_type):
    if not HAS_ASYNC_REST_EXTRA:
        pytest.skip("the library must be installed with the `async_rest` extra to test this feature.")
    client = ModelMonitoringServiceAsyncClient(
        credentials=async_anonymous_credentials(),
        transport="rest_asyncio",
    )

    request_init = {'name': 'projects/sample1/locations/sample2'}
    request = request_type(**request_init)
    # Mock the http request call within the method and fake a response.
    with mock.patch.object(AsyncAuthorizedSession, 'request') as req:
        # Designate an appropriate value for the returned response.
        return_value = operations_pb2.ListOperationsResponse()

        # Wrap the value into a proper Response obj
        response_value = mock.Mock()
        response_value.status_code = 200
        json_return_value = json_format.MessageToJson(return_value)
        response_value.read = mock.AsyncMock(return_value=json_return_value.encode('UTF-8'))

        req.return_value = response_value

        response = await client.list_operations(request)

    # Establish that the response is the type that we expect.
    assert isinstance(response, operations_pb2.ListOperationsResponse)

@pytest.mark.asyncio
async def test_wait_operation_rest_asyncio_bad_request(request_type=operations_pb2.WaitOperationRequest):
    if not HAS_ASYNC_REST_EXTRA:
        pytest.skip("the library must be installed with the `async_rest` extra to test this feature.")
    client = ModelMonitoringServiceAsyncClient(
        credentials=async_anonymous_credentials(),
        transport="rest_asyncio",
    )
    request = request_type()
    request = json_format.ParseDict({'name': 'projects/sample1/locations/sample2/operations/sample3'}, request)

    # Mock the http request call within the method and fake a BadRequest error.
    with mock.patch.object(AsyncAuthorizedSession, 'request') as req, pytest.raises(core_exceptions.BadRequest):
        # Wrap the value into a proper Response obj
        response_value = mock.Mock()
        response_value.read = mock.AsyncMock(return_value=b'{}')
        response_value.status_code = 400
        response_value.request = mock.Mock()
        req.return_value = response_value
        await client.wait_operation(request)

@pytest.mark.asyncio
@pytest.mark.parametrize("request_type", [
    operations_pb2.WaitOperationRequest,
    dict,
])
async def test_wait_operation_rest_asyncio(request_type):
    if not HAS_ASYNC_REST_EXTRA:
        pytest.skip("the library must be installed with the `async_rest` extra to test this feature.")
    client = ModelMonitoringServiceAsyncClient(
        credentials=async_anonymous_credentials(),
        transport="rest_asyncio",
    )

    request_init = {'name': 'projects/sample1/locations/sample2/operations/sample3'}
    request = request_type(**request_init)
    # Mock the http request call within the method and fake a response.
    with mock.patch.object(AsyncAuthorizedSession, 'request') as req:
        # Designate an appropriate value for the returned response.
        return_value = operations_pb2.Operation()

        # Wrap the value into a proper Response obj
        response_value = mock.Mock()
        response_value.status_code = 200
        json_return_value = json_format.MessageToJson(return_value)
        response_value.read = mock.AsyncMock(return_value=json_return_value.encode('UTF-8'))

        req.return_value = response_value

        response = await client.wait_operation(request)

    # Establish that the response is the type that we expect.
    assert isinstance(response, operations_pb2.Operation)

def test_initialize_client_w_rest_asyncio():
    if not HAS_ASYNC_REST_EXTRA:
        pytest.skip("the library must be installed with the `async_rest` extra to test this feature.")
    client = ModelMonitoringServiceAsyncClient(
        credentials=async_anonymous_credentials(),
        transport="rest_asyncio"
    )
    assert client is not None


# This test is a coverage failsafe to make sure that totally empty calls,
# i.e. request == None and no flattened fields passed, work.
@pytest.mark.asyncio
async def test_create_model_monitor_empty_call_rest_asyncio():
    if not HAS_ASYNC_REST_EXTRA:
        pytest.skip("the library must be installed with the `async_rest` extra to test this feature.")
    client = ModelMonitoringServiceAsyncClient(
        credentials=async_anonymous_credentials(),
        transport="rest_asyncio",
    )

    # Mock the actual call, and fake the request.
    with mock.patch.object(
            type(client.transport.create_model_monitor),
            '__call__') as call:
        await client.create_model_monitor(request=None)

        # Establish that the underlying stub method was called.
        call.assert_called()
        _, args, _ = call.mock_calls[0]
        request_msg = model_monitoring_service.CreateModelMonitorRequest()

        assert args[0] == request_msg


# This test is a coverage failsafe to make sure that totally empty calls,
# i.e. request == None and no flattened fields passed, work.
@pytest.mark.asyncio
async def test_update_model_monitor_empty_call_rest_asyncio():
    if not HAS_ASYNC_REST_EXTRA:
        pytest.skip("the library must be installed with the `async_rest` extra to test this feature.")
    client = ModelMonitoringServiceAsyncClient(
        credentials=async_anonymous_credentials(),
        transport="rest_asyncio",
    )

    # Mock the actual call, and fake the request.
    with mock.patch.object(
            type(client.transport.update_model_monitor),
            '__call__') as call:
        await client.update_model_monitor(request=None)

        # Establish that the underlying stub method was called.
        call.assert_called()
        _, args, _ = call.mock_calls[0]
        request_msg = model_monitoring_service.UpdateModelMonitorRequest()

        assert args[0] == request_msg


# This test is a coverage failsafe to make sure that totally empty calls,
# i.e. request == None and no flattened fields passed, work.
@pytest.mark.asyncio
async def test_get_model_monitor_empty_call_rest_asyncio():
    if not HAS_ASYNC_REST_EXTRA:
        pytest.skip("the library must be installed with the `async_rest` extra to test this feature.")
    client = ModelMonitoringServiceAsyncClient(
        credentials=async_anonymous_credentials(),
        transport="rest_asyncio",
    )

    # Mock the actual call, and fake the request.
    with mock.patch.object(
            type(client.transport.get_model_monitor),
            '__call__') as call:
        await client.get_model_monitor(request=None)

        # Establish that the underlying stub method was called.
        call.assert_called()
        _, args, _ = call.mock_calls[0]
        request_msg = model_monitoring_service.GetModelMonitorRequest()

        assert args[0] == request_msg


# This test is a coverage failsafe to make sure that totally empty calls,
# i.e. request == None and no flattened fields passed, work.
@pytest.mark.asyncio
async def test_list_model_monitors_empty_call_rest_asyncio():
    if not HAS_ASYNC_REST_EXTRA:
        pytest.skip("the library must be installed with the `async_rest` extra to test this feature.")
    client = ModelMonitoringServiceAsyncClient(
        credentials=async_anonymous_credentials(),
        transport="rest_asyncio",
    )

    # Mock the actual call, and fake the request.
    with mock.patch.object(
            type(client.transport.list_model_monitors),
            '__call__') as call:
        await client.list_model_monitors(request=None)

        # Establish that the underlying stub method was called.
        call.assert_called()
        _, args, _ = call.mock_calls[0]
        request_msg = model_monitoring_service.ListModelMonitorsRequest()

        assert args[0] == request_msg


# This test is a coverage failsafe to make sure that totally empty calls,
# i.e. request == None and no flattened fields passed, work.
@pytest.mark.asyncio
async def test_delete_model_monitor_empty_call_rest_asyncio():
    if not HAS_ASYNC_REST_EXTRA:
        pytest.skip("the library must be installed with the `async_rest` extra to test this feature.")
    client = ModelMonitoringServiceAsyncClient(
        credentials=async_anonymous_credentials(),
        transport="rest_asyncio",
    )

    # Mock the actual call, and fake the request.
    with mock.patch.object(
            type(client.transport.delete_model_monitor),
            '__call__') as call:
        await client.delete_model_monitor(request=None)

        # Establish that the underlying stub method was called.
        call.assert_called()
        _, args, _ = call.mock_calls[0]
        request_msg = model_monitoring_service.DeleteModelMonitorRequest()

        assert args[0] == request_msg


# This test is a coverage failsafe to make sure that totally empty calls,
# i.e. request == None and no flattened fields passed, work.
@pytest.mark.asyncio
async def test_create_model_monitoring_job_empty_call_rest_asyncio():
    if not HAS_ASYNC_REST_EXTRA:
        pytest.skip("the library must be installed with the `async_rest` extra to test this feature.")
    client = ModelMonitoringServiceAsyncClient(
        credentials=async_anonymous_credentials(),
        transport="rest_asyncio",
    )

    # Mock the actual call, and fake the request.
    with mock.patch.object(
            type(client.transport.create_model_monitoring_job),
            '__call__') as call:
        await client.create_model_monitoring_job(request=None)

        # Establish that the underlying stub method was called.
        call.assert_called()
        _, args, _ = call.mock_calls[0]
        request_msg = model_monitoring_service.CreateModelMonitoringJobRequest()

        assert args[0] == request_msg


# This test is a coverage failsafe to make sure that totally empty calls,
# i.e. request == None and no flattened fields passed, work.
@pytest.mark.asyncio
async def test_get_model_monitoring_job_empty_call_rest_asyncio():
    if not HAS_ASYNC_REST_EXTRA:
        pytest.skip("the library must be installed with the `async_rest` extra to test this feature.")
    client = ModelMonitoringServiceAsyncClient(
        credentials=async_anonymous_credentials(),
        transport="rest_asyncio",
    )

    # Mock the actual call, and fake the request.
    with mock.patch.object(
            type(client.transport.get_model_monitoring_job),
            '__call__') as call:
        await client.get_model_monitoring_job(request=None)

        # Establish that the underlying stub method was called.
        call.assert_called()
        _, args, _ = call.mock_calls[0]
        request_msg = model_monitoring_service.GetModelMonitoringJobRequest()

        assert args[0] == request_msg


# This test is a coverage failsafe to make sure that totally empty calls,
# i.e. request == None and no flattened fields passed, work.
@pytest.mark.asyncio
async def test_list_model_monitoring_jobs_empty_call_rest_asyncio():
    if not HAS_ASYNC_REST_EXTRA:
        pytest.skip("the library must be installed with the `async_rest` extra to test this feature.")
    client = ModelMonitoringServiceAsyncClient(
        credentials=async_anonymous_credentials(),
        transport="rest_asyncio",
    )

    # Mock the actual call, and fake the request.
    with mock.patch.object(
            type(client.transport.list_model_monitoring_jobs),
            '__call__') as call:
        await client.list_model_monitoring_jobs(request=None)

        # Establish that the underlying stub method was called.
        call.assert_called()
        _, args, _ = call.mock_calls[0]
        request_msg = model_monitoring_service.ListModelMonitoringJobsRequest()

        assert args[0] == request_msg


# This test is a coverage failsafe to make sure that totally empty calls,
# i.e. request == None and no flattened fields passed, work.
@pytest.mark.asyncio
async def test_delete_model_monitoring_job_empty_call_rest_asyncio():
    if not HAS_ASYNC_REST_EXTRA:
        pytest.skip("the library must be installed with the `async_rest` extra to test this feature.")
    client = ModelMonitoringServiceAsyncClient(
        credentials=async_anonymous_credentials(),
        transport="rest_asyncio",
    )

    # Mock the actual call, and fake the request.
    with mock.patch.object(
            type(client.transport.delete_model_monitoring_job),
            '__call__') as call:
        await client.delete_model_monitoring_job(request=None)

        # Establish that the underlying stub method was called.
        call.assert_called()
        _, args, _ = call.mock_calls[0]
        request_msg = model_monitoring_service.DeleteModelMonitoringJobRequest()

        assert args[0] == request_msg


# This test is a coverage failsafe to make sure that totally empty calls,
# i.e. request == None and no flattened fields passed, work.
@pytest.mark.asyncio
async def test_search_model_monitoring_stats_empty_call_rest_asyncio():
    if not HAS_ASYNC_REST_EXTRA:
        pytest.skip("the library must be installed with the `async_rest` extra to test this feature.")
    client = ModelMonitoringServiceAsyncClient(
        credentials=async_anonymous_credentials(),
        transport="rest_asyncio",
    )

    # Mock the actual call, and fake the request.
    with mock.patch.object(
            type(client.transport.search_model_monitoring_stats),
            '__call__') as call:
        await client.search_model_monitoring_stats(request=None)

        # Establish that the underlying stub method was called.
        call.assert_called()
        _, args, _ = call.mock_calls[0]
        request_msg = model_monitoring_service.SearchModelMonitoringStatsRequest()

        assert args[0] == request_msg


# This test is a coverage failsafe to make sure that totally empty calls,
# i.e. request == None and no flattened fields passed, work.
@pytest.mark.asyncio
async def test_search_model_monitoring_alerts_empty_call_rest_asyncio():
    if not HAS_ASYNC_REST_EXTRA:
        pytest.skip("the library must be installed with the `async_rest` extra to test this feature.")
    client = ModelMonitoringServiceAsyncClient(
        credentials=async_anonymous_credentials(),
        transport="rest_asyncio",
    )

    # Mock the actual call, and fake the request.
    with mock.patch.object(
            type(client.transport.search_model_monitoring_alerts),
            '__call__') as call:
        await client.search_model_monitoring_alerts(request=None)

        # Establish that the underlying stub method was called.
        call.assert_called()
        _, args, _ = call.mock_calls[0]
        request_msg = model_monitoring_service.SearchModelMonitoringAlertsRequest()

        assert args[0] == request_msg


def test_model_monitoring_service_rest_asyncio_lro_client():
    if not HAS_ASYNC_REST_EXTRA:
        pytest.skip("the library must be installed with the `async_rest` extra to test this feature.")
    client = ModelMonitoringServiceAsyncClient(
        credentials=async_anonymous_credentials(),
        transport="rest_asyncio",
    )
    transport = client.transport

    # Ensure that we have an api-core operations client.
    assert isinstance(
        transport.operations_client,
operations_v1.AsyncOperationsRestClient,
    )

    # Ensure that subsequent calls to the property send the exact same object.
    assert transport.operations_client is transport.operations_client

def test_unsupported_parameter_rest_asyncio():
    if not HAS_ASYNC_REST_EXTRA:
        pytest.skip("the library must be installed with the `async_rest` extra to test this feature.")
    options = client_options.ClientOptions(quota_project_id="octopus")
    with pytest.raises(core_exceptions.AsyncRestUnsupportedParameterError, match="google.api_core.client_options.ClientOptions.quota_project_id") as exc:  # type: ignore
        client = ModelMonitoringServiceAsyncClient(
            credentials=async_anonymous_credentials(),
            transport="rest_asyncio",
            client_options=options
    )


def test_transport_grpc_default():
    # A client should use the gRPC transport by default.
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
    )
    assert isinstance(
        client.transport,
        transports.ModelMonitoringServiceGrpcTransport,
    )

def test_model_monitoring_service_base_transport_error():
    # Passing both a credentials object and credentials_file should raise an error
    with pytest.raises(core_exceptions.DuplicateCredentialArgs):
        transport = transports.ModelMonitoringServiceTransport(
            credentials=ga_credentials.AnonymousCredentials(),
            credentials_file="credentials.json"
        )


def test_model_monitoring_service_base_transport():
    # Instantiate the base transport.
    with mock.patch('google.cloud.aiplatform_v1beta1.services.model_monitoring_service.transports.ModelMonitoringServiceTransport.__init__') as Transport:
        Transport.return_value = None
        transport = transports.ModelMonitoringServiceTransport(
            credentials=ga_credentials.AnonymousCredentials(),
        )

    # Every method on the transport should just blindly
    # raise NotImplementedError.
    methods = (
        'create_model_monitor',
        'update_model_monitor',
        'get_model_monitor',
        'list_model_monitors',
        'delete_model_monitor',
        'create_model_monitoring_job',
        'get_model_monitoring_job',
        'list_model_monitoring_jobs',
        'delete_model_monitoring_job',
        'search_model_monitoring_stats',
        'search_model_monitoring_alerts',
        'set_iam_policy',
        'get_iam_policy',
        'test_iam_permissions',
        'get_location',
        'list_locations',
        'get_operation',
        'wait_operation',
        'cancel_operation',
        'delete_operation',
        'list_operations',
    )
    for method in methods:
        with pytest.raises(NotImplementedError):
            getattr(transport, method)(request=object())

    with pytest.raises(NotImplementedError):
        transport.close()

    # Additionally, the LRO client (a property) should
    # also raise NotImplementedError
    with pytest.raises(NotImplementedError):
        transport.operations_client

    # Catch all for all remaining methods and properties
    remainder = [
        'kind',
    ]
    for r in remainder:
        with pytest.raises(NotImplementedError):
            getattr(transport, r)()


def test_model_monitoring_service_base_transport_with_credentials_file():
    # Instantiate the base transport with a credentials file
    with mock.patch.object(google.auth, 'load_credentials_from_file', autospec=True) as load_creds, mock.patch('google.cloud.aiplatform_v1beta1.services.model_monitoring_service.transports.ModelMonitoringServiceTransport._prep_wrapped_messages') as Transport:
        Transport.return_value = None
        load_creds.return_value = (ga_credentials.AnonymousCredentials(), None)
        transport = transports.ModelMonitoringServiceTransport(
            credentials_file="credentials.json",
            quota_project_id="octopus",
        )
        load_creds.assert_called_once_with("credentials.json",
            scopes=None,
            default_scopes=(
            'https://www.googleapis.com/auth/cloud-platform',
),
            quota_project_id="octopus",
        )


def test_model_monitoring_service_base_transport_with_adc():
    # Test the default credentials are used if credentials and credentials_file are None.
    with mock.patch.object(google.auth, 'default', autospec=True) as adc, mock.patch('google.cloud.aiplatform_v1beta1.services.model_monitoring_service.transports.ModelMonitoringServiceTransport._prep_wrapped_messages') as Transport:
        Transport.return_value = None
        adc.return_value = (ga_credentials.AnonymousCredentials(), None)
        transport = transports.ModelMonitoringServiceTransport()
        adc.assert_called_once()


def test_model_monitoring_service_auth_adc():
    # If no credentials are provided, we should use ADC credentials.
    with mock.patch.object(google.auth, 'default', autospec=True) as adc:
        adc.return_value = (ga_credentials.AnonymousCredentials(), None)
        ModelMonitoringServiceClient()
        adc.assert_called_once_with(
            scopes=None,
            default_scopes=(
            'https://www.googleapis.com/auth/cloud-platform',
),
            quota_project_id=None,
        )


@pytest.mark.parametrize(
    "transport_class",
    [
        transports.ModelMonitoringServiceGrpcTransport,
        transports.ModelMonitoringServiceGrpcAsyncIOTransport,
    ],
)
def test_model_monitoring_service_transport_auth_adc(transport_class):
    # If credentials and host are not provided, the transport class should use
    # ADC credentials.
    with mock.patch.object(google.auth, 'default', autospec=True) as adc:
        adc.return_value = (ga_credentials.AnonymousCredentials(), None)
        transport_class(quota_project_id="octopus", scopes=["1", "2"])
        adc.assert_called_once_with(
            scopes=["1", "2"],
            default_scopes=(                'https://www.googleapis.com/auth/cloud-platform',),
            quota_project_id="octopus",
        )


@pytest.mark.parametrize(
    "transport_class",
    [
        transports.ModelMonitoringServiceGrpcTransport,
        transports.ModelMonitoringServiceGrpcAsyncIOTransport,
        transports.ModelMonitoringServiceRestTransport,
    ],
)
def test_model_monitoring_service_transport_auth_gdch_credentials(transport_class):
    host = 'https://language.com'
    api_audience_tests = [None, 'https://language2.com']
    api_audience_expect = [host, 'https://language2.com']
    for t, e in zip(api_audience_tests, api_audience_expect):
        with mock.patch.object(google.auth, 'default', autospec=True) as adc:
            gdch_mock = mock.MagicMock()
            type(gdch_mock).with_gdch_audience = mock.PropertyMock(return_value=gdch_mock)
            adc.return_value = (gdch_mock, None)
            transport_class(host=host, api_audience=t)
            gdch_mock.with_gdch_audience.assert_called_once_with(
                e
            )


@pytest.mark.parametrize(
    "transport_class,grpc_helpers",
    [
        (transports.ModelMonitoringServiceGrpcTransport, grpc_helpers),
        (transports.ModelMonitoringServiceGrpcAsyncIOTransport, grpc_helpers_async)
    ],
)
def test_model_monitoring_service_transport_create_channel(transport_class, grpc_helpers):
    # If credentials and host are not provided, the transport class should use
    # ADC credentials.
    with mock.patch.object(google.auth, "default", autospec=True) as adc, mock.patch.object(
        grpc_helpers, "create_channel", autospec=True
    ) as create_channel:
        creds = ga_credentials.AnonymousCredentials()
        adc.return_value = (creds, None)
        transport_class(
            quota_project_id="octopus",
            scopes=["1", "2"]
        )

        create_channel.assert_called_with(
            "aiplatform.googleapis.com:443",
            credentials=creds,
            credentials_file=None,
            quota_project_id="octopus",
            default_scopes=(
                'https://www.googleapis.com/auth/cloud-platform',
),
            scopes=["1", "2"],
            default_host="aiplatform.googleapis.com",
            ssl_credentials=None,
            options=[
                ("grpc.max_send_message_length", -1),
                ("grpc.max_receive_message_length", -1),
            ],
        )


@pytest.mark.parametrize("transport_class", [transports.ModelMonitoringServiceGrpcTransport, transports.ModelMonitoringServiceGrpcAsyncIOTransport])
def test_model_monitoring_service_grpc_transport_client_cert_source_for_mtls(
    transport_class
):
    cred = ga_credentials.AnonymousCredentials()

    # Check ssl_channel_credentials is used if provided.
    with mock.patch.object(transport_class, "create_channel") as mock_create_channel:
        mock_ssl_channel_creds = mock.Mock()
        transport_class(
            host="squid.clam.whelk",
            credentials=cred,
            ssl_channel_credentials=mock_ssl_channel_creds
        )
        mock_create_channel.assert_called_once_with(
            "squid.clam.whelk:443",
            credentials=cred,
            credentials_file=None,
            scopes=None,
            ssl_credentials=mock_ssl_channel_creds,
            quota_project_id=None,
            options=[
                ("grpc.max_send_message_length", -1),
                ("grpc.max_receive_message_length", -1),
            ],
        )

    # Check if ssl_channel_credentials is not provided, then client_cert_source_for_mtls
    # is used.
    with mock.patch.object(transport_class, "create_channel", return_value=mock.Mock()):
        with mock.patch("grpc.ssl_channel_credentials") as mock_ssl_cred:
            transport_class(
                credentials=cred,
                client_cert_source_for_mtls=client_cert_source_callback
            )
            expected_cert, expected_key = client_cert_source_callback()
            mock_ssl_cred.assert_called_once_with(
                certificate_chain=expected_cert,
                private_key=expected_key
            )

def test_model_monitoring_service_http_transport_client_cert_source_for_mtls():
    cred = ga_credentials.AnonymousCredentials()
    with mock.patch("google.auth.transport.requests.AuthorizedSession.configure_mtls_channel") as mock_configure_mtls_channel:
        transports.ModelMonitoringServiceRestTransport (
            credentials=cred,
            client_cert_source_for_mtls=client_cert_source_callback
        )
        mock_configure_mtls_channel.assert_called_once_with(client_cert_source_callback)


@pytest.mark.parametrize("transport_name", [
    "grpc",
    "grpc_asyncio",
    "rest",
])
def test_model_monitoring_service_host_no_port(transport_name):
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        client_options=client_options.ClientOptions(api_endpoint='aiplatform.googleapis.com'),
         transport=transport_name,
    )
    assert client.transport._host == (
        'aiplatform.googleapis.com:443'
        if transport_name in ['grpc', 'grpc_asyncio']
        else 'https://aiplatform.googleapis.com'
    )

@pytest.mark.parametrize("transport_name", [
    "grpc",
    "grpc_asyncio",
    "rest",
])
def test_model_monitoring_service_host_with_port(transport_name):
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        client_options=client_options.ClientOptions(api_endpoint='aiplatform.googleapis.com:8000'),
        transport=transport_name,
    )
    assert client.transport._host == (
        'aiplatform.googleapis.com:8000'
        if transport_name in ['grpc', 'grpc_asyncio']
        else 'https://aiplatform.googleapis.com:8000'
    )

@pytest.mark.parametrize("transport_name", [
    "rest",
])
def test_model_monitoring_service_client_transport_session_collision(transport_name):
    creds1 = ga_credentials.AnonymousCredentials()
    creds2 = ga_credentials.AnonymousCredentials()
    client1 = ModelMonitoringServiceClient(
        credentials=creds1,
        transport=transport_name,
    )
    client2 = ModelMonitoringServiceClient(
        credentials=creds2,
        transport=transport_name,
    )
    session1 = client1.transport.create_model_monitor._session
    session2 = client2.transport.create_model_monitor._session
    assert session1 != session2
    session1 = client1.transport.update_model_monitor._session
    session2 = client2.transport.update_model_monitor._session
    assert session1 != session2
    session1 = client1.transport.get_model_monitor._session
    session2 = client2.transport.get_model_monitor._session
    assert session1 != session2
    session1 = client1.transport.list_model_monitors._session
    session2 = client2.transport.list_model_monitors._session
    assert session1 != session2
    session1 = client1.transport.delete_model_monitor._session
    session2 = client2.transport.delete_model_monitor._session
    assert session1 != session2
    session1 = client1.transport.create_model_monitoring_job._session
    session2 = client2.transport.create_model_monitoring_job._session
    assert session1 != session2
    session1 = client1.transport.get_model_monitoring_job._session
    session2 = client2.transport.get_model_monitoring_job._session
    assert session1 != session2
    session1 = client1.transport.list_model_monitoring_jobs._session
    session2 = client2.transport.list_model_monitoring_jobs._session
    assert session1 != session2
    session1 = client1.transport.delete_model_monitoring_job._session
    session2 = client2.transport.delete_model_monitoring_job._session
    assert session1 != session2
    session1 = client1.transport.search_model_monitoring_stats._session
    session2 = client2.transport.search_model_monitoring_stats._session
    assert session1 != session2
    session1 = client1.transport.search_model_monitoring_alerts._session
    session2 = client2.transport.search_model_monitoring_alerts._session
    assert session1 != session2
def test_model_monitoring_service_grpc_transport_channel():
    channel = grpc.secure_channel('http://localhost/', grpc.local_channel_credentials())

    # Check that channel is used if provided.
    transport = transports.ModelMonitoringServiceGrpcTransport(
        host="squid.clam.whelk",
        channel=channel,
    )
    assert transport.grpc_channel == channel
    assert transport._host == "squid.clam.whelk:443"
    assert transport._ssl_channel_credentials == None


def test_model_monitoring_service_grpc_asyncio_transport_channel():
    channel = aio.secure_channel('http://localhost/', grpc.local_channel_credentials())

    # Check that channel is used if provided.
    transport = transports.ModelMonitoringServiceGrpcAsyncIOTransport(
        host="squid.clam.whelk",
        channel=channel,
    )
    assert transport.grpc_channel == channel
    assert transport._host == "squid.clam.whelk:443"
    assert transport._ssl_channel_credentials == None


# Remove this test when deprecated arguments (api_mtls_endpoint, client_cert_source) are
# removed from grpc/grpc_asyncio transport constructor.
@pytest.mark.parametrize("transport_class", [transports.ModelMonitoringServiceGrpcTransport, transports.ModelMonitoringServiceGrpcAsyncIOTransport])
def test_model_monitoring_service_transport_channel_mtls_with_client_cert_source(
    transport_class
):
    with mock.patch("grpc.ssl_channel_credentials", autospec=True) as grpc_ssl_channel_cred:
        with mock.patch.object(transport_class, "create_channel") as grpc_create_channel:
            mock_ssl_cred = mock.Mock()
            grpc_ssl_channel_cred.return_value = mock_ssl_cred

            mock_grpc_channel = mock.Mock()
            grpc_create_channel.return_value = mock_grpc_channel

            cred = ga_credentials.AnonymousCredentials()
            with pytest.warns(DeprecationWarning):
                with mock.patch.object(google.auth, 'default') as adc:
                    adc.return_value = (cred, None)
                    transport = transport_class(
                        host="squid.clam.whelk",
                        api_mtls_endpoint="mtls.squid.clam.whelk",
                        client_cert_source=client_cert_source_callback,
                    )
                    adc.assert_called_once()

            grpc_ssl_channel_cred.assert_called_once_with(
                certificate_chain=b"cert bytes", private_key=b"key bytes"
            )
            grpc_create_channel.assert_called_once_with(
                "mtls.squid.clam.whelk:443",
                credentials=cred,
                credentials_file=None,
                scopes=None,
                ssl_credentials=mock_ssl_cred,
                quota_project_id=None,
                options=[
                    ("grpc.max_send_message_length", -1),
                    ("grpc.max_receive_message_length", -1),
                ],
            )
            assert transport.grpc_channel == mock_grpc_channel
            assert transport._ssl_channel_credentials == mock_ssl_cred


# Remove this test when deprecated arguments (api_mtls_endpoint, client_cert_source) are
# removed from grpc/grpc_asyncio transport constructor.
@pytest.mark.parametrize("transport_class", [transports.ModelMonitoringServiceGrpcTransport, transports.ModelMonitoringServiceGrpcAsyncIOTransport])
def test_model_monitoring_service_transport_channel_mtls_with_adc(
    transport_class
):
    mock_ssl_cred = mock.Mock()
    with mock.patch.multiple(
        "google.auth.transport.grpc.SslCredentials",
        __init__=mock.Mock(return_value=None),
        ssl_credentials=mock.PropertyMock(return_value=mock_ssl_cred),
    ):
        with mock.patch.object(transport_class, "create_channel") as grpc_create_channel:
            mock_grpc_channel = mock.Mock()
            grpc_create_channel.return_value = mock_grpc_channel
            mock_cred = mock.Mock()

            with pytest.warns(DeprecationWarning):
                transport = transport_class(
                    host="squid.clam.whelk",
                    credentials=mock_cred,
                    api_mtls_endpoint="mtls.squid.clam.whelk",
                    client_cert_source=None,
                )

            grpc_create_channel.assert_called_once_with(
                "mtls.squid.clam.whelk:443",
                credentials=mock_cred,
                credentials_file=None,
                scopes=None,
                ssl_credentials=mock_ssl_cred,
                quota_project_id=None,
                options=[
                    ("grpc.max_send_message_length", -1),
                    ("grpc.max_receive_message_length", -1),
                ],
            )
            assert transport.grpc_channel == mock_grpc_channel


def test_model_monitoring_service_grpc_lro_client():
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport='grpc',
    )
    transport = client.transport

    # Ensure that we have a api-core operations client.
    assert isinstance(
        transport.operations_client,
        operations_v1.OperationsClient,
    )

    # Ensure that subsequent calls to the property send the exact same object.
    assert transport.operations_client is transport.operations_client


def test_model_monitoring_service_grpc_lro_async_client():
    client = ModelMonitoringServiceAsyncClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport='grpc_asyncio',
    )
    transport = client.transport

    # Ensure that we have a api-core operations client.
    assert isinstance(
        transport.operations_client,
        operations_v1.OperationsAsyncClient,
    )

    # Ensure that subsequent calls to the property send the exact same object.
    assert transport.operations_client is transport.operations_client


def test_batch_prediction_job_path():
    project = "squid"
    location = "clam"
    batch_prediction_job = "whelk"
    expected = "projects/{project}/locations/{location}/batchPredictionJobs/{batch_prediction_job}".format(project=project, location=location, batch_prediction_job=batch_prediction_job, )
    actual = ModelMonitoringServiceClient.batch_prediction_job_path(project, location, batch_prediction_job)
    assert expected == actual


def test_parse_batch_prediction_job_path():
    expected = {
        "project": "octopus",
        "location": "oyster",
        "batch_prediction_job": "nudibranch",
    }
    path = ModelMonitoringServiceClient.batch_prediction_job_path(**expected)

    # Check that the path construction is reversible.
    actual = ModelMonitoringServiceClient.parse_batch_prediction_job_path(path)
    assert expected == actual

def test_dataset_path():
    project = "cuttlefish"
    location = "mussel"
    dataset = "winkle"
    expected = "projects/{project}/locations/{location}/datasets/{dataset}".format(project=project, location=location, dataset=dataset, )
    actual = ModelMonitoringServiceClient.dataset_path(project, location, dataset)
    assert expected == actual


def test_parse_dataset_path():
    expected = {
        "project": "nautilus",
        "location": "scallop",
        "dataset": "abalone",
    }
    path = ModelMonitoringServiceClient.dataset_path(**expected)

    # Check that the path construction is reversible.
    actual = ModelMonitoringServiceClient.parse_dataset_path(path)
    assert expected == actual

def test_endpoint_path():
    project = "squid"
    location = "clam"
    endpoint = "whelk"
    expected = "projects/{project}/locations/{location}/endpoints/{endpoint}".format(project=project, location=location, endpoint=endpoint, )
    actual = ModelMonitoringServiceClient.endpoint_path(project, location, endpoint)
    assert expected == actual


def test_parse_endpoint_path():
    expected = {
        "project": "octopus",
        "location": "oyster",
        "endpoint": "nudibranch",
    }
    path = ModelMonitoringServiceClient.endpoint_path(**expected)

    # Check that the path construction is reversible.
    actual = ModelMonitoringServiceClient.parse_endpoint_path(path)
    assert expected == actual

def test_model_path():
    project = "cuttlefish"
    location = "mussel"
    model = "winkle"
    expected = "projects/{project}/locations/{location}/models/{model}".format(project=project, location=location, model=model, )
    actual = ModelMonitoringServiceClient.model_path(project, location, model)
    assert expected == actual


def test_parse_model_path():
    expected = {
        "project": "nautilus",
        "location": "scallop",
        "model": "abalone",
    }
    path = ModelMonitoringServiceClient.model_path(**expected)

    # Check that the path construction is reversible.
    actual = ModelMonitoringServiceClient.parse_model_path(path)
    assert expected == actual

def test_model_monitor_path():
    project = "squid"
    location = "clam"
    model_monitor = "whelk"
    expected = "projects/{project}/locations/{location}/modelMonitors/{model_monitor}".format(project=project, location=location, model_monitor=model_monitor, )
    actual = ModelMonitoringServiceClient.model_monitor_path(project, location, model_monitor)
    assert expected == actual


def test_parse_model_monitor_path():
    expected = {
        "project": "octopus",
        "location": "oyster",
        "model_monitor": "nudibranch",
    }
    path = ModelMonitoringServiceClient.model_monitor_path(**expected)

    # Check that the path construction is reversible.
    actual = ModelMonitoringServiceClient.parse_model_monitor_path(path)
    assert expected == actual

def test_model_monitoring_job_path():
    project = "cuttlefish"
    location = "mussel"
    model_monitor = "winkle"
    model_monitoring_job = "nautilus"
    expected = "projects/{project}/locations/{location}/modelMonitors/{model_monitor}/modelMonitoringJobs/{model_monitoring_job}".format(project=project, location=location, model_monitor=model_monitor, model_monitoring_job=model_monitoring_job, )
    actual = ModelMonitoringServiceClient.model_monitoring_job_path(project, location, model_monitor, model_monitoring_job)
    assert expected == actual


def test_parse_model_monitoring_job_path():
    expected = {
        "project": "scallop",
        "location": "abalone",
        "model_monitor": "squid",
        "model_monitoring_job": "clam",
    }
    path = ModelMonitoringServiceClient.model_monitoring_job_path(**expected)

    # Check that the path construction is reversible.
    actual = ModelMonitoringServiceClient.parse_model_monitoring_job_path(path)
    assert expected == actual

def test_reservation_path():
    project_id_or_number = "whelk"
    zone = "octopus"
    reservation_name = "oyster"
    expected = "projects/{project_id_or_number}/zones/{zone}/reservations/{reservation_name}".format(project_id_or_number=project_id_or_number, zone=zone, reservation_name=reservation_name, )
    actual = ModelMonitoringServiceClient.reservation_path(project_id_or_number, zone, reservation_name)
    assert expected == actual


def test_parse_reservation_path():
    expected = {
        "project_id_or_number": "nudibranch",
        "zone": "cuttlefish",
        "reservation_name": "mussel",
    }
    path = ModelMonitoringServiceClient.reservation_path(**expected)

    # Check that the path construction is reversible.
    actual = ModelMonitoringServiceClient.parse_reservation_path(path)
    assert expected == actual

def test_schedule_path():
    project = "winkle"
    location = "nautilus"
    schedule = "scallop"
    expected = "projects/{project}/locations/{location}/schedules/{schedule}".format(project=project, location=location, schedule=schedule, )
    actual = ModelMonitoringServiceClient.schedule_path(project, location, schedule)
    assert expected == actual


def test_parse_schedule_path():
    expected = {
        "project": "abalone",
        "location": "squid",
        "schedule": "clam",
    }
    path = ModelMonitoringServiceClient.schedule_path(**expected)

    # Check that the path construction is reversible.
    actual = ModelMonitoringServiceClient.parse_schedule_path(path)
    assert expected == actual

def test_common_billing_account_path():
    billing_account = "whelk"
    expected = "billingAccounts/{billing_account}".format(billing_account=billing_account, )
    actual = ModelMonitoringServiceClient.common_billing_account_path(billing_account)
    assert expected == actual


def test_parse_common_billing_account_path():
    expected = {
        "billing_account": "octopus",
    }
    path = ModelMonitoringServiceClient.common_billing_account_path(**expected)

    # Check that the path construction is reversible.
    actual = ModelMonitoringServiceClient.parse_common_billing_account_path(path)
    assert expected == actual

def test_common_folder_path():
    folder = "oyster"
    expected = "folders/{folder}".format(folder=folder, )
    actual = ModelMonitoringServiceClient.common_folder_path(folder)
    assert expected == actual


def test_parse_common_folder_path():
    expected = {
        "folder": "nudibranch",
    }
    path = ModelMonitoringServiceClient.common_folder_path(**expected)

    # Check that the path construction is reversible.
    actual = ModelMonitoringServiceClient.parse_common_folder_path(path)
    assert expected == actual

def test_common_organization_path():
    organization = "cuttlefish"
    expected = "organizations/{organization}".format(organization=organization, )
    actual = ModelMonitoringServiceClient.common_organization_path(organization)
    assert expected == actual


def test_parse_common_organization_path():
    expected = {
        "organization": "mussel",
    }
    path = ModelMonitoringServiceClient.common_organization_path(**expected)

    # Check that the path construction is reversible.
    actual = ModelMonitoringServiceClient.parse_common_organization_path(path)
    assert expected == actual

def test_common_project_path():
    project = "winkle"
    expected = "projects/{project}".format(project=project, )
    actual = ModelMonitoringServiceClient.common_project_path(project)
    assert expected == actual


def test_parse_common_project_path():
    expected = {
        "project": "nautilus",
    }
    path = ModelMonitoringServiceClient.common_project_path(**expected)

    # Check that the path construction is reversible.
    actual = ModelMonitoringServiceClient.parse_common_project_path(path)
    assert expected == actual

def test_common_location_path():
    project = "scallop"
    location = "abalone"
    expected = "projects/{project}/locations/{location}".format(project=project, location=location, )
    actual = ModelMonitoringServiceClient.common_location_path(project, location)
    assert expected == actual


def test_parse_common_location_path():
    expected = {
        "project": "squid",
        "location": "clam",
    }
    path = ModelMonitoringServiceClient.common_location_path(**expected)

    # Check that the path construction is reversible.
    actual = ModelMonitoringServiceClient.parse_common_location_path(path)
    assert expected == actual


def test_client_with_default_client_info():
    client_info = gapic_v1.client_info.ClientInfo()

    with mock.patch.object(transports.ModelMonitoringServiceTransport, '_prep_wrapped_messages') as prep:
        client = ModelMonitoringServiceClient(
            credentials=ga_credentials.AnonymousCredentials(),
            client_info=client_info,
        )
        prep.assert_called_once_with(client_info)

    with mock.patch.object(transports.ModelMonitoringServiceTransport, '_prep_wrapped_messages') as prep:
        transport_class = ModelMonitoringServiceClient.get_transport_class()
        transport = transport_class(
            credentials=ga_credentials.AnonymousCredentials(),
            client_info=client_info,
        )
        prep.assert_called_once_with(client_info)


def test_delete_operation(transport: str = "grpc"):
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(), transport=transport,
    )

    # Everything is optional in proto3 as far as the runtime is concerned,
    # and we are mocking out the actual API, so just send an empty request.
    request = operations_pb2.DeleteOperationRequest()

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(type(client.transport.delete_operation), "__call__") as call:
        # Designate an appropriate return value for the call.
        call.return_value = None
        response = client.delete_operation(request)
        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls) == 1
        _, args, _ = call.mock_calls[0]
        assert args[0] == request

    # Establish that the response is the type that we expect.
    assert response is None
@pytest.mark.asyncio
async def test_delete_operation_async(transport: str = "grpc_asyncio"):
    client = ModelMonitoringServiceAsyncClient(
        credentials=async_anonymous_credentials(), transport=transport,
    )

    # Everything is optional in proto3 as far as the runtime is concerned,
    # and we are mocking out the actual API, so just send an empty request.
    request = operations_pb2.DeleteOperationRequest()

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(type(client.transport.delete_operation), "__call__") as call:
        # Designate an appropriate return value for the call.
        call.return_value = grpc_helpers_async.FakeUnaryUnaryCall(
            None
        )
        response = await client.delete_operation(request)
        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls) == 1
        _, args, _ = call.mock_calls[0]
        assert args[0] == request

    # Establish that the response is the type that we expect.
    assert response is None

def test_delete_operation_field_headers():
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
    )

    # Any value that is part of the HTTP/1.1 URI should be sent as
    # a field header. Set these to a non-empty value.
    request = operations_pb2.DeleteOperationRequest()
    request.name = "locations"

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(type(client.transport.delete_operation), "__call__") as call:
        call.return_value =  None

        client.delete_operation(request)
        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls) == 1
        _, args, _ = call.mock_calls[0]
        assert args[0] == request

    # Establish that the field header was sent.
    _, _, kw = call.mock_calls[0]
    assert ("x-goog-request-params", "name=locations",) in kw["metadata"]
@pytest.mark.asyncio
async def test_delete_operation_field_headers_async():
    client = ModelMonitoringServiceAsyncClient(
        credentials=async_anonymous_credentials(),
    )

    # Any value that is part of the HTTP/1.1 URI should be sent as
    # a field header. Set these to a non-empty value.
    request = operations_pb2.DeleteOperationRequest()
    request.name = "locations"

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(type(client.transport.delete_operation), "__call__") as call:
        call.return_value = grpc_helpers_async.FakeUnaryUnaryCall(
            None
        )
        await client.delete_operation(request)
        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls) == 1
        _, args, _ = call.mock_calls[0]
        assert args[0] == request

    # Establish that the field header was sent.
    _, _, kw = call.mock_calls[0]
    assert ("x-goog-request-params", "name=locations",) in kw["metadata"]

def test_delete_operation_from_dict():
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
    )
    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(type(client.transport.delete_operation), "__call__") as call:
        # Designate an appropriate return value for the call.
        call.return_value = None

        response = client.delete_operation(
            request={
                "name": "locations",
            }
        )
        call.assert_called()
@pytest.mark.asyncio
async def test_delete_operation_from_dict_async():
    client = ModelMonitoringServiceAsyncClient(
        credentials=async_anonymous_credentials(),
    )
    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(type(client.transport.delete_operation), "__call__") as call:
        # Designate an appropriate return value for the call.
        call.return_value = grpc_helpers_async.FakeUnaryUnaryCall(
            None
        )
        response = await client.delete_operation(
            request={
                "name": "locations",
            }
        )
        call.assert_called()


def test_cancel_operation(transport: str = "grpc"):
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(), transport=transport,
    )

    # Everything is optional in proto3 as far as the runtime is concerned,
    # and we are mocking out the actual API, so just send an empty request.
    request = operations_pb2.CancelOperationRequest()

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(type(client.transport.cancel_operation), "__call__") as call:
        # Designate an appropriate return value for the call.
        call.return_value = None
        response = client.cancel_operation(request)
        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls) == 1
        _, args, _ = call.mock_calls[0]
        assert args[0] == request

    # Establish that the response is the type that we expect.
    assert response is None
@pytest.mark.asyncio
async def test_cancel_operation_async(transport: str = "grpc_asyncio"):
    client = ModelMonitoringServiceAsyncClient(
        credentials=async_anonymous_credentials(), transport=transport,
    )

    # Everything is optional in proto3 as far as the runtime is concerned,
    # and we are mocking out the actual API, so just send an empty request.
    request = operations_pb2.CancelOperationRequest()

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(type(client.transport.cancel_operation), "__call__") as call:
        # Designate an appropriate return value for the call.
        call.return_value = grpc_helpers_async.FakeUnaryUnaryCall(
            None
        )
        response = await client.cancel_operation(request)
        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls) == 1
        _, args, _ = call.mock_calls[0]
        assert args[0] == request

    # Establish that the response is the type that we expect.
    assert response is None

def test_cancel_operation_field_headers():
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
    )

    # Any value that is part of the HTTP/1.1 URI should be sent as
    # a field header. Set these to a non-empty value.
    request = operations_pb2.CancelOperationRequest()
    request.name = "locations"

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(type(client.transport.cancel_operation), "__call__") as call:
        call.return_value =  None

        client.cancel_operation(request)
        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls) == 1
        _, args, _ = call.mock_calls[0]
        assert args[0] == request

    # Establish that the field header was sent.
    _, _, kw = call.mock_calls[0]
    assert ("x-goog-request-params", "name=locations",) in kw["metadata"]
@pytest.mark.asyncio
async def test_cancel_operation_field_headers_async():
    client = ModelMonitoringServiceAsyncClient(
        credentials=async_anonymous_credentials(),
    )

    # Any value that is part of the HTTP/1.1 URI should be sent as
    # a field header. Set these to a non-empty value.
    request = operations_pb2.CancelOperationRequest()
    request.name = "locations"

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(type(client.transport.cancel_operation), "__call__") as call:
        call.return_value = grpc_helpers_async.FakeUnaryUnaryCall(
            None
        )
        await client.cancel_operation(request)
        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls) == 1
        _, args, _ = call.mock_calls[0]
        assert args[0] == request

    # Establish that the field header was sent.
    _, _, kw = call.mock_calls[0]
    assert ("x-goog-request-params", "name=locations",) in kw["metadata"]

def test_cancel_operation_from_dict():
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
    )
    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(type(client.transport.cancel_operation), "__call__") as call:
        # Designate an appropriate return value for the call.
        call.return_value = None

        response = client.cancel_operation(
            request={
                "name": "locations",
            }
        )
        call.assert_called()
@pytest.mark.asyncio
async def test_cancel_operation_from_dict_async():
    client = ModelMonitoringServiceAsyncClient(
        credentials=async_anonymous_credentials(),
    )
    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(type(client.transport.cancel_operation), "__call__") as call:
        # Designate an appropriate return value for the call.
        call.return_value = grpc_helpers_async.FakeUnaryUnaryCall(
            None
        )
        response = await client.cancel_operation(
            request={
                "name": "locations",
            }
        )
        call.assert_called()

def test_wait_operation(transport: str = "grpc"):
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(), transport=transport,
    )

    # Everything is optional in proto3 as far as the runtime is concerned,
    # and we are mocking out the actual API, so just send an empty request.
    request = operations_pb2.WaitOperationRequest()

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(type(client.transport.wait_operation), "__call__") as call:
        # Designate an appropriate return value for the call.
        call.return_value = operations_pb2.Operation()
        response = client.wait_operation(request)
        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls) == 1
        _, args, _ = call.mock_calls[0]
        assert args[0] == request

    # Establish that the response is the type that we expect.
    assert isinstance(response, operations_pb2.Operation)
@pytest.mark.asyncio
async def test_wait_operation(transport: str = "grpc_asyncio"):
    client = ModelMonitoringServiceAsyncClient(
        credentials=async_anonymous_credentials(), transport=transport,
    )

    # Everything is optional in proto3 as far as the runtime is concerned,
    # and we are mocking out the actual API, so just send an empty request.
    request = operations_pb2.WaitOperationRequest()

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(type(client.transport.wait_operation), "__call__") as call:
        # Designate an appropriate return value for the call.
        call.return_value = grpc_helpers_async.FakeUnaryUnaryCall(
            operations_pb2.Operation()
        )
        response = await client.wait_operation(request)
        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls) == 1
        _, args, _ = call.mock_calls[0]
        assert args[0] == request

    # Establish that the response is the type that we expect.
    assert isinstance(response, operations_pb2.Operation)

def test_wait_operation_field_headers():
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
    )

    # Any value that is part of the HTTP/1.1 URI should be sent as
    # a field header. Set these to a non-empty value.
    request = operations_pb2.WaitOperationRequest()
    request.name = "locations"

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(type(client.transport.wait_operation), "__call__") as call:
        call.return_value = operations_pb2.Operation()

        client.wait_operation(request)
        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls) == 1
        _, args, _ = call.mock_calls[0]
        assert args[0] == request

    # Establish that the field header was sent.
    _, _, kw = call.mock_calls[0]
    assert ("x-goog-request-params", "name=locations",) in kw["metadata"]
@pytest.mark.asyncio
async def test_wait_operation_field_headers_async():
    client = ModelMonitoringServiceAsyncClient(
        credentials=async_anonymous_credentials(),
    )

    # Any value that is part of the HTTP/1.1 URI should be sent as
    # a field header. Set these to a non-empty value.
    request = operations_pb2.WaitOperationRequest()
    request.name = "locations"

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(type(client.transport.wait_operation), "__call__") as call:
        call.return_value = grpc_helpers_async.FakeUnaryUnaryCall(
            operations_pb2.Operation()
        )
        await client.wait_operation(request)
        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls) == 1
        _, args, _ = call.mock_calls[0]
        assert args[0] == request

    # Establish that the field header was sent.
    _, _, kw = call.mock_calls[0]
    assert ("x-goog-request-params", "name=locations",) in kw["metadata"]

def test_wait_operation_from_dict():
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
    )
    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(type(client.transport.wait_operation), "__call__") as call:
        # Designate an appropriate return value for the call.
        call.return_value = operations_pb2.Operation()

        response = client.wait_operation(
            request={
                "name": "locations",
            }
        )
        call.assert_called()
@pytest.mark.asyncio
async def test_wait_operation_from_dict_async():
    client = ModelMonitoringServiceAsyncClient(
        credentials=async_anonymous_credentials(),
    )
    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(type(client.transport.wait_operation), "__call__") as call:
        # Designate an appropriate return value for the call.
        call.return_value = grpc_helpers_async.FakeUnaryUnaryCall(
            operations_pb2.Operation()
        )
        response = await client.wait_operation(
            request={
                "name": "locations",
            }
        )
        call.assert_called()


def test_get_operation(transport: str = "grpc"):
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(), transport=transport,
    )

    # Everything is optional in proto3 as far as the runtime is concerned,
    # and we are mocking out the actual API, so just send an empty request.
    request = operations_pb2.GetOperationRequest()

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(type(client.transport.get_operation), "__call__") as call:
        # Designate an appropriate return value for the call.
        call.return_value = operations_pb2.Operation()
        response = client.get_operation(request)
        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls) == 1
        _, args, _ = call.mock_calls[0]
        assert args[0] == request

    # Establish that the response is the type that we expect.
    assert isinstance(response, operations_pb2.Operation)
@pytest.mark.asyncio
async def test_get_operation_async(transport: str = "grpc_asyncio"):
    client = ModelMonitoringServiceAsyncClient(
        credentials=async_anonymous_credentials(), transport=transport,
    )

    # Everything is optional in proto3 as far as the runtime is concerned,
    # and we are mocking out the actual API, so just send an empty request.
    request = operations_pb2.GetOperationRequest()

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(type(client.transport.get_operation), "__call__") as call:
        # Designate an appropriate return value for the call.
        call.return_value = grpc_helpers_async.FakeUnaryUnaryCall(
            operations_pb2.Operation()
        )
        response = await client.get_operation(request)
        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls) == 1
        _, args, _ = call.mock_calls[0]
        assert args[0] == request

    # Establish that the response is the type that we expect.
    assert isinstance(response, operations_pb2.Operation)

def test_get_operation_field_headers():
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
    )

    # Any value that is part of the HTTP/1.1 URI should be sent as
    # a field header. Set these to a non-empty value.
    request = operations_pb2.GetOperationRequest()
    request.name = "locations"

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(type(client.transport.get_operation), "__call__") as call:
        call.return_value = operations_pb2.Operation()

        client.get_operation(request)
        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls) == 1
        _, args, _ = call.mock_calls[0]
        assert args[0] == request

    # Establish that the field header was sent.
    _, _, kw = call.mock_calls[0]
    assert ("x-goog-request-params", "name=locations",) in kw["metadata"]
@pytest.mark.asyncio
async def test_get_operation_field_headers_async():
    client = ModelMonitoringServiceAsyncClient(
        credentials=async_anonymous_credentials(),
    )

    # Any value that is part of the HTTP/1.1 URI should be sent as
    # a field header. Set these to a non-empty value.
    request = operations_pb2.GetOperationRequest()
    request.name = "locations"

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(type(client.transport.get_operation), "__call__") as call:
        call.return_value = grpc_helpers_async.FakeUnaryUnaryCall(
            operations_pb2.Operation()
        )
        await client.get_operation(request)
        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls) == 1
        _, args, _ = call.mock_calls[0]
        assert args[0] == request

    # Establish that the field header was sent.
    _, _, kw = call.mock_calls[0]
    assert ("x-goog-request-params", "name=locations",) in kw["metadata"]

def test_get_operation_from_dict():
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
    )
    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(type(client.transport.get_operation), "__call__") as call:
        # Designate an appropriate return value for the call.
        call.return_value = operations_pb2.Operation()

        response = client.get_operation(
            request={
                "name": "locations",
            }
        )
        call.assert_called()
@pytest.mark.asyncio
async def test_get_operation_from_dict_async():
    client = ModelMonitoringServiceAsyncClient(
        credentials=async_anonymous_credentials(),
    )
    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(type(client.transport.get_operation), "__call__") as call:
        # Designate an appropriate return value for the call.
        call.return_value = grpc_helpers_async.FakeUnaryUnaryCall(
            operations_pb2.Operation()
        )
        response = await client.get_operation(
            request={
                "name": "locations",
            }
        )
        call.assert_called()


def test_list_operations(transport: str = "grpc"):
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(), transport=transport,
    )

    # Everything is optional in proto3 as far as the runtime is concerned,
    # and we are mocking out the actual API, so just send an empty request.
    request = operations_pb2.ListOperationsRequest()

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(type(client.transport.list_operations), "__call__") as call:
        # Designate an appropriate return value for the call.
        call.return_value = operations_pb2.ListOperationsResponse()
        response = client.list_operations(request)
        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls) == 1
        _, args, _ = call.mock_calls[0]
        assert args[0] == request

    # Establish that the response is the type that we expect.
    assert isinstance(response, operations_pb2.ListOperationsResponse)
@pytest.mark.asyncio
async def test_list_operations_async(transport: str = "grpc_asyncio"):
    client = ModelMonitoringServiceAsyncClient(
        credentials=async_anonymous_credentials(), transport=transport,
    )

    # Everything is optional in proto3 as far as the runtime is concerned,
    # and we are mocking out the actual API, so just send an empty request.
    request = operations_pb2.ListOperationsRequest()

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(type(client.transport.list_operations), "__call__") as call:
        # Designate an appropriate return value for the call.
        call.return_value = grpc_helpers_async.FakeUnaryUnaryCall(
            operations_pb2.ListOperationsResponse()
        )
        response = await client.list_operations(request)
        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls) == 1
        _, args, _ = call.mock_calls[0]
        assert args[0] == request

    # Establish that the response is the type that we expect.
    assert isinstance(response, operations_pb2.ListOperationsResponse)

def test_list_operations_field_headers():
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
    )

    # Any value that is part of the HTTP/1.1 URI should be sent as
    # a field header. Set these to a non-empty value.
    request = operations_pb2.ListOperationsRequest()
    request.name = "locations"

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(type(client.transport.list_operations), "__call__") as call:
        call.return_value = operations_pb2.ListOperationsResponse()

        client.list_operations(request)
        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls) == 1
        _, args, _ = call.mock_calls[0]
        assert args[0] == request

    # Establish that the field header was sent.
    _, _, kw = call.mock_calls[0]
    assert ("x-goog-request-params", "name=locations",) in kw["metadata"]
@pytest.mark.asyncio
async def test_list_operations_field_headers_async():
    client = ModelMonitoringServiceAsyncClient(
        credentials=async_anonymous_credentials(),
    )

    # Any value that is part of the HTTP/1.1 URI should be sent as
    # a field header. Set these to a non-empty value.
    request = operations_pb2.ListOperationsRequest()
    request.name = "locations"

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(type(client.transport.list_operations), "__call__") as call:
        call.return_value = grpc_helpers_async.FakeUnaryUnaryCall(
            operations_pb2.ListOperationsResponse()
        )
        await client.list_operations(request)
        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls) == 1
        _, args, _ = call.mock_calls[0]
        assert args[0] == request

    # Establish that the field header was sent.
    _, _, kw = call.mock_calls[0]
    assert ("x-goog-request-params", "name=locations",) in kw["metadata"]

def test_list_operations_from_dict():
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
    )
    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(type(client.transport.list_operations), "__call__") as call:
        # Designate an appropriate return value for the call.
        call.return_value = operations_pb2.ListOperationsResponse()

        response = client.list_operations(
            request={
                "name": "locations",
            }
        )
        call.assert_called()
@pytest.mark.asyncio
async def test_list_operations_from_dict_async():
    client = ModelMonitoringServiceAsyncClient(
        credentials=async_anonymous_credentials(),
    )
    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(type(client.transport.list_operations), "__call__") as call:
        # Designate an appropriate return value for the call.
        call.return_value = grpc_helpers_async.FakeUnaryUnaryCall(
            operations_pb2.ListOperationsResponse()
        )
        response = await client.list_operations(
            request={
                "name": "locations",
            }
        )
        call.assert_called()


def test_list_locations(transport: str = "grpc"):
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(), transport=transport,
    )

    # Everything is optional in proto3 as far as the runtime is concerned,
    # and we are mocking out the actual API, so just send an empty request.
    request = locations_pb2.ListLocationsRequest()

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(type(client.transport.list_locations), "__call__") as call:
        # Designate an appropriate return value for the call.
        call.return_value = locations_pb2.ListLocationsResponse()
        response = client.list_locations(request)
        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls) == 1
        _, args, _ = call.mock_calls[0]
        assert args[0] == request

    # Establish that the response is the type that we expect.
    assert isinstance(response, locations_pb2.ListLocationsResponse)
@pytest.mark.asyncio
async def test_list_locations_async(transport: str = "grpc_asyncio"):
    client = ModelMonitoringServiceAsyncClient(
        credentials=async_anonymous_credentials(), transport=transport,
    )

    # Everything is optional in proto3 as far as the runtime is concerned,
    # and we are mocking out the actual API, so just send an empty request.
    request = locations_pb2.ListLocationsRequest()

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(type(client.transport.list_locations), "__call__") as call:
        # Designate an appropriate return value for the call.
        call.return_value = grpc_helpers_async.FakeUnaryUnaryCall(
            locations_pb2.ListLocationsResponse()
        )
        response = await client.list_locations(request)
        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls) == 1
        _, args, _ = call.mock_calls[0]
        assert args[0] == request

    # Establish that the response is the type that we expect.
    assert isinstance(response, locations_pb2.ListLocationsResponse)

def test_list_locations_field_headers():
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
    )

    # Any value that is part of the HTTP/1.1 URI should be sent as
    # a field header. Set these to a non-empty value.
    request = locations_pb2.ListLocationsRequest()
    request.name = "locations"

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(type(client.transport.list_locations), "__call__") as call:
        call.return_value = locations_pb2.ListLocationsResponse()

        client.list_locations(request)
        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls) == 1
        _, args, _ = call.mock_calls[0]
        assert args[0] == request

    # Establish that the field header was sent.
    _, _, kw = call.mock_calls[0]
    assert ("x-goog-request-params", "name=locations",) in kw["metadata"]
@pytest.mark.asyncio
async def test_list_locations_field_headers_async():
    client = ModelMonitoringServiceAsyncClient(
        credentials=async_anonymous_credentials(),
    )

    # Any value that is part of the HTTP/1.1 URI should be sent as
    # a field header. Set these to a non-empty value.
    request = locations_pb2.ListLocationsRequest()
    request.name = "locations"

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(type(client.transport.list_locations), "__call__") as call:
        call.return_value = grpc_helpers_async.FakeUnaryUnaryCall(
            locations_pb2.ListLocationsResponse()
        )
        await client.list_locations(request)
        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls) == 1
        _, args, _ = call.mock_calls[0]
        assert args[0] == request

    # Establish that the field header was sent.
    _, _, kw = call.mock_calls[0]
    assert ("x-goog-request-params", "name=locations",) in kw["metadata"]

def test_list_locations_from_dict():
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
    )
    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(type(client.transport.list_locations), "__call__") as call:
        # Designate an appropriate return value for the call.
        call.return_value = locations_pb2.ListLocationsResponse()

        response = client.list_locations(
            request={
                "name": "locations",
            }
        )
        call.assert_called()
@pytest.mark.asyncio
async def test_list_locations_from_dict_async():
    client = ModelMonitoringServiceAsyncClient(
        credentials=async_anonymous_credentials(),
    )
    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(type(client.transport.list_locations), "__call__") as call:
        # Designate an appropriate return value for the call.
        call.return_value = grpc_helpers_async.FakeUnaryUnaryCall(
            locations_pb2.ListLocationsResponse()
        )
        response = await client.list_locations(
            request={
                "name": "locations",
            }
        )
        call.assert_called()


def test_get_location(transport: str = "grpc"):
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(), transport=transport,
    )

    # Everything is optional in proto3 as far as the runtime is concerned,
    # and we are mocking out the actual API, so just send an empty request.
    request = locations_pb2.GetLocationRequest()

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(type(client.transport.get_location), "__call__") as call:
        # Designate an appropriate return value for the call.
        call.return_value = locations_pb2.Location()
        response = client.get_location(request)
        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls) == 1
        _, args, _ = call.mock_calls[0]
        assert args[0] == request

    # Establish that the response is the type that we expect.
    assert isinstance(response, locations_pb2.Location)
@pytest.mark.asyncio
async def test_get_location_async(transport: str = "grpc_asyncio"):
    client = ModelMonitoringServiceAsyncClient(
        credentials=async_anonymous_credentials(), transport=transport,
    )

    # Everything is optional in proto3 as far as the runtime is concerned,
    # and we are mocking out the actual API, so just send an empty request.
    request = locations_pb2.GetLocationRequest()

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(type(client.transport.get_location), "__call__") as call:
        # Designate an appropriate return value for the call.
        call.return_value = grpc_helpers_async.FakeUnaryUnaryCall(
            locations_pb2.Location()
        )
        response = await client.get_location(request)
        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls) == 1
        _, args, _ = call.mock_calls[0]
        assert args[0] == request

    # Establish that the response is the type that we expect.
    assert isinstance(response, locations_pb2.Location)

def test_get_location_field_headers():
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials())

    # Any value that is part of the HTTP/1.1 URI should be sent as
    # a field header. Set these to a non-empty value.
    request = locations_pb2.GetLocationRequest()
    request.name = "locations/abc"

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(type(client.transport.get_location), "__call__") as call:
        call.return_value = locations_pb2.Location()

        client.get_location(request)
        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls) == 1
        _, args, _ = call.mock_calls[0]
        assert args[0] == request

    # Establish that the field header was sent.
    _, _, kw = call.mock_calls[0]
    assert ("x-goog-request-params", "name=locations/abc",) in kw["metadata"]
@pytest.mark.asyncio
async def test_get_location_field_headers_async():
    client = ModelMonitoringServiceAsyncClient(
        credentials=async_anonymous_credentials()
    )

    # Any value that is part of the HTTP/1.1 URI should be sent as
    # a field header. Set these to a non-empty value.
    request = locations_pb2.GetLocationRequest()
    request.name = "locations/abc"

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(type(client.transport.get_location), "__call__") as call:
        call.return_value = grpc_helpers_async.FakeUnaryUnaryCall(
            locations_pb2.Location()
        )
        await client.get_location(request)
        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls) == 1
        _, args, _ = call.mock_calls[0]
        assert args[0] == request

    # Establish that the field header was sent.
    _, _, kw = call.mock_calls[0]
    assert ("x-goog-request-params", "name=locations/abc",) in kw["metadata"]

def test_get_location_from_dict():
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
    )
    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(type(client.transport.list_locations), "__call__") as call:
        # Designate an appropriate return value for the call.
        call.return_value = locations_pb2.Location()

        response = client.get_location(
            request={
                "name": "locations/abc",
            }
        )
        call.assert_called()
@pytest.mark.asyncio
async def test_get_location_from_dict_async():
    client = ModelMonitoringServiceAsyncClient(
        credentials=async_anonymous_credentials(),
    )
    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(type(client.transport.list_locations), "__call__") as call:
        # Designate an appropriate return value for the call.
        call.return_value = grpc_helpers_async.FakeUnaryUnaryCall(
            locations_pb2.Location()
        )
        response = await client.get_location(
            request={
                "name": "locations",
            }
        )
        call.assert_called()


def test_set_iam_policy(transport: str = "grpc"):
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(), transport=transport,
    )

    # Everything is optional in proto3 as far as the runtime is concerned,
    # and we are mocking out the actual API, so just send an empty request.
    request = iam_policy_pb2.SetIamPolicyRequest()

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(type(client.transport.set_iam_policy), "__call__") as call:
        # Designate an appropriate return value for the call.
        call.return_value = policy_pb2.Policy(version=774, etag=b"etag_blob",)
        response = client.set_iam_policy(request)
        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls) == 1
        _, args, _ = call.mock_calls[0]

        assert args[0] == request

    # Establish that the response is the type that we expect.
    assert isinstance(response, policy_pb2.Policy)

    assert response.version == 774

    assert response.etag == b"etag_blob"
@pytest.mark.asyncio
async def test_set_iam_policy_async(transport: str = "grpc_asyncio"):
    client = ModelMonitoringServiceAsyncClient(
        credentials=async_anonymous_credentials(), transport=transport,
    )

    # Everything is optional in proto3 as far as the runtime is concerned,
    # and we are mocking out the actual API, so just send an empty request.
    request = iam_policy_pb2.SetIamPolicyRequest()

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(type(client.transport.set_iam_policy), "__call__") as call:
        # Designate an appropriate return value for the call.
        # Designate an appropriate return value for the call.
        call.return_value = grpc_helpers_async.FakeUnaryUnaryCall(
            policy_pb2.Policy(version=774, etag=b"etag_blob",)
        )
        response = await client.set_iam_policy(request)
        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls) == 1
        _, args, _ = call.mock_calls[0]

        assert args[0] == request

    # Establish that the response is the type that we expect.
    assert isinstance(response, policy_pb2.Policy)

    assert response.version == 774

    assert response.etag == b"etag_blob"

def test_set_iam_policy_field_headers():
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
    )

    # Any value that is part of the HTTP/1.1 URI should be sent as
    # a field header. Set these to a non-empty value.
    request = iam_policy_pb2.SetIamPolicyRequest()
    request.resource = "resource/value"

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(type(client.transport.set_iam_policy), "__call__") as call:
        call.return_value = policy_pb2.Policy()

        client.set_iam_policy(request)

        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls) == 1
        _, args, _ = call.mock_calls[0]
        assert args[0] == request

    # Establish that the field header was sent.
    _, _, kw = call.mock_calls[0]
    assert ("x-goog-request-params", "resource=resource/value",) in kw["metadata"]
@pytest.mark.asyncio
async def test_set_iam_policy_field_headers_async():
    client = ModelMonitoringServiceAsyncClient(
        credentials=async_anonymous_credentials(),
    )

    # Any value that is part of the HTTP/1.1 URI should be sent as
    # a field header. Set these to a non-empty value.
    request = iam_policy_pb2.SetIamPolicyRequest()
    request.resource = "resource/value"

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(type(client.transport.set_iam_policy), "__call__") as call:
        call.return_value = grpc_helpers_async.FakeUnaryUnaryCall(policy_pb2.Policy())

        await client.set_iam_policy(request)

        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls) == 1
        _, args, _ = call.mock_calls[0]
        assert args[0] == request

    # Establish that the field header was sent.
    _, _, kw = call.mock_calls[0]
    assert ("x-goog-request-params", "resource=resource/value",) in kw["metadata"]

def test_set_iam_policy_from_dict():
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
    )
    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(type(client.transport.set_iam_policy), "__call__") as call:
        # Designate an appropriate return value for the call.
        call.return_value = policy_pb2.Policy()

        response = client.set_iam_policy(
            request={
                "resource": "resource_value",
                "policy": policy_pb2.Policy(version=774),
            }
        )
        call.assert_called()


@pytest.mark.asyncio
async def test_set_iam_policy_from_dict_async():
    client = ModelMonitoringServiceAsyncClient(
        credentials=async_anonymous_credentials(),
    )
    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(type(client.transport.set_iam_policy), "__call__") as call:
        # Designate an appropriate return value for the call.
        call.return_value = grpc_helpers_async.FakeUnaryUnaryCall(
            policy_pb2.Policy()
        )

        response = await client.set_iam_policy(
            request={
                "resource": "resource_value",
                "policy": policy_pb2.Policy(version=774),
            }
        )
        call.assert_called()

def test_get_iam_policy(transport: str = "grpc"):
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(), transport=transport,
    )

    # Everything is optional in proto3 as far as the runtime is concerned,
    # and we are mocking out the actual API, so just send an empty request.
    request = iam_policy_pb2.GetIamPolicyRequest()

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(type(client.transport.get_iam_policy), "__call__") as call:
        # Designate an appropriate return value for the call.
        call.return_value = policy_pb2.Policy(version=774, etag=b"etag_blob",)

        response = client.get_iam_policy(request)

        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls) == 1
        _, args, _ = call.mock_calls[0]

        assert args[0] == request

    # Establish that the response is the type that we expect.
    assert isinstance(response, policy_pb2.Policy)

    assert response.version == 774

    assert response.etag == b"etag_blob"


@pytest.mark.asyncio
async def test_get_iam_policy_async(transport: str = "grpc_asyncio"):
    client = ModelMonitoringServiceAsyncClient(
        credentials=async_anonymous_credentials(), transport=transport,
    )

    # Everything is optional in proto3 as far as the runtime is concerned,
    # and we are mocking out the actual API, so just send an empty request.
    request = iam_policy_pb2.GetIamPolicyRequest()

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
        type(client.transport.get_iam_policy), "__call__"
    ) as call:
        # Designate an appropriate return value for the call.
        call.return_value = grpc_helpers_async.FakeUnaryUnaryCall(
            policy_pb2.Policy(version=774, etag=b"etag_blob",)
        )

        response = await client.get_iam_policy(request)

        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls)
        _, args, _ = call.mock_calls[0]

        assert args[0] == request

    # Establish that the response is the type that we expect.
    assert isinstance(response, policy_pb2.Policy)

    assert response.version == 774

    assert response.etag == b"etag_blob"


def test_get_iam_policy_field_headers():
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
    )

    # Any value that is part of the HTTP/1.1 URI should be sent as
    # a field header. Set these to a non-empty value.
    request = iam_policy_pb2.GetIamPolicyRequest()
    request.resource = "resource/value"

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(type(client.transport.get_iam_policy), "__call__") as call:
        call.return_value = policy_pb2.Policy()

        client.get_iam_policy(request)

        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls) == 1
        _, args, _ = call.mock_calls[0]
        assert args[0] == request

    # Establish that the field header was sent.
    _, _, kw = call.mock_calls[0]
    assert ("x-goog-request-params", "resource=resource/value",) in kw["metadata"]


@pytest.mark.asyncio
async def test_get_iam_policy_field_headers_async():
    client = ModelMonitoringServiceAsyncClient(
        credentials=async_anonymous_credentials(),
    )

    # Any value that is part of the HTTP/1.1 URI should be sent as
    # a field header. Set these to a non-empty value.
    request = iam_policy_pb2.GetIamPolicyRequest()
    request.resource = "resource/value"

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
        type(client.transport.get_iam_policy), "__call__"
    ) as call:
        call.return_value = grpc_helpers_async.FakeUnaryUnaryCall(policy_pb2.Policy())

        await client.get_iam_policy(request)

        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls)
        _, args, _ = call.mock_calls[0]
        assert args[0] == request

    # Establish that the field header was sent.
    _, _, kw = call.mock_calls[0]
    assert ("x-goog-request-params", "resource=resource/value",) in kw["metadata"]


def test_get_iam_policy_from_dict():
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
    )
    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(type(client.transport.get_iam_policy), "__call__") as call:
        # Designate an appropriate return value for the call.
        call.return_value = policy_pb2.Policy()

        response = client.get_iam_policy(
            request={
                "resource": "resource_value",
                "options": options_pb2.GetPolicyOptions(requested_policy_version=2598),
            }
        )
        call.assert_called()

@pytest.mark.asyncio
async def test_get_iam_policy_from_dict_async():
    client = ModelMonitoringServiceAsyncClient(
        credentials=async_anonymous_credentials(),
    )
    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(type(client.transport.get_iam_policy), "__call__") as call:
        # Designate an appropriate return value for the call.
        call.return_value = grpc_helpers_async.FakeUnaryUnaryCall(
            policy_pb2.Policy()
        )

        response = await client.get_iam_policy(
            request={
                "resource": "resource_value",
                "options": options_pb2.GetPolicyOptions(requested_policy_version=2598),
            }
        )
        call.assert_called()

def test_test_iam_permissions(transport: str = "grpc"):
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(), transport=transport,
    )

    # Everything is optional in proto3 as far as the runtime is concerned,
    # and we are mocking out the actual API, so just send an empty request.
    request = iam_policy_pb2.TestIamPermissionsRequest()

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
        type(client.transport.test_iam_permissions), "__call__"
    ) as call:
        # Designate an appropriate return value for the call.
        call.return_value = iam_policy_pb2.TestIamPermissionsResponse(
            permissions=["permissions_value"],
        )

        response = client.test_iam_permissions(request)

        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls) == 1
        _, args, _ = call.mock_calls[0]

        assert args[0] == request

    # Establish that the response is the type that we expect.
    assert isinstance(response, iam_policy_pb2.TestIamPermissionsResponse)

    assert response.permissions == ["permissions_value"]


@pytest.mark.asyncio
async def test_test_iam_permissions_async(transport: str = "grpc_asyncio"):
    client = ModelMonitoringServiceAsyncClient(
        credentials=async_anonymous_credentials(), transport=transport,
    )

    # Everything is optional in proto3 as far as the runtime is concerned,
    # and we are mocking out the actual API, so just send an empty request.
    request = iam_policy_pb2.TestIamPermissionsRequest()

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
        type(client.transport.test_iam_permissions), "__call__"
    ) as call:
        # Designate an appropriate return value for the call.
        call.return_value = grpc_helpers_async.FakeUnaryUnaryCall(
            iam_policy_pb2.TestIamPermissionsResponse(permissions=["permissions_value"],)
        )

        response = await client.test_iam_permissions(request)

        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls)
        _, args, _ = call.mock_calls[0]

        assert args[0] == request

    # Establish that the response is the type that we expect.
    assert isinstance(response, iam_policy_pb2.TestIamPermissionsResponse)

    assert response.permissions == ["permissions_value"]


def test_test_iam_permissions_field_headers():
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
    )

    # Any value that is part of the HTTP/1.1 URI should be sent as
    # a field header. Set these to a non-empty value.
    request = iam_policy_pb2.TestIamPermissionsRequest()
    request.resource = "resource/value"

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
        type(client.transport.test_iam_permissions), "__call__"
    ) as call:
        call.return_value = iam_policy_pb2.TestIamPermissionsResponse()

        client.test_iam_permissions(request)

        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls) == 1
        _, args, _ = call.mock_calls[0]
        assert args[0] == request

    # Establish that the field header was sent.
    _, _, kw = call.mock_calls[0]
    assert ("x-goog-request-params", "resource=resource/value",) in kw["metadata"]


@pytest.mark.asyncio
async def test_test_iam_permissions_field_headers_async():
    client = ModelMonitoringServiceAsyncClient(
        credentials=async_anonymous_credentials(),
    )

    # Any value that is part of the HTTP/1.1 URI should be sent as
    # a field header. Set these to a non-empty value.
    request = iam_policy_pb2.TestIamPermissionsRequest()
    request.resource = "resource/value"

    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
        type(client.transport.test_iam_permissions), "__call__"
    ) as call:
        call.return_value = grpc_helpers_async.FakeUnaryUnaryCall(
            iam_policy_pb2.TestIamPermissionsResponse()
        )

        await client.test_iam_permissions(request)

        # Establish that the underlying gRPC stub method was called.
        assert len(call.mock_calls)
        _, args, _ = call.mock_calls[0]
        assert args[0] == request

    # Establish that the field header was sent.
    _, _, kw = call.mock_calls[0]
    assert ("x-goog-request-params", "resource=resource/value",) in kw["metadata"]


def test_test_iam_permissions_from_dict():
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
    )
    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
        type(client.transport.test_iam_permissions), "__call__"
    ) as call:
        # Designate an appropriate return value for the call.
        call.return_value = iam_policy_pb2.TestIamPermissionsResponse()

        response = client.test_iam_permissions(
            request={
                "resource": "resource_value",
                "permissions": ["permissions_value"],
            }
        )
        call.assert_called()

@pytest.mark.asyncio
async def test_test_iam_permissions_from_dict_async():
    client = ModelMonitoringServiceAsyncClient(
        credentials=async_anonymous_credentials(),
    )
    # Mock the actual call within the gRPC stub, and fake the request.
    with mock.patch.object(
        type(client.transport.test_iam_permissions), "__call__"
    ) as call:
        # Designate an appropriate return value for the call.
        call.return_value = grpc_helpers_async.FakeUnaryUnaryCall(
            iam_policy_pb2.TestIamPermissionsResponse()
        )

        response = await client.test_iam_permissions(
            request={
                "resource": "resource_value",
                "permissions": ["permissions_value"],
            }
        )
        call.assert_called()


def test_transport_close_grpc():
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport="grpc"
    )
    with mock.patch.object(type(getattr(client.transport, "_grpc_channel")), "close") as close:
        with client:
            close.assert_not_called()
        close.assert_called_once()


@pytest.mark.asyncio
async def test_transport_close_grpc_asyncio():
    client = ModelMonitoringServiceAsyncClient(
        credentials=async_anonymous_credentials(),
        transport="grpc_asyncio"
    )
    with mock.patch.object(type(getattr(client.transport, "_grpc_channel")), "close") as close:
        async with client:
            close.assert_not_called()
        close.assert_called_once()


def test_transport_close_rest():
    client = ModelMonitoringServiceClient(
        credentials=ga_credentials.AnonymousCredentials(),
        transport="rest"
    )
    with mock.patch.object(type(getattr(client.transport, "_session")), "close") as close:
        with client:
            close.assert_not_called()
        close.assert_called_once()


@pytest.mark.asyncio
async def test_transport_close_rest_asyncio():
    if not HAS_ASYNC_REST_EXTRA:
        pytest.skip("the library must be installed with the `async_rest` extra to test this feature.")
    client = ModelMonitoringServiceAsyncClient(
        credentials=async_anonymous_credentials(),
        transport="rest_asyncio"
    )
    with mock.patch.object(type(getattr(client.transport, "_session")), "close") as close:
        async with client:
            close.assert_not_called()
        close.assert_called_once()


def test_client_ctx():
    transports = [
        'rest',
        'grpc',
    ]
    for transport in transports:
        client = ModelMonitoringServiceClient(
            credentials=ga_credentials.AnonymousCredentials(),
            transport=transport
        )
        # Test client calls underlying transport.
        with mock.patch.object(type(client.transport), "close") as close:
            close.assert_not_called()
            with client:
                pass
            close.assert_called()

@pytest.mark.parametrize("client_class,transport_class", [
    (ModelMonitoringServiceClient, transports.ModelMonitoringServiceGrpcTransport),
    (ModelMonitoringServiceAsyncClient, transports.ModelMonitoringServiceGrpcAsyncIOTransport),
])
def test_api_key_credentials(client_class, transport_class):
    with mock.patch.object(
        google.auth._default, "get_api_key_credentials", create=True
    ) as get_api_key_credentials:
        mock_cred = mock.Mock()
        get_api_key_credentials.return_value = mock_cred
        options = client_options.ClientOptions()
        options.api_key = "api_key"
        with mock.patch.object(transport_class, "__init__") as patched:
            patched.return_value = None
            client = client_class(client_options=options)
            patched.assert_called_once_with(
                credentials=mock_cred,
                credentials_file=None,
                host=client._DEFAULT_ENDPOINT_TEMPLATE.format(UNIVERSE_DOMAIN=client._DEFAULT_UNIVERSE),
                scopes=None,
                client_cert_source_for_mtls=None,
                quota_project_id=None,
                client_info=transports.base.DEFAULT_CLIENT_INFO,
                always_use_jwt_access=True,
                api_audience=None,
            )
