PersistentResourceService
-------------------------------------------

.. automodule:: google.cloud.aiplatform_v1beta1.services.persistent_resource_service
    :members:
    :inherited-members:

.. automodule:: google.cloud.aiplatform_v1beta1.services.persistent_resource_service.pagers
    :members:
    :inherited-members:
