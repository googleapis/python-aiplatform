EvaluationService
-----------------------------------

.. automodule:: google.cloud.aiplatform_v1beta1.services.evaluation_service
    :members:
    :inherited-members:
