VertexRagService
----------------------------------

.. automodule:: google.cloud.aiplatform_v1beta1.services.vertex_rag_service
    :members:
    :inherited-members:
