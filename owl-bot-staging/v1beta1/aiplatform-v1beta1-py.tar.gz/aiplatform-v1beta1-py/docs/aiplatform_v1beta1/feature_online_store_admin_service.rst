FeatureOnlineStoreAdminService
------------------------------------------------

.. automodule:: google.cloud.aiplatform_v1beta1.services.feature_online_store_admin_service
    :members:
    :inherited-members:

.. automodule:: google.cloud.aiplatform_v1beta1.services.feature_online_store_admin_service.pagers
    :members:
    :inherited-members:
