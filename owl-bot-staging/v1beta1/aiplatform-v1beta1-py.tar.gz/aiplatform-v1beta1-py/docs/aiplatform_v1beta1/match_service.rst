MatchService
------------------------------

.. automodule:: google.cloud.aiplatform_v1beta1.services.match_service
    :members:
    :inherited-members:
