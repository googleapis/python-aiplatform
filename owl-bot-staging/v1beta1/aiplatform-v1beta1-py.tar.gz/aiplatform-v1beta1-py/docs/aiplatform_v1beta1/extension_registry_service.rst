ExtensionRegistryService
------------------------------------------

.. automodule:: google.cloud.aiplatform_v1beta1.services.extension_registry_service
    :members:
    :inherited-members:

.. automodule:: google.cloud.aiplatform_v1beta1.services.extension_registry_service.pagers
    :members:
    :inherited-members:
