FeaturestoreOnlineServingService
--------------------------------------------------

.. automodule:: google.cloud.aiplatform_v1beta1.services.featurestore_online_serving_service
    :members:
    :inherited-members:
