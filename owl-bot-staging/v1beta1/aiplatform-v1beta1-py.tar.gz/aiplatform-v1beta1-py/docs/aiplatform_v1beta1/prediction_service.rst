PredictionService
-----------------------------------

.. automodule:: google.cloud.aiplatform_v1beta1.services.prediction_service
    :members:
    :inherited-members:
