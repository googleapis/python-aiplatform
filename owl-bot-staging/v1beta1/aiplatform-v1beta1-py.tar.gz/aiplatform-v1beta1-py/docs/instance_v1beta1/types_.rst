Types for Google Cloud Aiplatform V1beta1 Schema Predict Instance v1beta1 API
=============================================================================

.. automodule:: google.cloud.aiplatform.v1beta1.schema.predict.instance_v1beta1.types
    :members:
    :show-inheritance:
